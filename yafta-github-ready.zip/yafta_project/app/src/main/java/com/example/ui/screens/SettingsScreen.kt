package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreenLayout(viewModel: YaftaViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val settings by viewModel.settingsState.collectAsState()
    val staffList by viewModel.allStaff.collectAsState()

    // Screen-level state for backup categories selections
    var incCompany by remember { mutableStateOf(true) }
    var incUsers by remember { mutableStateOf(true) }
    var incLeads by remember { mutableStateOf(true) }
    var incProjects by remember { mutableStateOf(true) }
    var incInventory by remember { mutableStateOf(true) }
    var incFinance by remember { mutableStateOf(true) }
    var incHr by remember { mutableStateOf(true) }
    var incSettingsCategory by remember { mutableStateOf(true) }

    // Backup interaction outcomes states
    var showBackupDialog by remember { mutableStateOf(false) }
    var generatedBackupJson by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(false) }
    var importJsonText by remember { mutableStateOf("") }
    var isBackupEncrypting by remember { mutableStateOf(false) }
    var backupProgress by remember { mutableStateOf(0f) }
    var cloudSyncStatus by remember { mutableStateOf("Not Synced") }
    var lastSyncTime by remember { mutableStateOf("") }

    // 12 Sub-sections list setup
    val sections = listOf(
        SystemCenterSection("Application Settings", "إعدادات التطبيق", Icons.Filled.AppSettingsAlt),
        SystemCenterSection("Language Settings (Arabic / English)", "إعدادات اللغة", Icons.Filled.Translate),
        SystemCenterSection("Light / Dark Theme", "المظهر والسمات", Icons.Filled.LightMode),
        SystemCenterSection("User Management", "إدارة المستخدمين", Icons.Filled.People),
        SystemCenterSection("Roles & Permissions", "الرتب والصلاحيات", Icons.Filled.AdminPanelSettings),
        SystemCenterSection("Security Settings", "خيارات الحماية", Icons.Filled.Security),
        SystemCenterSection("Backup & Restore", "النسخ الاحتياطي", Icons.Filled.Backup),
        SystemCenterSection("Company Information", "بيانات الشركة", Icons.Filled.Business),
        SystemCenterSection("Print Settings", "إعدادات الطباعة", Icons.Filled.Print),
        SystemCenterSection("Design Studio Settings", "خصائص لوحة التصميم", Icons.Filled.SettingsInputComponent),
        SystemCenterSection("AI Settings", "إعدادات الذكاء الاصطناعي", Icons.Filled.AutoAwesome),
        SystemCenterSection("Notification Settings", "التنبيهات والإشعارات", Icons.Filled.Notifications)
    )

    var activeSubTab by remember { mutableStateOf(0) }

    // Determine device screen properties for adaptive scaling
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 720

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .padding(if (isTablet) 24.dp else 16.dp)
            .testTag("settings_screen_container")
    ) {
        // Upper Title Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "YAFTA SYSTEM CENTER / مركز النظام",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = BrushedTitanium,
                        fontSize = if (isTablet) 24.sp else 18.sp,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = "Configure advanced permissions, enterprise local profiles, and database disaster recovery.",
                    style = MaterialTheme.typography.bodySmall,
                    color = NeonCyan
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(NeonCyan.copy(alpha = 0.15f))
                    .border(1.dp, NeonCyan, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("SECURE SHA1", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (isTablet) {
            // Adaptive Grid: Left Sidebar Selector (12 sections), Right Control Form Panel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // PANEL 1: Left Navigation Strip of the 12 Modules
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(DarkSlateCard.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                        .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                        .verticalScroll(rememberScrollState())
                        .padding(8.dp)
                ) {
                    sections.forEachIndexed { idx, sec ->
                        val active = activeSubTab == idx
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) NeonPurple else Color.Transparent)
                                .clickable { activeSubTab = idx }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = sec.icon,
                                    contentDescription = null,
                                    tint = if (active) DeepSlateBg else TextSilver,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = sec.titleEng,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (active) DeepSlateBg else BrushedTitanium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = sec.titleAra,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                        color = if (active) DeepSlateBg.copy(alpha = 0.8f) else TextSilver,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                // PANEL 2: Right Active Section Control form layout
                Column(
                    modifier = Modifier
                        .weight(2.2f)
                        .fillMaxHeight()
                        .background(DarkSlateCard, RoundedCornerShape(16.dp))
                        .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                        .padding(20.dp)
                ) {
                    Text(
                        text = sections[activeSubTab].titleEng.uppercase() + " / " + sections[activeSubTab].titleAra,
                        color = NeonCyan,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        RenderSectionControl(
                            index = activeSubTab,
                            settings = settings,
                            staffList = staffList,
                            viewModel = viewModel,
                            coroutineScope = coroutineScope,
                            clipboardManager = clipboardManager,
                            context = context,
                            incCompany = incCompany,
                            incUsers = incUsers,
                            incLeads = incLeads,
                            incProjects = incProjects,
                            incInventory = incInventory,
                            incFinance = incFinance,
                            incHr = incHr,
                            incSettingsCategory = incSettingsCategory,
                            onChangeIncCompany = { incCompany = it },
                            onChangeIncUsers = { incUsers = it },
                            onChangeIncLeads = { incLeads = it },
                            onChangeIncProjects = { incProjects = it },
                            onChangeIncInventory = { incInventory = it },
                            onChangeIncFinance = { incFinance = it },
                            onChangeIncHr = { incHr = it },
                            onChangeIncSettingsCategory = { incSettingsCategory = it },
                            onTriggerBackup = {
                                generatedBackupJson = it
                                showBackupDialog = true
                            },
                            onTriggerImport = { showImportDialog = true }
                        )
                    }
                }
            }
        } else {
            // MOBILE COMPACT VIEWS
            var showMobileDropdownMenu by remember { mutableStateOf(false) }

            // Mobile Category Selector
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, BorderGlass, RoundedCornerShape(12.dp))
                    .clickable { showMobileDropdownMenu = true }
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(sections[activeSubTab].icon, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(sections[activeSubTab].titleEng, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(sections[activeSubTab].titleAra, color = TextSilver, fontSize = 9.sp)
                        }
                    }
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = BrushedTitanium)
                }

                DropdownMenu(
                    expanded = showMobileDropdownMenu,
                    onDismissRequest = { showMobileDropdownMenu = false },
                    modifier = Modifier
                        .background(DarkSlateCard)
                        .border(1.dp, BorderGlass)
                ) {
                    sections.forEachIndexed { selectIdx, selectSec ->
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(selectSec.icon, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("${selectSec.titleEng} / ${selectSec.titleAra}", color = BrushedTitanium, fontSize = 11.sp)
                                }
                            },
                            onClick = {
                                activeSubTab = selectIdx
                                showMobileDropdownMenu = false
                            },
                            modifier = Modifier.background(if (activeSubTab == selectIdx) BorderGlass else Color.Transparent)
                        )
                    }
                }
            }

            // Mobile Controls Pane
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(DarkSlateCard, RoundedCornerShape(16.dp))
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    RenderSectionControl(
                        index = activeSubTab,
                        settings = settings,
                        staffList = staffList,
                        viewModel = viewModel,
                        coroutineScope = coroutineScope,
                        clipboardManager = clipboardManager,
                        context = context,
                        incCompany = incCompany,
                        incUsers = incUsers,
                        incLeads = incLeads,
                        incProjects = incProjects,
                        incInventory = incInventory,
                        incFinance = incFinance,
                        incHr = incHr,
                        incSettingsCategory = incSettingsCategory,
                        onChangeIncCompany = { incCompany = it },
                        onChangeIncUsers = { incUsers = it },
                        onChangeIncLeads = { incLeads = it },
                        onChangeIncProjects = { incProjects = it },
                        onChangeIncInventory = { incInventory = it },
                        onChangeIncFinance = { incFinance = it },
                        onChangeIncHr = { incHr = it },
                        onChangeIncSettingsCategory = { incSettingsCategory = it },
                        onTriggerBackup = {
                            generatedBackupJson = it
                            showBackupDialog = true
                        },
                        onTriggerImport = { showImportDialog = true }
                    )
                }
            }
        }
    }

    // Modal dialog displaying packed JSON backup payload (preserved)
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            containerColor = DarkSlateCard,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.CloudDownload, contentDescription = null, tint = NeonMint)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Backup Payload Prepared", color = BrushedTitanium)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Real-time non-media system preferences, core business records, and customer logs packed into encrypted-ready text. Safe for storage or migration:",
                        color = TextSilver,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DeepInkShadow)
                            .border(1.dp, BorderGlass, RoundedCornerShape(8.dp))
                            .verticalScroll(rememberScrollState())
                            .padding(8.dp)
                    ) {
                        Text(
                            text = generatedBackupJson,
                            color = NeonMint,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = BorderGlass),
                        onClick = {
                            clipboardManager.setText(AnnotatedString(generatedBackupJson))
                            Toast.makeText(context, "Copied backup payload to Clipboard!", Toast.LENGTH_LONG).show()
                        }
                    ) {
                        Icon(imageVector = Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy JSON", color = BrushedTitanium)
                    }
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        onClick = { showBackupDialog = false }
                    ) {
                        Text("Dismiss", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }

    // Modal dialog to receive JSON import string and execute system restoration
    if (showImportDialog) {
        var restoreSettingsMode by remember { mutableStateOf(true) }
        var restoreBusinessMode by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = DarkSlateCard,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.SystemUpdateAlt, contentDescription = null, tint = SignalCritical)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Restore Database & System", color = BrushedTitanium)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Paste system backup JSON payload to overwrite active system values:",
                        color = TextSilver,
                        fontSize = 11.sp
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DeepInkShadow)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1.1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (restoreSettingsMode) BorderGlass else Color.Transparent)
                                .clickable { restoreSettingsMode = !restoreSettingsMode }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("RESTORE PREFS", color = if (restoreSettingsMode) NeonCyan else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .weight(1.3f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (restoreBusinessMode) BorderGlass else Color.Transparent)
                                .clickable { restoreBusinessMode = !restoreBusinessMode }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("RESTORE BUS-DATA", color = if (restoreBusinessMode) NeonCyan else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    TextField(
                        value = importJsonText,
                        onValueChange = { importJsonText = it },
                        placeholder = { Text("Paste JSON metadata here...", color = TextSilver.copy(alpha = 0.4f), fontSize = 11.sp) },
                        textStyle = TextStyle(color = NeonMint, fontSize = 10.sp, fontFamily = FontFamily.Monospace),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("restore_json_field"),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = DeepInkShadow,
                            unfocusedContainerColor = DeepInkShadow,
                            unfocusedTextColor = TextSilver,
                            focusedTextColor = BrushedTitanium
                        )
                    )

                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = BorderGlass),
                        onClick = {
                            val demoPayload = BackupPayload(
                                exportTimestamp = System.currentTimeMillis(),
                                settingsConfig = AdvancedSettings(
                                    measurementUnit = "inch",
                                    canvasWidth = 140.0,
                                    canvasHeight = 85.0,
                                    dpi = 350,
                                    colorMode = "CMYK",
                                    watermarkText = "YAFTA RECOVERED PRESET"
                                )
                            )
                            importJsonText = BackupSerializer.serialize(demoPayload)
                            Toast.makeText(context, "Loaded demo preset backup successfully!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Load Sample Preset Blueprint", fontSize = 10.sp, color = NeonCyan)
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = BorderGlass),
                        onClick = { showImportDialog = false }
                    ) {
                        Text("Cancel", color = BrushedTitanium)
                    }
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = SignalCritical),
                        onClick = {
                            if (importJsonText.trim().isEmpty()) {
                                Toast.makeText(context, "Please paste valid JSON text first", Toast.LENGTH_LONG).show()
                            } else {
                                coroutineScope.launch {
                                    try {
                                        val payload = BackupSerializer.deserialize(importJsonText)
                                        if (payload != null) {
                                            viewModel.restoreBackup(
                                                payload = payload,
                                                restoreSettings = restoreSettingsMode,
                                                restoreBusinessData = restoreBusinessMode
                                            )
                                            Toast.makeText(context, "RESTORE SUCCESSFUL! Enterprise systems synchronized.", Toast.LENGTH_LONG).show()
                                            showImportDialog = false
                                        } else {
                                            Toast.makeText(context, "Failed to parse recovery structure. Invalid parameters.", Toast.LENGTH_LONG).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Restoration Failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }
                    ) {
                        Text("Execute Overwrite", color = BrushedTitanium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }
}

@Composable
fun RenderSectionControl(
    index: Int,
    settings: AdvancedSettings,
    staffList: List<User>,
    viewModel: YaftaViewModel,
    coroutineScope: kotlinx.coroutines.CoroutineScope,
    clipboardManager: androidx.compose.ui.platform.ClipboardManager,
    context: android.content.Context,
    incCompany: Boolean,
    incUsers: Boolean,
    incLeads: Boolean,
    incProjects: Boolean,
    incInventory: Boolean,
    incFinance: Boolean,
    incHr: Boolean,
    incSettingsCategory: Boolean,
    onChangeIncCompany: (Boolean) -> Unit,
    onChangeIncUsers: (Boolean) -> Unit,
    onChangeIncLeads: (Boolean) -> Unit,
    onChangeIncProjects: (Boolean) -> Unit,
    onChangeIncInventory: (Boolean) -> Unit,
    onChangeIncFinance: (Boolean) -> Unit,
    onChangeIncHr: (Boolean) -> Unit,
    onChangeIncSettingsCategory: (Boolean) -> Unit,
    onTriggerBackup: (String) -> Unit,
    onTriggerImport: () -> Unit
) {
    var backupProgress by remember { mutableStateOf(0f) }
    var isBackupEncrypting by remember { mutableStateOf(false) }

    when (index) {
        0 -> { // Application Settings
            var autoSave by remember { mutableStateOf(true) }
            var logEvents by remember { mutableStateOf(true) }
            var apiCache by remember { mutableStateOf(true) }

            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Dashboard Refresh Rate interval", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Slider(
                        value = settings.dashboardRefreshIntervalMs.toFloat(),
                        onValueChange = { viewModel.updateSettings(settings.copy(dashboardRefreshIntervalMs = it.toInt())) },
                        valueRange = 1000f..15000f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )
                    Text("${settings.dashboardRefreshIntervalMs} MS", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                Divider(color = BorderGlass)

                StyledSwitchRow("Auto-Save Configurations", "Save application preferences locally as they alter", autoSave) { autoSave = it }
                StyledSwitchRow("Activity Telemetry Logs", "Write debug logs about database & print queries", logEvents) { logEvents = it }
                StyledSwitchRow("Pre-fetch Asset Cache", "Pre-load system vector logos & fonts", apiCache) { apiCache = it }
                StyledSwitchRow("Universal Quick-Launch Section", "Enable direct workflow floating launcher metrics", settings.showQuickLaunchSection) {
                    viewModel.updateSettings(settings.copy(showQuickLaunchSection = it))
                }
            }
        }

        1 -> { // Language Settings
            val languages = listOf("English", "Arabic", "French")
            val nativeLabels = listOf("English (UK)", "العربية (RTL)", "Français (EU)")

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Primary operating interface dialect:", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                languages.forEachIndexed { i, lang ->
                    val active = settings.uiLanguage == lang
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (active) NeonPurple.copy(alpha = 0.15f) else DeepInkShadow)
                            .border(1.dp, if (active) NeonPurple else BorderGlass, RoundedCornerShape(10.dp))
                            .clickable {
                                viewModel.updateSettings(settings.copy(uiLanguage = lang))
                                Toast.makeText(context, "System Language toggled to $lang", Toast.LENGTH_SHORT).show()
                            }
                            .padding(14.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(lang, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(nativeLabels[i], color = TextSilver, fontSize = 10.sp)
                            }
                            if (active) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = NeonPurple)
                            }
                        }
                    }
                }
            }
        }

        2 -> { // Theme Settings
            val themes = listOf("Dark Cosmic", "Classic Slate", "High-Contrast")
            val colorsList = listOf(NeonPurple, NeonCyan, SignalCritical)

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Select application aesthetic & visual color schemes:", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                themes.forEachIndexed { i, th ->
                    val active = settings.themeMode == th
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (active) BorderGlass else DeepInkShadow)
                            .border(1.dp, if (active) colorsList[i] else BorderGlass, RoundedCornerShape(10.dp))
                            .clickable {
                                viewModel.updateSettings(settings.copy(themeMode = th))
                                Toast.makeText(context, "Theme toggled to $th", Toast.LENGTH_SHORT).show()
                            }
                            .padding(14.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(colorsList[i]))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(th, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            if (active) {
                                Text("ACTIVE / نشط", color = NeonMint, fontWeight = FontWeight.Black, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        3 -> { // User Management
            var showAddUserDialog by remember { mutableStateOf(false) }
            var newName by remember { mutableStateOf("") }
            var newEmail by remember { mutableStateOf("") }
            var newPassword by remember { mutableStateOf("") }
            var newRole by remember { mutableStateOf("Designer") }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("AUTHORIZED ENTERPRISE ACCOUNTS", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                    Button(
                        onClick = { showAddUserDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, tint = DeepSlateBg, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Account", color = DeepSlateBg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    staffList.forEach { usr ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(DeepInkShadow)
                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(usr.name, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(usr.email, color = TextSilver, fontSize = 10.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(NeonPurple.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(usr.role, color = NeonPurple, fontSize = 9.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            if (showAddUserDialog) {
                AlertDialog(
                    onDismissRequest = { showAddUserDialog = false },
                    containerColor = DarkSlateCard,
                    title = { Text("CREATE OPERATIONAL ACCOUNT", color = BrushedTitanium, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = newName,
                                onValueChange = { newName = it },
                                label = { Text("Account Name / الاسم", color = TextSilver) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = newEmail,
                                onValueChange = { newEmail = it },
                                label = { Text("Log-in Email / البريد", color = TextSilver) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = newPassword,
                                onValueChange = { newPassword = it },
                                label = { Text("Temporary Passcode / رمز المرور", color = TextSilver) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("Select Role Level Role / الصلاحية", color = TextSilver, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("Admin", "Designer", "Fabricator", "Accountant").forEach { r ->
                                    val match = newRole == r
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (match) NeonPurple else DeepSlateBg)
                                            .clickable { newRole = r }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(r, color = if (match) DeepSlateBg else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                if (newName.isEmpty() || newEmail.isEmpty()) {
                                    Toast.makeText(context, "Please fill in valid account particulars", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                viewModel.register(newEmail, newPassword, newName, newRole) { success ->
                                    if (success) {
                                        Toast.makeText(context, "Registered $newName into database", Toast.LENGTH_SHORT).show()
                                        showAddUserDialog = false
                                        newName = ""
                                        newEmail = ""
                                        newPassword = ""
                                    } else {
                                        Toast.makeText(context, "Account already exists in database!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                        ) {
                            Text("Deploy Account", color = DeepSlateBg)
                        }
                    }
                )
            }
        }

        4 -> { // Roles & Permissions
            var selectedPremRole by remember { mutableStateOf("Designer") }
            var cadWrite by remember { mutableStateOf(true) }
            var crmWrite by remember { mutableStateOf(false) }
            var invoiceWrite by remember { mutableStateOf(false) }
            var stockWrite by remember { mutableStateOf(true) }
            var staffSched by remember { mutableStateOf(false) }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Select a workforce role level to modify ERP module ACL policies:", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Admin", "Designer", "Fabricator", "Accountant").forEach { r ->
                        val act = selectedPremRole == r
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (act) NeonPurple else DeepInkShadow)
                                .border(1.dp, if (act) NeonPurple else BorderGlass, RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedPremRole = r
                                    when (r) {
                                        "Admin" -> {
                                            cadWrite = true; crmWrite = true; invoiceWrite = true; stockWrite = true; staffSched = true
                                        }
                                        "Designer" -> {
                                            cadWrite = true; crmWrite = false; invoiceWrite = false; stockWrite = true; staffSched = false
                                        }
                                        "Fabricator" -> {
                                            cadWrite = false; crmWrite = false; invoiceWrite = false; stockWrite = true; staffSched = false
                                        }
                                        "Accountant" -> {
                                            cadWrite = false; crmWrite = true; invoiceWrite = true; stockWrite = false; staffSched = false
                                        }
                                    }
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(r, color = if (act) DeepSlateBg else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Divider(color = BorderGlass, modifier = Modifier.padding(vertical = 4.dp))

                StyledSwitchRow("CAD Vector Node Creation & Export", "Authorizes modifying Signage studio design models", cadWrite) { cadWrite = it }
                StyledSwitchRow("CRM Directory Operations", "Allow inserting, updating or clearing customer records & dial logs", crmWrite) { crmWrite = it }
                StyledSwitchRow("Financial Invoicing Ledger Edit", "Permits dispatching and signing commercial legal receipts", invoiceWrite) { invoiceWrite = it }
                StyledSwitchRow("Inventory Catalog Allocation", "Permit deducting or restock acrylic, neon modules, profiles", stockWrite) { stockWrite = it }
                StyledSwitchRow("Staff Salary Allocation Plan", "Permit modifying payroll schedule & assignments", staffSched) { staffSched = it }

                Button(
                    onClick = {
                        Toast.makeText(context, "$selectedPremRole Permissions applied instantly to cloud active accounts!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonMint),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Apply Access Policies", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                }
            }
        }

        5 -> { // Security Settings
            var passcodeEnabled by remember { mutableStateOf(false) }
            var codeText by remember { mutableStateOf("1422") }
            var sessionTimeout by remember { mutableStateOf(30f) }
            var syncMfa by remember { mutableStateOf(true) }

            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                StyledSwitchRow("Require System Pin passcode Code", "Locks app operations when screen is idle", passcodeEnabled) { passcodeEnabled = it }
                if (passcodeEnabled) {
                    OutlinedTextField(
                        value = codeText,
                        onValueChange = { codeText = it },
                        label = { Text("Secure numerical PIN code", color = TextSilver) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Divider(color = BorderGlass)

                Text("Automatic Session Lock Timeout: ${sessionTimeout.toInt()} Mins", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = sessionTimeout,
                    onValueChange = { sessionTimeout = it },
                    valueRange = 5f..120f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                StyledSwitchRow("Admin Multi-Factor Verification", "Requires SMS verification check when loading invoice sync outputs", syncMfa) { syncMfa = it }
            }
        }

        6 -> { // Backup & Restore (exact preservation)
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    "Pack business parameters & preferences locally:",
                    color = TextSilver,
                    fontSize = 11.sp
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DeepInkShadow)
                        .padding(12.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BackupCheckbox("Company Data", incCompany, onChangeIncCompany)
                        BackupCheckbox("User Accounts", incUsers, onChangeIncUsers)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BackupCheckbox("CRM Leads", incLeads, onChangeIncLeads)
                        BackupCheckbox("Fabrications", incProjects, onChangeIncProjects)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BackupCheckbox("Inventory Logs", incInventory, onChangeIncInventory)
                        BackupCheckbox("Finances Receipts", incFinance, onChangeIncFinance)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BackupCheckbox("Workforce Roles", incHr, onChangeIncHr)
                        BackupCheckbox("System Settings", incSettingsCategory, onChangeIncSettingsCategory)
                    }
                }

                Button(
                    onClick = {
                        coroutineScope.launch {
                            val payload = viewModel.createBackupPayload(
                                includeCompanyColors = incCompany,
                                includeUsers = incUsers,
                                includeLeads = incLeads,
                                includeProjects = incProjects,
                                includeInventory = incInventory,
                                includeFinance = incFinance,
                                includeHr = incHr,
                                includeSettings = incSettingsCategory
                            )
                            val serialized = BackupSerializer.serialize(payload)
                            onTriggerBackup(serialized)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("add_backup_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                ) {
                    Icon(imageVector = Icons.Filled.Backup, contentDescription = null, tint = DeepSlateBg)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate Selective JSON Backup", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            isBackupEncrypting = true
                            backupProgress = 0f
                            coroutineScope.launch {
                                for (p in 1..10) {
                                    kotlinx.coroutines.delay(100)
                                    backupProgress = p / 10f
                                }
                                isBackupEncrypting = false
                                Toast.makeText(context, "Encrypted Secure ZIP created: yafta-backup-bundle.zip.enc (AES-256)", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = BorderGlass),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.FolderZip, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Secure ZIP", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                kotlinx.coroutines.delay(1000)
                                Toast.makeText(context, "Google Drive Sync Completed!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = BorderGlass),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.CloudUpload, contentDescription = null, tint = NeonMint, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cloud Sync", color = NeonMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (isBackupEncrypting) {
                    Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Encrypting non-binary files & building CRC block...", color = TextSilver, fontSize = 10.sp)
                            Text("${(backupProgress * 100).toInt()}%", color = Neoncyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = backupProgress,
                            color = NeonCyan,
                            trackColor = BorderGlass,
                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape)
                        )
                    }
                }

                Divider(color = BorderGlass)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onTriggerImport,
                        modifier = Modifier.weight(1f).testTag("restore_import_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSlateCard),
                        border = BorderStroke(1.dp, SignalCritical)
                    ) {
                        Icon(imageVector = Icons.Filled.Restore, contentDescription = null, tint = SignalCritical)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Restore from JSON", color = SignalCritical, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        7 -> { // Company Information
            var compName by remember { mutableStateOf("Yafta Advertisers KSA") }
            var commercialRegisterNum by remember { mutableStateOf("1010776542") }
            var taxVatId by remember { mutableStateOf("310243452200003") }
            var emailVal by remember { mutableStateOf("support@yafta.com.sa") }
            var phoneVal by remember { mutableStateOf("+966504288012") }
            var officeLoc by remember { mutableStateOf("Olaya District Commercial Strip, Riyadh GP 12211") }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = compName,
                    onValueChange = { compName = it },
                    label = { Text("Corporate Firm Name / الاسم التجاري", color = TextSilver) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = commercialRegisterNum,
                    onValueChange = { commercialRegisterNum = it },
                    label = { Text("Saudi CR Number / السجل التجاري", color = TextSilver) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = taxVatId,
                    onValueChange = { taxVatId = it },
                    label = { Text("KSA VAT Tax Registration (15% ID)", color = TextSilver) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = emailVal,
                        onValueChange = { emailVal = it },
                        label = { Text("Support Email / البريد", color = TextSilver) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = phoneVal,
                        onValueChange = { phoneVal = it },
                        label = { Text("Landline Phone / الجوال", color = TextSilver) },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = officeLoc,
                    onValueChange = { officeLoc = it },
                    label = { Text("Riyadh Headquarters Headquarters Area", color = TextSilver) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Button(
                    onClick = {
                        Toast.makeText(context, "Company Registry profile localized to Room Database!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonMint),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save Corporate Profile", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                }
            }
        }

        8 -> { // Print Settings (Marginal values, color mode, dpi)
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Print Output Margins Boundary Control (CM):", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Left (${settings.printMarginLeft}cm)", color = TextSilver, fontSize = 10.sp)
                        Slider(
                            value = settings.printMarginLeft.toFloat(),
                            onValueChange = { viewModel.updateSettings(settings.copy(printMarginLeft = it.toDouble())) },
                            valueRange = 0f..10f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyan)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Right (${settings.printMarginRight}cm)", color = TextSilver, fontSize = 10.sp)
                        Slider(
                            value = settings.printMarginRight.toFloat(),
                            onValueChange = { viewModel.updateSettings(settings.copy(printMarginRight = it.toDouble())) },
                            valueRange = 0f..10f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyan)
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Top (${settings.printMarginTop}cm)", color = TextSilver, fontSize = 10.sp)
                        Slider(
                            value = settings.printMarginTop.toFloat(),
                            onValueChange = { viewModel.updateSettings(settings.copy(printMarginTop = it.toDouble())) },
                            valueRange = 0f..10f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyan)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Bottom (${settings.printMarginBottom}cm)", color = TextSilver, fontSize = 10.sp)
                        Slider(
                            value = settings.printMarginBottom.toFloat(),
                            onValueChange = { viewModel.updateSettings(settings.copy(printMarginBottom = it.toDouble())) },
                            valueRange = 0f..10f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyan)
                        )
                    }
                }

                Divider(color = BorderGlass)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Laser/Print Resolution Depth:", color = TextSilver, fontSize = 11.sp)
                    Text("${settings.dpi} DPI", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                Slider(
                    value = settings.dpi.toFloat(),
                    onValueChange = { viewModel.updateSettings(settings.copy(dpi = it.toInt())) },
                    valueRange = 72f..600f,
                    steps = 6,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                Divider(color = BorderGlass)

                Text("Ink Spot Color Output System", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("RGB", "CMYK").forEach { style ->
                        val active = settings.colorMode == style
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) NeonPurple.copy(alpha = 0.15f) else DeepInkShadow)
                                .border(1.dp, if (active) NeonPurple else BorderGlass, RoundedCornerShape(8.dp))
                                .clickable { viewModel.updateSettings(settings.copy(colorMode = style)) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(style, color = if (active) NeonPurple else TextSilver, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        9 -> { // Design Studio Settings (Preserving core ruler/guide switches, crop marks, etc.)
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Board Width (${settings.canvasWidth.toInt()}cm)", color = TextSilver, fontSize = 10.sp)
                        Slider(
                            value = settings.canvasWidth.toFloat(),
                            onValueChange = { viewModel.updateSettings(settings.copy(canvasWidth = it.toDouble())) },
                            valueRange = 20f..300f,
                            colors = SliderDefaults.colors(thumbColor = Neoncyan)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Board Height (${settings.canvasHeight.toInt()}cm)", color = TextSilver, fontSize = 10.sp)
                        Slider(
                            value = settings.canvasHeight.toFloat(),
                            onValueChange = { viewModel.updateSettings(settings.copy(canvasHeight = it.toDouble())) },
                            valueRange = 20f..300f,
                            colors = SliderDefaults.colors(thumbColor = Neoncyan)
                        )
                    }
                }

                Divider(color = BorderGlass)

                StyledSwitchRow("Overlay Core Ticks Rulers", "Displays metric scale ticks around sheet bounds", settings.rulersEnabled) {
                    viewModel.updateSettings(settings.copy(rulersEnabled = it))
                }
                StyledSwitchRow("Enable Guidelines Alignment", "Snaps active vector layers to grid limits", settings.guidesEnabled) {
                    viewModel.updateSettings(settings.copy(guidesEnabled = it))
                }
                StyledSwitchRow("Graph Grid Graticule Lines", "Draw reference blueprint dashed grids", settings.gridEnabled) {
                    viewModel.updateSettings(settings.copy(gridEnabled = it))
                }
                StyledSwitchRow("Safe Bounds Marginal Frame", "Alerts designer of bezel structural margins", settings.safeAreaEnabled) {
                    viewModel.updateSettings(settings.copy(safeAreaEnabled = it))
                }
                StyledSwitchRow("Production Bleed Line", "Draw outer laser bleed cut boundaries", settings.bleedAreaEnabled) {
                    viewModel.updateSettings(settings.copy(bleedAreaEnabled = it))
                }
                StyledSwitchRow("Overlay Registration Marks", "Draw camera register corners for CNC laser cutting", settings.cropMarksEnabled) {
                    viewModel.updateSettings(settings.copy(cropMarksEnabled = it))
                }

                Divider(color = BorderGlass)

                Text("Watermark Overlaid Mask Text:", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                OutlinedTextField(
                    value = settings.watermarkText,
                    onValueChange = { viewModel.updateSettings(settings.copy(watermarkText = it)) },
                    placeholder = { Text("YAFTA WATERMARK") },
                    textStyle = TextStyle(color = BrushedTitanium, fontSize = 12.sp),
                    colors = TextFieldDefaults.colors(focusedTextColor = BrushedTitanium, focusedContainerColor = DeepInkShadow),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Watermark Opacity:", color = TextSilver, fontSize = 11.sp)
                    Text("${(settings.watermarkOpacity * 100).toInt()}%", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                Slider(
                    value = settings.watermarkOpacity,
                    onValueChange = { viewModel.updateSettings(settings.copy(watermarkOpacity = it)) },
                    valueRange = 0.05f..0.8f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan)
                )

                Divider(color = BorderGlass)

                Text("Branding Shield Logo Placement:", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("Top-Left", "Top-Right", "Bottom-Left", "None").forEach { pos ->
                        val act = settings.logoPlacement == pos
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (act) NeonPurple.copy(alpha = 0.15f) else DeepInkShadow)
                                .border(1.dp, if (act) NeonPurple else BorderGlass, RoundedCornerShape(6.dp))
                                .clickable { viewModel.updateSettings(settings.copy(logoPlacement = pos)) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(pos, color = if (act) NeonPurple else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        10 -> { // AI Settings (Gemini Parameters configuration)
            var aiModelSelected by remember { mutableStateOf("Gemini 1.5 Pro (Workspace)") }
            var aiTemperature by remember { mutableStateOf(0.7f) }
            var maxTokensSetting by remember { mutableStateOf(1024f) }

            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Select Default Gemini model Core:", color = TextSilver, style = MaterialTheme.typography.labelSmall)
                listOf("Gemini 1.5 Flash (Swift)", "Gemini 1.5 Pro (Workspace)", "Gemini 2.0 Flash Experiments").forEach { model ->
                    val act = aiModelSelected == model
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (act) NeonPurple.copy(alpha = 0.15f) else DeepInkShadow)
                            .border(1.dp, if (act) NeonPurple else BorderGlass, RoundedCornerShape(8.dp))
                            .clickable {
                                aiModelSelected = model
                                Toast.makeText(context, "$model selected as default pipeline", Toast.LENGTH_SHORT).show()
                            }
                            .padding(12.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(model, color = BrushedTitanium, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            if (act) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(NeonMint))
                            }
                        }
                    }
                }

                Divider(color = BorderGlass)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("AI Creativity Scale (Temperature):", color = TextSilver, fontSize = 11.sp)
                    Text(String.format("%.1f", aiTemperature), color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                Slider(
                    value = aiTemperature,
                    onValueChange = { aiTemperature = it },
                    valueRange = 0.1f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Max Generated Response Length:", color = TextSilver, fontSize = 11.sp)
                    Text("${maxTokensSetting.toInt()} Tokens", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                Slider(
                    value = maxTokensSetting,
                    onValueChange = { maxTokensSetting = it },
                    valueRange = 128f..2048f,
                    steps = 15,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan)
                )
            }
        }

        11 -> { // Notification Settings
            var emailReports by remember { mutableStateOf(true) }
            var stockWarnings by remember { mutableStateOf(true) }
            var lowBalanceAlarms by remember { mutableStateOf(false) }
            var deadlineSlackSync by remember { mutableStateOf(true) }

            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                StyledSwitchRow("Email Weekly Profit Reports", "Dispatches executive summaries to support mailbox daily", emailReports) { emailReports = it }
                StyledSwitchRow("Low Material Stock Warnings", "Triggers high-contrast alerts when acrylic stock under alerts limits", stockWarnings) { stockWarnings = it }
                StyledSwitchRow("Financial Deficit Balance Alarms", "Alerts operators when expense transactions cross commercial bounds", lowBalanceAlarms) { lowBalanceAlarms = it }
                StyledSwitchRow("Slack Team Deadline Coordination", "Dispatches push alerts about signboard fabrication delays", deadlineSlackSync) { deadlineSlackSync = it }
            }
        }
    }
}

@Composable
fun StyledSwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(0.8f)) {
            Text(title, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(description, color = TextSilver, fontSize = 10.sp, lineHeight = 13.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NeonCyan,
                checkedTrackColor = NeonCyan.copy(alpha = 0.4f),
                uncheckedThumbColor = TextSilver,
                uncheckedTrackColor = DeepSlateBg
            )
        )
    }
}

data class SystemCenterSection(
    val titleEng: String,
    val titleAra: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun BackupCheckbox(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .width(140.dp)
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = NeonCyan,
                uncheckedColor = BorderGlass,
                checkmarkColor = DeepSlateBg
            )
        )
        Text(
            text = label,
            color = BrushedTitanium,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

val Neoncyan = Color(0xFF00F5FF)
