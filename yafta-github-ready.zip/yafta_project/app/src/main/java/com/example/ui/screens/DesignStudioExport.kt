package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.IntegrationInstructions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@Composable
fun PrintSetupDialog(
    showPrintSetupMenu: Boolean,
    onDismiss: () -> Unit,
    colorMode: String,
    onColorModeChange: (String) -> Unit,
    dpiSetting: Int,
    onDpiSettingChange: (Int) -> Unit,
    showBleedField: Boolean,
    onShowBleedFieldChange: (Boolean) -> Unit,
    showSafeField: Boolean,
    onShowSafeFieldChange: (Boolean) -> Unit
) {
    if (showPrintSetupMenu) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = DarkSlateCard,
            modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
            title = { Text("PRINT SPECIFICATIONS", color = BrushedTitanium, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Output Color Space Preview:", color = TextSilver, fontSize = 10.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("RGB", "CMYK").forEach { style ->
                                val act = colorMode == style
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (act) NeonCyan else DeepSlateBg)
                                        .clickable { onColorModeChange(style) }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(style, color = if (act) DeepSlateBg else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Resolution Depth:", color = TextSilver, fontSize = 10.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(150, 300, 600).forEach { dpi ->
                                val act = dpiSetting == dpi
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (act) NeonCyan else DeepSlateBg)
                                        .clickable { onDpiSettingChange(dpi) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("${dpi}DPI", color = if (act) DeepSlateBg else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Render Bleed Guide Overlay:", color = TextSilver, fontSize = 10.sp)
                        Switch(checked = showBleedField, onCheckedChange = onShowBleedFieldChange)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Render Safe Zone Margin:", color = TextSilver, fontSize = 10.sp)
                        Switch(checked = showSafeField, onCheckedChange = onShowSafeFieldChange)
                    }
                }
            },
            confirmButton = {
                Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)) {
                    Text("Accept", color = DeepSlateBg)
                }
            }
        )
    }
}

@Composable
fun SaveLeadDialog(
    showSaveLeadDialog: Boolean,
    onDismiss: () -> Unit,
    leadClientBusinessName: String,
    onLeadClientBusinessNameChange: (String) -> Unit,
    leadContactPhoneNum: String,
    onLeadContactPhoneNumChange: (String) -> Unit,
    viewModel: YaftaViewModel,
    totalAreaSquareMeters: Double,
    canvasWidth: String,
    selectedUnit: String,
    canvasHeight: String,
    estimatedLedModules: Int,
    aluminumProfileMeters: Double,
    suggestedRetailPrice: Double,
    acrylicSheetsM2: Double,
    unitAcrylicCost: Double,
    widthFloat: Double,
    heightFloat: Double,
    activeText: String,
    onCreatedLead: () -> Unit
) {
    val context = LocalContext.current

    if (showSaveLeadDialog) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = DarkSlateCard,
            modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.IntegrationInstructions, contentDescription = null, tint = NeonPurple)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Lodge to Yafta Enterprise ERP", color = BrushedTitanium, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Pushes this exact canvas coordinate set to CRM as a design option, logs required materials inside inventory catalogs, and files a customer proposal quote record.",
                        color = TextSilver,
                        fontSize = 11.sp
                    )
                    OutlinedTextField(
                        value = leadClientBusinessName,
                        onValueChange = onLeadClientBusinessNameChange,
                        label = { Text("Client Business Name", color = TextSilver) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = leadContactPhoneNum,
                        onValueChange = onLeadContactPhoneNumChange,
                        label = { Text("Client Handphone number", color = TextSilver) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (leadClientBusinessName.isEmpty()) {
                            Toast.makeText(context, "Provide corporate partner name", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val summaryBrief = "Custom Advertising Design Studio: Area: ${String.format("%.2f", totalAreaSquareMeters)}m², Width: ${canvasWidth}${selectedUnit}, Height: ${canvasHeight}${selectedUnit}. Specifications: $estimatedLedModules LEDs, $aluminumProfileMeters m metal profile."
                        
                        // Lead insert
                        viewModel.addLead(
                            clientName = leadClientBusinessName,
                            clientPhone = leadContactPhoneNum.ifEmpty { "+9665" },
                            projectType = "Custom Signboard Board",
                            designBrief = summaryBrief,
                            estimatedValue = suggestedRetailPrice
                        )

                        // Project creation
                        viewModel.addCustomProject(
                            title = "$leadClientBusinessName Modern Advertising Board",
                            clientName = leadClientBusinessName,
                            budget = suggestedRetailPrice,
                            notes = summaryBrief,
                            widthCm = widthFloat,
                            heightCm = heightFloat,
                            colorHex = "#00FFFF",
                            signText = activeText,
                            assignedDesigner = 1L,
                            assignedFabricator = 2L,
                            assignedInstaller = 3L
                        )

                        // Stock updates
                        viewModel.addInventoryItem(
                            name = "$leadClientBusinessName Acrylic Panel Sheet",
                            materialType = "Acrylic Sheets",
                            currentStock = acrylicSheetsM2,
                            minimumStockAlert = 5.0,
                            unitPrice = unitAcrylicCost
                        )

                        Toast.makeText(context, "Direct ERP integration generated perfectly!", Toast.LENGTH_LONG).show()
                        onDismiss()
                        onCreatedLead()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonMint)
                ) {
                    Text("Integrate Contract", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = TextSilver)
                }
            }
        )
    }
}

@Composable
fun PowerTraceExportDialog(
    showCpuSvgExportViewer: Boolean,
    onDismiss: () -> Unit,
    canvasWidth: String,
    canvasHeight: String,
    layersList: List<DesignLayer>
) {
    if (showCpuSvgExportViewer) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = DarkSlateCard,
            modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
            title = { Text("PowerTRACE CNC SVG Vector Code", color = BrushedTitanium, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Direct output code parsed matching vector layer attributes, compiled for Laser, Ink, and CNC router machinery coordinates.",
                        color = TextSilver,
                        fontSize = 11.sp
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepSlateBg)
                            .clip(RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        val svgCode = StringBuilder().apply {
                            append("<svg width=\"${canvasWidth}\" height=\"${canvasHeight}\" viewBox=\"0 0 100 100\" xmlns=\"http://www.w3.org/2000/svg\">\n")
                            layersList.forEach { layer ->
                                if (layer.type == LayerType.SHAPE) {
                                    append("  <rect x=\"${layer.xPercent - layer.widthPercent / 2}\" y=\"${layer.yPercent - layer.heightPercent / 2}\" width=\"${layer.widthPercent}\" height=\"${layer.heightPercent}\" fill=\"${layer.primaryColorHex}\" />\n")
                                } else if (layer.type == LayerType.TEXT) {
                                    append("  <text x=\"${layer.xPercent}\" y=\"${layer.yPercent}\" font-size=\"${layer.fontSize}\" fill=\"${layer.primaryColorHex}\">${layer.text}</text>\n")
                                } else {
                                    append("  <path d=\"M ${layer.xPercent} ${layer.yPercent} L 55 42 L 45 60 Z\" fill=\"${layer.primaryColorHex}\" />\n")
                                }
                            }
                            append("</svg>")
                        }.toString()

                        Text(
                            text = svgCode,
                            fontFamily = FontFamily.Monospace,
                            color = NeonCyan,
                            fontSize = 9.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)) {
                    Text("Ok", color = DeepSlateBg)
                }
            }
        )
    }
}

@Composable
fun AiAdviceSidePanel(
    showAiAdvicePanel: Boolean,
    onDismiss: () -> Unit,
    aiFeatureClickedTitle: String,
    aiIsLoading: Boolean,
    aiStudioResult: String
) {
    if (showAiAdvicePanel) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(320.dp)
                .background(DarkSlateCard.copy(alpha = 0.98f))
                .border(1.dp, BorderGlass)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.AutoAwesome, contentDescription = null, tint = NeonPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = aiFeatureClickedTitle,
                            color = BrushedTitanium,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Close", tint = TextSilver)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Querying live model algorithms... Generates styling recommendations, optimal neon placements, and Arabic fonts advice:",
                    color = TextSilver,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                if (aiIsLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = NeonPurple, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Computing Vector Metrics...", color = TextSilver, fontSize = 10.sp)
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = "GEMINI ADVERTISING STRATEGY:",
                            color = NeonMint,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                        .fillMaxWidth()
                                        .background(DeepSlateBg)
                                        .clip(RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                        ) {
                            Text(
                                text = aiStudioResult.ifEmpty { "Recommendation: Highlight branding header with champagne-gold color with back-lit halo glows. Use Tajawal Calligraphy font style on brushed glass backplates to guarantee high readability." },
                                color = TextSilver,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
