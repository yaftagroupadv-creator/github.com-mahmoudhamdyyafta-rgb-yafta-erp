package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun DesignCustomCanvas(
    layersList: List<DesignLayer>,
    selectedLayerId: String?,
    onLayerSelect: (String) -> Unit,
    zoomFactor: Float,
    showGrid: Boolean,
    showGuides: Boolean,
    showBleedField: Boolean,
    showSafeField: Boolean,
    showMockupBg: Boolean,
    backdropTheme: String,
    colorMode: String,
    isTablet: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1.5f)
            .scale(zoomFactor)
            .border(
                BorderStroke(
                    2.dp,
                    Brush.linearGradient(
                        listOf(
                            BorderGlass,
                            if (selectedLayerId != null) NeonPurple else BorderGlass,
                            BorderGlass
                        )
                    )
                ),
                shape = RoundedCornerShape(10.dp)
            ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (showMockupBg) {
                        when (backdropTheme) {
                            "Café Brick Storefront" -> Brush.verticalGradient(
                                listOf(Color(0xFF8B5E3C), Color(0xFF3E2723))
                            )
                            "Urban Concrete Face" -> Brush.radialGradient(
                                listOf(Color(0xFF808080), Color(0xFF2E2E2E))
                            )
                            "Vans Delivery Side" -> Brush.linearGradient(
                                listOf(Color(0xFFDCDCDC), Color(0xFF778899))
                            )
                            else -> Brush.verticalGradient(
                                listOf(Color(0xFF15181F), Color(0xFF090A0D))
                            )
                        }
                    } else {
                        Brush.radialGradient(listOf(DarkSlateCard, DeepSlateBg))
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            
            // CMYK Preview Mode shadow
            if (colorMode == "CMYK") {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF000000).copy(alpha = 0.08f))
                )
            }

            // Dynamic Grid Drawing Mesh
            if (showGrid) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val gridRowsAndCols = 16
                    val unitWidth = size.width / gridRowsAndCols
                    for (i in 1 until gridRowsAndCols) {
                        drawLine(
                            color = BorderGlass.copy(alpha = 0.12f),
                            start = Offset(unitWidth * i, 0f),
                            end = Offset(unitWidth * i, size.height),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = BorderGlass.copy(alpha = 0.12f),
                            start = Offset(0f, unitWidth * i),
                            end = Offset(size.width, unitWidth * i),
                            strokeWidth = 1f
                        )
                    }
                }
            }

            // Render Custom Vector Graphics
            Canvas(modifier = Modifier.fillMaxSize()) {
                layersList.filterNot { it.isHidden }.forEach { layer ->
                    val xPos = (layer.xPercent / 100f) * size.width
                    val yPos = (layer.yPercent / 100f) * size.height
                    val lWidth = (layer.widthPercent / 100f) * size.width
                    val lHeight = (layer.heightPercent / 100f) * size.height
                    val colorVal = try {
                        Color(android.graphics.Color.parseColor(layer.primaryColorHex))
                    } catch (e: Exception) {
                        NeonCyan
                    }

                    // Render glowing halogen bounds
                    if (layer.hasGlow) {
                        val gColor = try {
                            Color(android.graphics.Color.parseColor(layer.glowColorHex)).copy(alpha = 0.45f)
                        } catch (e: Exception) {
                            NeonCyan.copy(alpha = 0.45f)
                        }
                        drawCircle(
                            color = gColor,
                            radius = layer.glowRadius * 1.5f,
                            center = Offset(xPos, yPos)
                        )
                    }

                    when (layer.type) {
                        LayerType.SHAPE -> {
                            when (layer.shapeType) {
                                ShapeType.CIRCLE -> {
                                    if (layer.strokeWidth > 0f) {
                                        drawCircle(
                                            color = colorVal,
                                            radius = lWidth / 2f,
                                            center = Offset(xPos, yPos),
                                            style = Stroke(width = layer.strokeWidth * 1.5f)
                                        )
                                    } else {
                                        drawCircle(
                                            color = colorVal,
                                            radius = lWidth / 2f,
                                            center = Offset(xPos, yPos)
                                        )
                                    }
                                }
                                ShapeType.TRIANGLE -> {
                                    val path = Path().apply {
                                        moveTo(xPos, yPos - lHeight / 2)
                                        lineTo(xPos - lWidth / 2, yPos + lHeight / 2)
                                        lineTo(xPos + lWidth / 2, yPos + lHeight / 2)
                                        close()
                                    }
                                    if (layer.strokeWidth > 0f) {
                                        drawPath(path, colorVal, style = Stroke(width = layer.strokeWidth * 1.5f))
                                    } else {
                                        drawPath(path, colorVal)
                                    }
                                }
                                ShapeType.LINE -> {
                                    drawLine(
                                        color = colorVal,
                                        start = Offset(xPos - lWidth / 2, yPos),
                                        end = Offset(xPos + lWidth / 2, yPos),
                                        strokeWidth = (layer.strokeWidth * 2f).coerceAtLeast(3f)
                                    )
                                }
                                else -> { // Rectangle
                                    if (layer.strokeWidth > 0f) {
                                        drawRect(
                                            color = colorVal,
                                            topLeft = Offset(xPos - lWidth / 2, yPos - lHeight / 2),
                                            size = Size(lWidth, lHeight),
                                            style = Stroke(width = layer.strokeWidth * 1.5f)
                                        )
                                    } else {
                                        drawRect(
                                            color = colorVal,
                                            topLeft = Offset(xPos - lWidth / 2, yPos - lHeight / 2),
                                            size = Size(lWidth, lHeight)
                                        )
                                    }
                                }
                            }
                        }
                        LayerType.SVG_LOGO -> {
                            val logoPath = Path().apply {
                                moveTo(xPos, yPos - lHeight / 2)
                                lineTo(xPos + lWidth / 4, yPos + lHeight / 2)
                                lineTo(xPos - lWidth / 2, yPos - lHeight / 6)
                                lineTo(xPos + lWidth / 2, yPos - lHeight / 6)
                                lineTo(xPos - lWidth / 4, yPos + lHeight / 2)
                                close()
                            }
                            drawPath(
                                path = logoPath,
                                color = colorVal,
                                style = if (layer.strokeWidth > 0f) Stroke(layer.strokeWidth) else Fill
                            )
                        }
                        else -> {}
                    }
                }
            }

            // Typography text layers
            layersList.filter { it.type == LayerType.TEXT && !it.isHidden }.forEach { layer ->
                Box(
                    modifier = Modifier
                        .offset(
                            x = (layer.xPercent - 50f).dp * (if (isTablet) 3.5f else 1.8f),
                            y = (layer.yPercent - 50f).dp * (if (isTablet) 2.2f else 1.2f)
                        )
                        .rotate(layer.rotation)
                        .width(((layer.widthPercent * 3.5f).toInt()).dp)
                        .clickable {
                            if (!layer.isLocked) {
                                onLayerSelect(layer.id)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    val itemColor = try {
                        Color(android.graphics.Color.parseColor(layer.primaryColorHex))
                    } catch (e: Exception) {
                        NeonCyan
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = layer.text.ifEmpty { "ENTER SIGN TEXT" }.uppercase(),
                            fontFamily = if (layer.fontName == "Cairo" || layer.fontName == "Amiri") FontFamily.Serif else FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            fontSize = (layer.fontSize * (if (isTablet) 0.7f else 0.45f)).sp,
                            color = itemColor,
                            textAlign = TextAlign.Center,
                            letterSpacing = layer.letterSpacing.sp,
                            lineHeight = (layer.fontSize + 4).sp,
                            modifier = Modifier.padding(2.dp),
                            style = MaterialTheme.typography.titleMedium.copy(
                                shadow = if (layer.hasGlow) Shadow(
                                    color = itemColor,
                                    offset = Offset(0f, 0f),
                                    blurRadius = layer.glowRadius
                                ) else null
                            )
                        )
                        
                        if (layer.isCurved) {
                            Text(
                                text = "~~~~~~~~~~",
                                color = itemColor.copy(alpha = 0.6f),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Bleed Limit Guides & Margin Rulers
            if (showGuides && showBleedField) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(2.dp, SignalCritical.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                ) {
                    Text(
                        text = "BLEED AREA LIMIT (3mm)",
                        color = SignalCritical,
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                    )
                }
            }

            if (showGuides && showSafeField) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(0.92f)
                        .border(1.5.dp, NeonMint.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                ) {
                    Text(
                        text = "SAFE PRINT MARGIN ZONE",
                        color = NeonMint,
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(6.dp)
                    )
                }
            }
        }
    }
}
