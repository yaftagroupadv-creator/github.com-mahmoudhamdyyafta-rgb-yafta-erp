package com.example.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class BackupPayload(
    val exportTimestamp: Long = System.currentTimeMillis(),
    val appVersion: String = "1.0-yafta-erp",
    val companySettings: List<Company>? = null,
    val userAccounts: List<User>? = null,
    val leadsAndQuotes: List<Lead>? = null,
    val projects: List<Project>? = null,
    val inventoryData: List<InventoryItem>? = null,
    val financeTransactions: List<FinanceTransaction>? = null,
    val hrTasks: List<HrTask>? = null,
    val settingsConfig: AdvancedSettings? = null
)

object BackupSerializer {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(BackupPayload::class.java)

    fun serialize(payload: BackupPayload): String {
        return adapter.indent("  ").toJson(payload)
    }

    fun deserialize(json: String): BackupPayload? {
        return adapter.fromJson(json)
    }
}
