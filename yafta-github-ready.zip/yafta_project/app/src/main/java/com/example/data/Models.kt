package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "companies")
data class Company(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val industry: String = "Advertising & Signage",
    val type: String = "Creative Agency",
    val logoUrl: String = "",
    val vatNumber: String = "VAT-99201-AR",
    val address: String = "Riyadh Creative District, Saudi Arabia"
) : Serializable

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val email: String,
    val passwordHash: String,
    val name: String,
    val role: String, // Admin, Designer, Fabricator, Installer, Sales
    val companyId: Long = 1,
    val hourlyRate: Double = 25.0
) : Serializable

@Entity(tableName = "leads")
data class Lead(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientName: String,
    val clientPhone: String,
    val companyId: Long = 1,
    val projectType: String, // "3D Neon Signboard", "Acrylic Light Box", "Flex Billboard", "LED Screen", "Creative Logo"
    val designBrief: String,
    val estimatedValue: Double,
    val status: String = "New", // "New", "Quoted", "Briefing", "Converted", "Lost"
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val leadId: Long = 0,
    val clientName: String = "Anonymous Client",
    val companyId: Long = 1,
    val status: String, // "Design Draft", "Client Approval", "Printing/Laser Cut", "Fabrication & Wiring", "Installation", "Completed"
    val dueDate: Long = System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000L, // +7 Days default
    val totalBudget: Double,
    val notes: String = "",
    val assignedDesignerId: Long = 0,
    val assignedFabricatorId: Long = 0,
    val assignedInstallerId: Long = 0,
    val widthCm: Double = 120.0,
    val heightCm: Double = 80.0,
    val primaryColorHex: String = "#00FFFF",
    val signText: String = ""
) : Serializable

@Entity(tableName = "inventory_items")
data class InventoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyId: Long = 1,
    val name: String,
    val materialType: String, // "LED", "Acrylic", "Flex", "Transformer", "Metal Profile", "Vinyl"
    val currentStock: Double, // in standard units/meters
    val minimumStockAlert: Double,
    val unitPrice: Double
) : Serializable

@Entity(tableName = "finance_transactions")
data class FinanceTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyId: Long = 1,
    val projectId: Long = 0,
    val type: String, // "Invoice Income", "Material Purchase", "Staff Salary", "Operations Cost"
    val amount: Double,
    val description: String,
    val isPaid: Boolean = false,
    val arabicRecipientName: String = "", // Crucial for Arabic PDF contracts/invoices
    val taxPercentage: Double = 15.0, // Saudi Arabia 15% Standard VAT
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "hr_tasks")
data class HrTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val projectId: Long = 0,
    val title: String,
    val taskType: String, // "Design Sketching", "Acrylic Laser Cutting", "Metal Welding", "LED Board Wiring", "Site Installation"
    val status: String = "Assigned", // "Assigned", "In Progress", "Under Review", "Completed"
    val minutesWorked: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "crm_clients")
data class CrmClient(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val email: String,
    val phone: String,
    val address: String = "",
    val organization: String = "",
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "crm_communication_logs")
data class CommunicationLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val type: String, // "Phone Call", "Email", "WhatsApp", "In-Person Meeting", "Technical Survey"
    val summary: String,
    val detail: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val agentName: String = "Staff Agent"
) : Serializable

