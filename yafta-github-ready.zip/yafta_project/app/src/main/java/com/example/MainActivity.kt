package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.AppNavigationShell
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.YaftaViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: YaftaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    AppNavigationShell(
                        viewModel = viewModel,
                        onArabicPdfPrint = { client, price, id, date, details ->
                            Toast.makeText(this, "Print Triggered for $client", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}
