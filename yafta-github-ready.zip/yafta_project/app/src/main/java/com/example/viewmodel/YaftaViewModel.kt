package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class YaftaViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    
    // Repositories
    val userRepository = UserRepository(database.userDao())
    val crmRepository = CrmRepository(database.leadDao())
    val projectRepository = ProjectRepository(database.projectDao())
    val inventoryRepository = InventoryRepository(database.inventoryDao())
    val financeRepository = FinanceRepository(database.financeDao())
    val hrRepository = HrRepository(database.hrTaskDao())
    val clientRepository = ClientRepository(database.crmClientDao(), database.communicationLogDao())
    val geminiRepository = GeminiAiRepository()

    // SharedPreferences for local configuration storage
    private val sharedPrefs = application.getSharedPreferences("yafta_settings", android.content.Context.MODE_PRIVATE)

    // Advanced Settings Management StateFlow
    private val _advancedSettings = MutableStateFlow<AdvancedSettings>(AdvancedSettings())
    val settingsState: StateFlow<AdvancedSettings> = _advancedSettings.asStateFlow()

    // Screen navigation flow session
    private val _currentSessionUser = MutableStateFlow<User?>(null)
    val currentSessionUser: StateFlow<User?> = _currentSessionUser.asStateFlow()

    // Reactive StateFlow sources
    val allStaff: StateFlow<List<User>> = userRepository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val leadsList: StateFlow<List<Lead>> = crmRepository.allLeads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val projectsList: StateFlow<List<Project>> = projectRepository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val clientsList: StateFlow<List<CrmClient>> = clientRepository.allClients
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val communicationLogsList: StateFlow<List<CommunicationLog>> = clientRepository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inventoryList: StateFlow<List<InventoryItem>> = inventoryRepository.allInventory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactionsList: StateFlow<List<FinanceTransaction>> = financeRepository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val hrTasksList: StateFlow<List<HrTask>> = hrRepository.allHrTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Load Advanced Settings on startup
        val savedSettings = sharedPrefs.getString("advanced_settings_json", null)
        if (savedSettings != null) {
            try {
                val parsed = SettingsSerializer.deserialize(savedSettings)
                if (parsed != null) {
                    _advancedSettings.value = parsed
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Auto sign-in to Yafta Administrator on initialization if no session is details, to ensure ready-to-test
        viewModelScope.launch {
            val defaultUser = User(
                email = "agency@yafta.com",
                passwordHash = "yafta",
                name = "Yafta Administrator",
                role = "Admin",
                companyId = 1
            )
            val rows = userRepository.registerUser(defaultUser)
            _currentSessionUser.value = defaultUser.copy(id = rows)
        }
    }

    // AUTH ACTIONS
    fun login(email: String, passwordHash: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val user = userRepository.loginUser(email, passwordHash)
            if (user != null) {
                _currentSessionUser.value = user
                onResult(true, "Welcome back, ${user.name}!")
            } else {
                onResult(false, "Invalid credentials or user offline fallback.")
            }
        }
    }

    fun register(email: String, passwordHash: String, name: String, role: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val checkUser = userRepository.loginUser(email, passwordHash)
            if (checkUser != null) {
                onResult(false)
            } else {
                val newId = userRepository.registerUser(
                    User(
                        email = email,
                        passwordHash = passwordHash,
                        name = name,
                        role = role,
                        companyId = 1
                    )
                )
                val newUser = User(id = newId, email = email, passwordHash = passwordHash, name = name, role = role, companyId = 1)
                _currentSessionUser.value = newUser
                onResult(true)
            }
        }
    }

    fun logout() {
        _currentSessionUser.value = null
    }

    // CRM / LEAD ACTIONS
    fun addLead(clientName: String, clientPhone: String, projectType: String, designBrief: String, estimatedValue: Double) {
        viewModelScope.launch {
            crmRepository.createLead(
                Lead(
                    clientName = clientName,
                    clientPhone = clientPhone,
                    projectType = projectType,
                    designBrief = designBrief,
                    estimatedValue = estimatedValue,
                    status = "New"
                )
            )
        }
    }

    fun updateLeadStatus(lead: Lead, status: String) {
        viewModelScope.launch {
            crmRepository.updateLead(lead.copy(status = status))
        }
    }

    fun deleteLead(leadId: Long) {
        viewModelScope.launch {
            crmRepository.deleteLead(leadId)
        }
    }

    // CRM CLIENT & COMMUNICATION LOG ACTIONS
    fun addClient(name: String, email: String, phone: String, address: String = "", organization: String = "") {
        viewModelScope.launch {
            clientRepository.createClient(
                CrmClient(
                    name = name,
                    email = email,
                    phone = phone,
                    address = address,
                    organization = organization
                )
            )
        }
    }

    fun updateClient(client: CrmClient) {
        viewModelScope.launch {
            clientRepository.updateClient(client)
        }
    }

    fun deleteClient(clientId: Long) {
        viewModelScope.launch {
            clientRepository.deleteClient(clientId)
        }
    }

    fun addCommunicationLog(clientId: Long, type: String, summary: String, detail: String = "", agentName: String = "Staff Agent") {
        viewModelScope.launch {
            clientRepository.createLog(
                CommunicationLog(
                    clientId = clientId,
                    type = type,
                    summary = summary,
                    detail = detail,
                    agentName = agentName
                )
            )
        }
    }

    fun deleteCommunicationLog(logId: Long) {
        viewModelScope.launch {
            clientRepository.deleteLog(logId)
        }
    }

    // PROJECT ACTIONS
    fun convertLeadToProject(lead: Lead, assignedDesigner: Long, assignedFabricator: Long, assignedInstaller: Long) {
        viewModelScope.launch {
            // Update lead status
            crmRepository.updateLead(lead.copy(status = "Converted"))

            // Auto-create persistent CRM client if not already present
            if (!clientsList.value.any { it.name.trim().lowercase() == lead.clientName.trim().lowercase() }) {
                clientRepository.createClient(
                    CrmClient(
                        name = lead.clientName,
                        email = "",
                        phone = lead.clientPhone,
                        organization = lead.clientName
                    )
                )
            }

            // Create project
            projectRepository.createProject(
                Project(
                    title = "Illuminated Signboard - ${lead.clientName}",
                    leadId = lead.id,
                    clientName = lead.clientName,
                    status = "Design Draft",
                    totalBudget = lead.estimatedValue,
                    notes = lead.designBrief,
                    assignedDesignerId = assignedDesigner,
                    assignedFabricatorId = assignedFabricator,
                    assignedInstallerId = assignedInstaller
                )
            )

            // Update cash forecast with Client Invoice
            financeRepository.recordTransaction(
                FinanceTransaction(
                    projectId = lead.id,
                    type = "Invoice Income",
                    amount = lead.estimatedValue,
                    description = "Creative Project Initiation - Signage for ${lead.clientName}",
                    isPaid = false,
                    arabicRecipientName = lead.clientName
                )
            )
        }
    }

    fun addCustomProject(
        title: String,
        clientName: String,
        budget: Double,
        notes: String,
        widthCm: Double,
        heightCm: Double,
        colorHex: String,
        signText: String,
        assignedDesigner: Long,
        assignedFabricator: Long,
        assignedInstaller: Long
    ) {
        viewModelScope.launch {
            val projectId = projectRepository.createProject(
                Project(
                    title = title,
                    clientName = clientName,
                    status = "Design Draft",
                    totalBudget = budget,
                    notes = notes,
                    widthCm = widthCm,
                    heightCm = heightCm,
                    primaryColorHex = colorHex,
                    signText = signText,
                    assignedDesignerId = assignedDesigner,
                    assignedFabricatorId = assignedFabricator,
                    assignedInstallerId = assignedInstaller
                )
            )

            // Auto create invoice
            financeRepository.recordTransaction(
                FinanceTransaction(
                    projectId = projectId,
                    type = "Invoice Income",
                    amount = budget,
                    description = "Design Project Agreement: $title",
                    isPaid = false,
                    arabicRecipientName = clientName
                )
            )
        }
    }

    fun updateProjectStatus(project: Project, status: String) {
        viewModelScope.launch {
            projectRepository.updateProject(project.copy(status = status))
            
            // Auto create bonus tasks for HR tracker depending on state
            val userToAssign = when (status) {
                "Client Approval", "Design Draft" -> project.assignedDesignerId
                "Printing/Laser Cut", "Fabrication & Wiring" -> project.assignedFabricatorId
                "Installation" -> project.assignedInstallerId
                else -> 0L
            }
            if (userToAssign != 0L) {
                hrRepository.assignTask(
                    HrTask(
                        userId = userToAssign,
                        projectId = project.id,
                        title = "Deploy materials for ${project.title}",
                        taskType = when (status) {
                            "Design Draft" -> "Design Sketching"
                            "Printing/Laser Cut" -> "Acrylic Laser Cutting"
                            "Fabrication & Wiring" -> "LED Board Wiring"
                            "Installation" -> "Site Installation"
                            else -> "Design Sketching"
                        },
                        status = "In Progress"
                    )
                )
            }
        }
    }

    fun deleteProject(projectId: Long) {
        viewModelScope.launch {
            projectRepository.deleteProject(projectId)
        }
    }

    // INVENTORY ACTIONS
    fun addInventoryItem(name: String, materialType: String, currentStock: Double, minimumStockAlert: Double, unitPrice: Double) {
        viewModelScope.launch {
            inventoryRepository.addInventoryItem(
                InventoryItem(
                    name = name,
                    materialType = materialType,
                    currentStock = currentStock,
                    minimumStockAlert = minimumStockAlert,
                    unitPrice = unitPrice
                )
            )
            // Register as operation cost expense
            financeRepository.recordTransaction(
                FinanceTransaction(
                    type = "Material Purchase",
                    amount = currentStock * unitPrice,
                    description = "Stock Refill: $name [${currentStock} units]",
                    isPaid = true,
                    arabicRecipientName = "Agency Warehouse"
                )
            )
        }
    }

    fun modifyInventoryQuantity(item: InventoryItem, newStock: Double) {
        viewModelScope.launch {
            inventoryRepository.updateInventoryItem(item.copy(currentStock = newStock))
        }
    }

    fun deleteInventoryItem(itemId: Long) {
        viewModelScope.launch {
            inventoryRepository.deleteInventoryItem(itemId)
        }
    }

    // FINANCE ACTIONS
    fun addTransaction(amount: Double, type: String, description: String, isPaid: Boolean, arabicRecipient: String = "") {
        viewModelScope.launch {
            financeRepository.recordTransaction(
                FinanceTransaction(
                    amount = amount,
                    type = type,
                    description = description,
                    isPaid = isPaid,
                    arabicRecipientName = arabicRecipient
                )
            )
        }
    }

    fun markTransactionPaid(transaction: FinanceTransaction) {
        viewModelScope.launch {
            financeRepository.recordTransaction(transaction.copy(isPaid = true))
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            financeRepository.deleteTransaction(id)
        }
    }

    // HR ACTIONS
    fun assignStaffTask(userId: Long, projectId: Long, title: String, type: String) {
        viewModelScope.launch {
            hrRepository.assignTask(
                HrTask(
                    userId = userId,
                    projectId = projectId,
                    title = title,
                    taskType = type,
                    status = "Assigned"
                )
            )
        }
    }

    fun completeHrTask(task: HrTask, minutes: Int) {
        viewModelScope.launch {
            hrRepository.updateTask(
                task.copy(status = "Completed", minutesWorked = minutes)
            )
            
            // Auto calculate finance pay transaction based on staff hourly rates
            val user = userRepository.getUserById(task.userId)
            if (user != null) {
                val earned = (minutes.toDouble() / 60.0) * user.hourlyRate
                financeRepository.recordTransaction(
                    FinanceTransaction(
                        type = "Staff Salary",
                        amount = earned,
                        description = "Salary payout to ${user.name} for completed creative assignment: [${task.title}]",
                        isPaid = true,
                        arabicRecipientName = user.name
                    )
                )
            }
        }
    }

    fun deleteHrTask(taskId: Long) {
        viewModelScope.launch {
            hrRepository.deleteTask(taskId)
        }
    }

    // GEMINI REAL-TIME ASSISTANCE
    private val _aiCopywritingResult = MutableStateFlow<String>("")
    val aiCopywritingResult: StateFlow<String> = _aiCopywritingResult.asStateFlow()

    private val _aiMaterialResult = MutableStateFlow<String>("")
    val aiMaterialResult: StateFlow<String> = _aiMaterialResult.asStateFlow()

    private val _aiBriefResult = MutableStateFlow<String>("")
    val aiBriefResult: StateFlow<String> = _aiBriefResult.asStateFlow()

    private val _aiIsLoading = MutableStateFlow<Boolean>(false)
    val aiIsLoading: StateFlow<Boolean> = _aiIsLoading.asStateFlow()

    fun triggerAiSlogans(projectName: String, vibe: String, signText: String) {
        viewModelScope.launch {
            _aiIsLoading.value = true
            _aiCopywritingResult.value = geminiRepository.generateCreativeCopy(projectName, vibe, signText)
            _aiIsLoading.value = false
        }
    }

    fun triggerAiMaterials(widthCm: Double, heightCm: Double, lettersCount: Int, material: String) {
        viewModelScope.launch {
            _aiIsLoading.value = true
            _aiMaterialResult.value = geminiRepository.generateMaterialAdvisor(widthCm, heightCm, lettersCount, material)
            _aiIsLoading.value = false
        }
    }

    fun triggerAiBriefOutline(rawNotes: String) {
        viewModelScope.launch {
            _aiIsLoading.value = true
            _aiBriefResult.value = geminiRepository.refineBriefIntoOutline(rawNotes)
            _aiIsLoading.value = false
        }
    }

    private val _aiStudioResult = MutableStateFlow<String>("")
    val aiStudioResult: StateFlow<String> = _aiStudioResult.asStateFlow()

    fun triggerAiStudioAction(prompt: String) {
        viewModelScope.launch {
            _aiIsLoading.value = true
            _aiStudioResult.value = geminiRepository.getAiDesignAdvice(prompt)
            _aiIsLoading.value = false
        }
    }

    fun updateSettings(newSettings: AdvancedSettings) {
        _advancedSettings.value = newSettings
        viewModelScope.launch {
            try {
                val json = SettingsSerializer.serialize(newSettings)
                sharedPrefs.edit().putString("advanced_settings_json", json).apply()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun createBackupPayload(
        includeCompanyColors: Boolean,
        includeUsers: Boolean,
        includeLeads: Boolean,
        includeProjects: Boolean,
        includeInventory: Boolean,
        includeFinance: Boolean,
        includeHr: Boolean,
        includeSettings: Boolean
    ): BackupPayload {
        val companies = if (includeCompanyColors) database.companyDao().getAllCompanies().firstOrNull() else null
        val users = if (includeUsers) database.userDao().getAllUsers().firstOrNull() else null
        val leads = if (includeLeads) database.leadDao().getAllLeads().firstOrNull() else null
        val projects = if (includeProjects) database.projectDao().getAllProjects().firstOrNull() else null
        val inventory = if (includeInventory) database.inventoryDao().getAllInventory().firstOrNull() else null
        val finance = if (includeFinance) database.financeDao().getAllTransactions().firstOrNull() else null
        val hr = if (includeHr) database.hrTaskDao().getAllTasks().firstOrNull() else null
        val settings = if (includeSettings) _advancedSettings.value else null

        return BackupPayload(
            exportTimestamp = System.currentTimeMillis(),
            companySettings = companies,
            userAccounts = users,
            leadsAndQuotes = leads,
            projects = projects,
            inventoryData = inventory,
            financeTransactions = finance,
            hrTasks = hr,
            settingsConfig = settings
        )
    }

    suspend fun restoreBackup(
        payload: BackupPayload,
        restoreSettings: Boolean = true,
        restoreBusinessData: Boolean = true
    ) {
        if (restoreSettings) {
            payload.settingsConfig?.let {
                updateSettings(it)
            }
            payload.companySettings?.let { companies ->
                if (companies.isNotEmpty()) {
                    database.companyDao().clearAllCompanies()
                    database.companyDao().insertCompanies(companies)
                }
            }
        }

        if (restoreBusinessData) {
            payload.userAccounts?.let { users ->
                if (users.isNotEmpty()) {
                    database.userDao().clearAllUsers()
                    database.userDao().insertUsers(users)
                }
            }
            payload.leadsAndQuotes?.let { leads ->
                if (leads.isNotEmpty()) {
                    database.leadDao().clearAllLeads()
                    database.leadDao().insertLeads(leads)
                }
            }
            payload.projects?.let { projects ->
                if (projects.isNotEmpty()) {
                    database.projectDao().clearAllProjects()
                    database.projectDao().insertProjects(projects)
                }
            }
            payload.inventoryData?.let { items ->
                if (items.isNotEmpty()) {
                    database.inventoryDao().clearAllInventory()
                    database.inventoryDao().insertInventory(items)
                }
            }
            payload.financeTransactions?.let { transactions ->
                if (transactions.isNotEmpty()) {
                    database.financeDao().clearAllTransactions()
                    database.financeDao().insertTransactions(transactions)
                }
            }
            payload.hrTasks?.let { tasks ->
                if (tasks.isNotEmpty()) {
                    database.hrTaskDao().clearAllTasks()
                    database.hrTaskDao().insertTasks(tasks)
                }
            }
        }

        val currentUserEmail = _currentSessionUser.value?.email
        if (currentUserEmail != null) {
            val user = database.userDao().getUserByEmail(currentUserEmail)
            if (user != null) {
                _currentSessionUser.value = user
            }
        }
    }
}
