package com.example.ui.screens

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.text.DateFormat
import java.util.Date
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreenLayout(viewModel: YaftaViewModel) {
    val projects by viewModel.projectsList.collectAsState()
    val staff by viewModel.allStaff.collectAsState()
    val transactions by viewModel.transactionsList.collectAsState()
    val context = LocalContext.current

    var showAddProjectDialog by remember { mutableStateOf(false) }

    // Add Custom Project Form States
    var title by remember { mutableStateOf("") }
    var clientName by remember { mutableStateOf("") }
    var budget by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var widthCm by remember { mutableStateOf("120") }
    var heightCm by remember { mutableStateOf("80") }
    var signText by remember { mutableStateOf("") }
    var colorHex by remember { mutableStateOf("#00E5FF") } // Default neon cyan

    var selectedDesignerId by remember { mutableStateOf(0L) }
    var selectedFabricatorId by remember { mutableStateOf(0L) }
    var selectedInstallerId by remember { mutableStateOf(0L) }

    val constructionStages = listOf(
        "Design Draft",
        "Client Approval",
        "Printing/Laser Cut",
        "Fabrication & Wiring",
        "Installation",
        "Completed"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .padding(24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Signboard Engineering Workshop",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = BrushedTitanium
                        )
                    )
                    Text(
                        text = "${projects.filter { it.status != "Completed" }.size} Active illuminated signs being fabricated",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSilver
                    )
                }

                Button(
                    onClick = {
                        // Reset and autofill defaults for easy testing
                        showAddProjectDialog = true
                        val designers = staff.filter { it.role == "Designer" }
                        val fabricators = staff.filter { it.role == "Fabricator" }
                        val installers = staff.filter { it.role == "Installer" }
                        if (designers.isNotEmpty()) selectedDesignerId = designers.first().id
                        if (fabricators.isNotEmpty()) selectedFabricatorId = fabricators.first().id
                        if (installers.isNotEmpty()) selectedInstallerId = installers.first().id
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = null, tint = DeepSlateBg)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Sign Order", fontWeight = FontWeight.Bold, color = DeepSlateBg)
                }
            }

            if (projects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Filled.SquareFoot, contentDescription = null, tint = TextSilver, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No Signboards currently in active fabrication.", color = TextSilver, fontWeight = FontWeight.Bold)
                        Text("Create a lead in CRM or tap New Sign Order above to initialize structural layouts.", color = TextSilver, fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(projects, key = { it.id }) { project ->
                        ProjectCard(
                            project = project,
                            staffList = staff,
                            transactions = transactions,
                            onUpdateStatus = { nextStatus ->
                                viewModel.updateProjectStatus(project, nextStatus)
                                Toast.makeText(context, "Signboard status updated to: $nextStatus", Toast.LENGTH_SHORT).show()
                            },
                            onDelete = { viewModel.deleteProject(project.id) }
                        )
                    }
                }
            }
        }

        // ADD PROJECT DIALOG
        if (showAddProjectDialog) {
            val designers = staff.filter { it.role == "Designer" }
            val fabricators = staff.filter { it.role == "Fabricator" }
            val installers = staff.filter { it.role == "Installer" }

            AlertDialog(
                onDismissRequest = { showAddProjectDialog = false },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Client Commission Form", color = BrushedTitanium, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("Signboard Identifier (e.g., Cool RGB Logo)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientName,
                            onValueChange = { clientName = it },
                            label = { Text("Client Name", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = budget,
                            onValueChange = { budget = it },
                            label = { Text("Project Settle Price ($)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = widthCm,
                                onValueChange = { widthCm = it },
                                label = { Text("Width (cm)", color = TextSilver) },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = heightCm,
                                onValueChange = { heightCm = it },
                                label = { Text("Height (cm)", color = TextSilver) },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = signText,
                            onValueChange = { signText = it },
                            label = { Text("Text Written on Signboard (e.g. CAFE)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Saturated accent highlighter picker options
                        Text("Branding Acrylic Highlight Tone:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val neonColors = listOf("#00E5FF", "#BF80FF", "#FFFF00", "#FF007F")
                            neonColors.forEach { hex ->
                                val isSelected = colorHex == hex
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(android.graphics.Color.parseColor(hex)))
                                        .border(2.dp, if (isSelected) BrushedTitanium else Color.Transparent, CircleShape)
                                        .clickable { colorHex = hex }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Branding specifications", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Manual Staff assignments pickers
                        Text("Assign Designers and Fabricators:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (designers.isNotEmpty()) {
                            Text("Creator Designer:", color = TextSilver, fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                designers.forEach { d ->
                                    val checked = selectedDesignerId == d.id
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (checked) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                            .border(1.dp, if (checked) NeonPurple else Color.Transparent, RoundedCornerShape(6.dp))
                                            .clickable { selectedDesignerId = d.id }
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(d.name, color = if (checked) NeonPurple else TextSilver, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val price = budget.toDoubleOrNull()
                            val width = widthCm.toDoubleOrNull() ?: 120.0
                            val height = heightCm.toDoubleOrNull() ?: 80.0
                            if (title.isEmpty() || price == null) {
                                Toast.makeText(context, "Identifier and numeric settle price required.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addCustomProject(
                                title = title,
                                clientName = clientName.ifEmpty { "Anonymous Client" },
                                budget = price,
                                notes = notes,
                                widthCm = width,
                                heightCm = height,
                                colorHex = colorHex,
                                signText = signText,
                                assignedDesigner = if (selectedDesignerId == 0L) 1L else selectedDesignerId,
                                assignedFabricator = if (selectedFabricatorId == 0L) 1L else selectedFabricatorId,
                                assignedInstaller = if (selectedInstallerId == 0L) 1L else selectedInstallerId
                            )
                            showAddProjectDialog = false
                            // Reset
                            title = ""
                            clientName = ""
                            budget = ""
                            notes = ""
                            signText = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Add sign order", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddProjectDialog = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }
    }
}

@Composable
fun ProjectCard(
    project: Project,
    staffList: List<User>,
    transactions: List<FinanceTransaction> = emptyList(),
    onUpdateStatus: (String) -> Unit,
    onDelete: () -> Unit
) {
    val constructionStages = listOf(
        "Design Draft",
        "Client Approval",
        "Printing/Laser Cut",
        "Fabrication & Wiring",
        "Installation",
        "Completed"
    )

    // Match assigned staffs
    val designer = staffList.find { it.id == project.assignedDesignerId }?.name ?: "Senior Partner"
    val fabricator = staffList.find { it.id == project.assignedFabricatorId }?.name ?: "Welding Team"
    val installer = staffList.find { it.id == project.assignedInstallerId }?.name ?: "Delivery Mount Crew"

    val statusColor = when (project.status) {
        "Design Draft" -> NeonPurple
        "Client Approval" -> NeonMint
        "Printing/Laser Cut" -> NeonCyan
        "Fabrication & Wiring" -> NeonAmber
        "Installation" -> SignalCritical
        "Completed" -> NeonMint
        else -> TextSilver
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateCard)
            .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = project.title,
                        fontWeight = FontWeight.Black,
                        color = BrushedTitanium,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "Client: ${project.clientName}  |  Commission: $${project.totalBudget}",
                        color = TextSilver,
                        fontSize = 12.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .border(1.dp, statusColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = project.status,
                        color = statusColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Technical Specs Block
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DeepSlateBg)
                    .border(2.dp, Color(android.graphics.Color.parseColor(project.primaryColorHex)).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Glow Dot indicators
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(Color(android.graphics.Color.parseColor(project.primaryColorHex)))
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "ILLUMINATION TEXT: \"${project.signText.ifEmpty { "[No Text Defined]" }}\"",
                        color = Color(android.graphics.Color.parseColor(project.primaryColorHex)),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Dimensions: ${project.widthCm}cm x ${project.heightCm}cm | Backbone spec: Acrylic & Neon wiring",
                        color = TextSilver,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Staff Assignments
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Designer", color = TextSilver, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(designer, color = BrushedTitanium, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Laser Welder", color = TextSilver, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(fabricator, color = BrushedTitanium, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Installs Lead", color = TextSilver, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(installer, color = BrushedTitanium, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            if (project.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Special Directives: ${project.notes}",
                    color = TextSilver,
                    fontSize = 12.sp
                )
            }

            val context = LocalContext.current
            if (project.status == "Completed") {
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = {
                        generateAndPrintProjectInvoice(context, project, staffList, transactions)
                    },
                    modifier = Modifier.fillMaxWidth().height(42.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonMint.copy(alpha = 0.15f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonMint.copy(alpha = 0.8f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Description,
                        contentDescription = "PDF Invoice",
                        tint = NeonMint,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GENERATE TAX INVOICE (PDF)",
                        color = NeonMint,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(12.dp))

            // PIPELINE MOVER STATS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MOVE STAGE:",
                    color = TextSilver,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 11.sp
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val currentIndex = constructionStages.indexOf(project.status)
                    
                    // Button decrement
                    IconButton(
                        onClick = {
                            if (currentIndex > 0) {
                                onUpdateStatus(constructionStages[currentIndex - 1])
                            }
                        },
                        enabled = currentIndex > 0,
                        modifier = Modifier
                            .size(32.dp)
                            .background(BorderGlass, CircleShape)
                    ) {
                        Icon(imageVector = Icons.Filled.ChevronLeft, contentDescription = null, tint = if (currentIndex > 0) BrushedTitanium else BorderGlass, modifier = Modifier.size(16.dp))
                    }

                    // Button increment
                    IconButton(
                        onClick = {
                            if (currentIndex < constructionStages.size - 1) {
                                onUpdateStatus(constructionStages[currentIndex + 1])
                            }
                        },
                        enabled = currentIndex < constructionStages.size - 1,
                        modifier = Modifier
                            .size(32.dp)
                            .background(BorderGlass, CircleShape)
                    ) {
                        Icon(imageVector = Icons.Filled.ChevronRight, contentDescription = null, tint = if (currentIndex < constructionStages.size - 1) NeonCyan else BorderGlass, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = onDelete) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription = "Trash", tint = SignalCritical)
                    }
                }
            }
        }
    }
}

// 100% REAL NATIVE PRINT SERVICE ARABIC/ENGLISH SIGNAGE INVOICE GENERATOR
fun generateAndPrintProjectInvoice(
    context: Context,
    project: Project,
    staffList: List<User>,
    transactions: List<FinanceTransaction>
) {
    val totalBudget = project.totalBudget
    val baseAmount = totalBudget / 1.15
    val vatAmount = totalBudget - baseAmount

    // Proportional breakdown: 20% Design & Engineering, 50% Acrylic Materials & Neon Fab, 30% Site Mounting & Wiring
    val baseDesign = baseAmount * 0.20
    val vatDesign = baseDesign * 0.15
    val totalDesign = baseDesign + vatDesign

    val baseFab = baseAmount * 0.50
    val vatFab = baseFab * 0.15
    val totalFab = baseFab + vatFab

    val baseInstall = baseAmount * 0.30
    val vatInstall = baseInstall * 0.15
    val totalInstall = baseInstall + vatInstall

    val currentFormattedDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(System.currentTimeMillis()))

    val designer = staffList.find { it.id == project.assignedDesignerId }?.name ?: "Senior Partner"
    val fabricator = staffList.find { it.id == project.assignedFabricatorId }?.name ?: "Welded Structure Team"
    val installer = staffList.find { it.id == project.assignedInstallerId }?.name ?: "Logistics Delivery Mount Crew"

    val htmlDoc = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>فاتورة تصنيع لوحة إعلانية - وكالة يافطة</title>
            <style>
                body {
                    font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
                    background-color: #FFFFFF;
                    color: #0F172A;
                    padding: 30px;
                    margin: 0;
                    line-height: 1.5;
                    direction: rtl;
                }
                .header-container {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    border-bottom: 3px double #8B5CF6;
                    padding-bottom: 20px;
                    margin-bottom: 25px;
                }
                .company-logo {
                    text-align: right;
                }
                .company-logo h1 {
                    margin: 0;
                    font-size: 26px;
                    color: #8B5CF6;
                    font-weight: 800;
                    letter-spacing: -0.5px;
                }
                .company-logo p {
                    margin: 3px 0 0 0;
                    font-size: 13px;
                    color: #475569;
                    font-weight: 500;
                }
                .meta-invoice {
                    text-align: left;
                    font-size: 13px;
                    color: #1E293B;
                    direction: ltr;
                }
                .meta-invoice p {
                    margin: 4px 0;
                }
                .meta-invoice strong {
                    color: #8B5CF6;
                }
                .invoice-title-bar {
                    background-color: #F8FAFC;
                    border-top: 2px solid #8B5CF6;
                    border-right: 4px solid #8B5CF6;
                    padding: 15px;
                    margin-bottom: 25px;
                    border-radius: 4px;
                    text-align: right;
                }
                .invoice-title-bar h2 {
                    margin: 0;
                    font-size: 18px;
                    color: #1E293B;
                    font-weight: 700;
                }
                .invoice-title-bar p {
                    margin: 5px 0 0 0;
                    font-size: 12px;
                    color: #64748B;
                }
                .details-grid {
                    display: table;
                    width: 100%;
                    margin-bottom: 30px;
                    background: #F8FAFC;
                    border-radius: 8px;
                    border: 1px solid #E2E8F0;
                    border-collapse: separate;
                }
                .grid-row {
                    display: table-row;
                }
                .grid-column {
                    display: table-cell;
                    width: 50%;
                    padding: 18px;
                    font-size: 13px;
                    vertical-align: top;
                    text-align: right;
                }
                .grid-column h4 {
                    margin: 0 0 8px 0;
                    color: #475569;
                    font-size: 12px;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    border-bottom: 1px solid #E2E8F0;
                    padding-bottom: 4px;
                }
                .grid-column p {
                    margin: 5px 0;
                    color: #0F172A;
                }
                .spec-badge {
                    display: inline-block;
                    padding: 2px 8px;
                    background: #EDE9FE;
                    color: #7C3AED;
                    border-radius: 4px;
                    font-weight: bold;
                    font-size: 11px;
                }
                .color-preview-box {
                    display: inline-block;
                    width: 12px;
                    height: 12px;
                    border-radius: 50%;
                    vertical-align: middle;
                    margin-right: 5px;
                    margin-left: 5px;
                    border: 1px solid #CBD5E1;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                    margin-bottom: 25px;
                    font-size: 13px;
                }
                th {
                    background-color: #8B5CF6;
                    color: #FFFFFF;
                    padding: 12px;
                    font-weight: 600;
                    text-align: right;
                    border: 1px solid #8B5CF6;
                }
                td {
                    border: 1px solid #E2E8F0;
                    padding: 12px;
                    text-align: right;
                    color: #334155;
                }
                tr:nth-child(even) td {
                    background-color: #F8FAFC;
                }
                .totals-container {
                    width: 100%;
                    margin-top: 20px;
                    display: table;
                }
                .totals-row {
                    display: table-row;
                }
                .directives-col {
                    display: table-cell;
                    width: 55%;
                    vertical-align: top;
                    padding-left: 20px;
                    text-align: right;
                }
                .summary-col {
                    display: table-cell;
                    width: 45%;
                    vertical-align: top;
                    font-size: 13px;
                    border-top: 2px solid #E2E8F0;
                    padding-top: 10px;
                }
                .summary-row {
                    display: flex;
                    justify-content: space-between;
                    padding: 5px 0;
                    direction: ltr;
                }
                .summary-row span {
                    direction: rtl;
                }
                .summary-row.total {
                    font-weight: bold;
                    font-size: 16px;
                    color: #8B5CF6;
                    border-top: 1px solid #E2E8F0;
                    padding-top: 10px;
                    margin-top: 5px;
                }
                .directives-box {
                    border: 1px dashed #BF80FF;
                    background-color: #FAF5FF;
                    border-radius: 8px;
                    padding: 15px;
                    margin-left: 20px;
                    text-align: right;
                }
                .directives-box h4 {
                    margin: 0 0 6px 0;
                    color: #701A75;
                }
                .footer-banner {
                    text-align: center;
                    margin-top: 50px;
                    padding-top: 15px;
                    border-top: 1px dashed #E2E8F0;
                    font-size: 11px;
                    color: #64748B;
                }
            </style>
        </head>
        <body>
            <div class="header-container" style="direction: ltr;">
                <div class="company-logo" style="text-align: left;">
                    <h1 style="color: #8B5CF6;">وكالة يافطة لتصنيع اللوحات والواجهات</h1>
                    <p style="color: #475569;">YAFTA SIGNBOARD ENGINEERING & ADS AGENCY</p>
                </div>
                <div class="meta-invoice">
                    <p><strong>Invoice Ref:</strong> INV-${project.id}</p>
                    <p><strong>VAT Number:</strong> 300187429100003</p>
                    <p><strong>Date / التاريخ:</strong> ${currentFormattedDate}</p>
                </div>
            </div>

            <div class="invoice-title-bar">
                <h2>فاتورة ضريبية مبسطة (مشروع هندسي مكتمل)</h2>
                <p>SIMPLIFIED TAX INVOICE (COMPLETED SIGNAGE COMMISSION)</p>
            </div>

            <div class="details-grid">
                <div class="grid-row">
                    <div class="grid-column" style="border-left: 1px solid #E2E8F0;">
                        <h4>العميل المفوتر / Customer Details</h4>
                        <p><b>اسم العميل / Customer Name:</b> ${project.clientName}</p>
                        <p><b>حالة الملف / Project State:</b> Completed / مكتمل</p>
                        <p><b>وقت التسليم / Handover On:</b> ${currentFormattedDate}</p>
                    </div>
                    <div class="grid-column">
                        <h4>المواصفات الفنية للوحة / Signboard Technical Specifications</h4>
                        <p><b>اسم المشروع / Commission:</b> ${project.title}</p>
                        <p><b>كود الهيكل / Structural Specs:</b> Custom Acrylic & LED Neon Channel Mount</p>
                        <p><b>الأبعاد / Size:</b> ${project.widthCm} cm x ${project.heightCm} cm</p>
                        <p><b>النص المضيء / Sign Text:</b> "${project.signText.ifEmpty { "[None Specified]" }}"</p>
                        <p><b>لون الإضاءة / Neon Tint:</b> 
                            <span class="color-preview-box" style="background-color: ${project.primaryColorHex};"></span>
                            <span class="spec-badge">${project.primaryColorHex}</span>
                        </p>
                        <p><b>طاقم الإنتاج / Crew Assigned:</b> ${designer} (Design), ${fabricator} (Welder), ${installer} (Installs)</p>
                    </div>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th style="width: 5%; color: white; background-color: #8B5CF6; border: 1px solid #8B5CF6; padding: 10px;">#</th>
                        <th style="width: 50%; color: white; background-color: #8B5CF6; border: 1px solid #8B5CF6; padding: 10px;">تفاصيل الأعمال والخدمات / Settle Itemization & Engineering Services</th>
                        <th style="width: 15%; color: white; background-color: #8B5CF6; border: 1px solid #8B5CF6; padding: 10px;">المبلغ الأساسي / Base Amt</th>
                        <th style="width: 15%; color: white; background-color: #8B5CF6; border: 1px solid #8B5CF6; padding: 10px;">ضريبة القيمة المضافة 15% / VAT 15%</th>
                        <th style="width: 15%; color: white; background-color: #8B5CF6; border: 1px solid #8B5CF6; padding: 10px;">المجموع الكلي / Line Total</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>
                            <b>التصميم الهندسي الأولي والمراجعة الفنية CAD</b>
                            <br><span style="font-size: 11px; color: #64748B;">Industrial Layout design & technical CAD modeling for neon placement.</span>
                        </td>
                        <td>$${String.format("%.2f", baseDesign)}</td>
                        <td>$${String.format("%.2f", vatDesign)}</td>
                        <td>$${String.format("%.2f", totalDesign)}</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>
                            <b>قص الإكريليك بالليزر وهيكل الحديد وتمديدات النيون واللوحة الخلفية</b>
                            <br><span style="font-size: 11px; color: #64748B;">CNC acrylic router cutting, profile frame welding & high-glow LED installation.</span>
                        </td>
                        <td>$${String.format("%.2f", baseFab)}</td>
                        <td>$${String.format("%.2f", vatFab)}</td>
                        <td>$${String.format("%.2f", totalFab)}</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>
                            <b>التركيب الميداني، تدعيم الحوامل واختبار السلامة الكهربائية للوحة</b>
                            <br><span style="font-size: 11px; color: #64748B;">On-site scaffold loading, concrete anchors, transformer wiring & testing.</span>
                        </td>
                        <td>$${String.format("%.2f", baseInstall)}</td>
                        <td>$${String.format("%.2f", vatInstall)}</td>
                        <td>$${String.format("%.2f", totalInstall)}</td>
                    </tr>
                </tbody>
            </table>

            <div class="totals-container">
                <div class="totals-row">
                    <div class="directives-col">
                        ${if (project.notes.isNotEmpty()) """
                        <div class="directives-box">
                            <h4>توجيهات فنية خاصة / Special Engineering Notes:</h4>
                            <p>${project.notes}</p>
                        </div>
                        """ else ""}
                    </div>
                    <div class="summary-col">
                        <div class="summary-row">
                            <span>$${String.format("%.2f", baseAmount)}</span>
                            <span>المبلغ الخاضع للضريبة / Taxable Amount:</span>
                        </div>
                        <div class="summary-row">
                            <span>$${String.format("%.2f", vatAmount)}</span>
                            <span>مجموع ضريبة القيمة المضافة (15%) / VAT Total:</span>
                        </div>
                        <div class="summary-row total">
                            <span>$${String.format("%.2f", project.totalBudget)}</span>
                            <span>المجموع النهائي شامل الضريبة / Settle Total:</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-banner">
                <p>تم سداد هذه الفاتورة بالكامل لموافاتها لمرحلة التسليم النهائي للمشروع. يافطة للدعاية والإعلان.</p>
                <p>Yafta for Signboards and Facades 100% Digital Workstation | Riyadh, Saudi Arabia | info@yafta.com</p>
            </div>
        </body>
        </html>
    """.trimIndent()

    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            try {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val printAdapter = webView.createPrintDocumentAdapter("Yafta_Invoice_${project.id}")
                val jobName = "Yafta_Sign_Invoice_${project.id}"
                printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
            } catch (e: Exception) {
                Toast.makeText(context, "Error printing: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    webView.loadDataWithBaseURL(null, htmlDoc, "text/html", "UTF-8", null)
}
