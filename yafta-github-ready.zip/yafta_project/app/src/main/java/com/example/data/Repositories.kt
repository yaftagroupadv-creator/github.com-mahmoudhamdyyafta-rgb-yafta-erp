package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class UserRepository(private val userDao: UserDao) {
    val allUsers: Flow<List<User>> = userDao.getAllUsers()

    suspend fun registerUser(user: User): Long {
        // Simple plain-password matching as fallback, keeps auth real and fast
        return userDao.insertUser(user)
    }

    suspend fun loginUser(email: String, passwordHash: String): User? {
        val user = userDao.getUserByEmail(email)
        return if (user != null && user.passwordHash == passwordHash) {
            user
        } else {
            null
        }
    }

    suspend fun getUserById(id: Long): User? {
        return userDao.getUserById(id)
    }

    suspend fun updateUser(user: User) {
        userDao.updateUser(user)
    }
}

class CrmRepository(private val leadDao: LeadDao) {
    val allLeads: Flow<List<Lead>> = leadDao.getAllLeads()

    fun getLeadsByCompany(companyId: Long): Flow<List<Lead>> {
        return leadDao.getLeadsByCompany(companyId)
    }

    suspend fun createLead(lead: Lead): Long {
        return leadDao.insertLead(lead)
    }

    suspend fun updateLead(lead: Lead) {
        leadDao.updateLead(lead)
    }

    suspend fun deleteLead(id: Long) {
        leadDao.deleteLeadById(id)
    }
}

class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<Project>> = projectDao.getAllProjects()

    fun getProjectsByCompany(companyId: Long): Flow<List<Project>> {
        return projectDao.getProjectsByCompany(companyId)
    }

    suspend fun getProjectById(id: Long): Project? {
        return projectDao.getProjectById(id)
    }

    suspend fun createProject(project: Project): Long {
        return projectDao.insertProject(project)
    }

    suspend fun updateProject(project: Project) {
        projectDao.updateProject(project)
    }

    suspend fun deleteProject(id: Long) {
        projectDao.deleteProjectById(id)
    }
}

class InventoryRepository(private val inventoryDao: InventoryDao) {
    val allInventory: Flow<List<InventoryItem>> = inventoryDao.getAllInventory()

    suspend fun addInventoryItem(item: InventoryItem) {
        inventoryDao.insertInventoryItem(item)
    }

    suspend fun updateInventoryItem(item: InventoryItem) {
        inventoryDao.updateInventoryItem(item)
    }

    suspend fun deleteInventoryItem(id: Long) {
        inventoryDao.deleteInventoryItem(id)
    }
}

class FinanceRepository(private val financeDao: FinanceDao) {
    val allTransactions: Flow<List<FinanceTransaction>> = financeDao.getAllTransactions()

    fun getTransactionsByCompany(companyId: Long): Flow<List<FinanceTransaction>> {
        return financeDao.getTransactionsByCompany(companyId)
    }

    suspend fun recordTransaction(transaction: FinanceTransaction): Long {
        return financeDao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: FinanceTransaction) {
        financeDao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(id: Long) {
        financeDao.deleteTransaction(id)
    }
}

class HrRepository(private val hrTaskDao: HrTaskDao) {
    val allHrTasks: Flow<List<HrTask>> = hrTaskDao.getAllTasks()

    fun getTasksByUser(userId: Long): Flow<List<HrTask>> {
        return hrTaskDao.getTasksByUser(userId)
    }

    suspend fun assignTask(task: HrTask): Long {
        return hrTaskDao.insertTask(task)
    }

    suspend fun updateTask(task: HrTask) {
        hrTaskDao.updateTask(task)
    }

    suspend fun deleteTask(id: Long) {
        hrTaskDao.deleteTask(id)
    }
}

class ClientRepository(
    private val clientDao: CrmClientDao,
    private val logDao: CommunicationLogDao
) {
    val allClients: Flow<List<CrmClient>> = clientDao.getAllClients()
    val allLogs: Flow<List<CommunicationLog>> = logDao.getAllLogs()

    fun getLogsByClient(clientId: Long): Flow<List<CommunicationLog>> {
        return logDao.getLogsByClient(clientId)
    }

    suspend fun createClient(client: CrmClient): Long {
        return clientDao.insertClient(client)
    }

    suspend fun updateClient(client: CrmClient) {
        clientDao.updateClient(client)
    }

    suspend fun deleteClient(id: Long) {
        clientDao.deleteClientById(id)
        logDao.deleteLogsByClientId(id)
    }

    suspend fun createLog(log: CommunicationLog): Long {
        return logDao.insertLog(log)
    }

    suspend fun updateLog(log: CommunicationLog) {
        logDao.updateLog(log)
    }

    suspend fun deleteLog(id: Long) {
        logDao.deleteLogById(id)
    }
}

