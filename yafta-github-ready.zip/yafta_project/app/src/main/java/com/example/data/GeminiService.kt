package com.example.data

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

// Moshi data classes instead of kotlinx.serialization to match converter.moshi in build.gradle
@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-2.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiNetworkClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

class GeminiAiRepository {
    suspend fun generateCreativeCopy(projectName: String, vibe: String, signText: String): String = withContext(Dispatchers.IO) {
        val prompt = """
            You are a senior creative copywriter at "Yafta" - a premium advertising and signboard branding agency in Riyadh.
            Develop 3 snappy, highly-impactful, bilingual (Arabic & English) marketing slogans or visual headliners for a $vibe business brand.
            Project Name: "$projectName".
            Text written on the signboard: "$signText".
            Make sure the taglines feel high-end, premium, creative, and fit for stunning lighted neon boards in public districts!
            Format the response clearly with bullet points.
        """.trimIndent()

        callGemini(prompt)
    }

    suspend fun generateMaterialAdvisor(widthCm: Double, heightCm: Double, lettersCount: Int, primaryMaterial: String): String = withContext(Dispatchers.IO) {
        val prompt = """
            You are a senior structure and fabrication engineer for outdoor signboards at "Yafta" production factory.
            Provide professional, direct material estimations and wiring instructions for a $primaryMaterial signboard.
            Sizing: Width = $widthCm cm, Height = $heightCm cm.
            Number of illuminated letters: $lettersCount letters.
            Detail:
            1. Estimated number of 12V LED modules or meters of neon flex wire required.
            2. Estimated power transformer capacity (in Watts) needed, keeping a 20% safety buffer.
            3. Essential metal profile length (meters) for framing.
            4. Advice on acrylic depth (e.g. 3mm vs 5mm) and recommendations for outdoor wind resistance.
            Keep the content highly structured and professional, styled as an engineering worksheet list.
        """.trimIndent()

        callGemini(prompt)
    }

    suspend fun refineBriefIntoOutline(rawBrief: String): String = withContext(Dispatchers.IO) {
        val prompt = """
            You are a creative brand director at Yafta Agency.
            Refine this crude client signboard brief into a professional agency-ready design specification:
            
            Raw Brief: "$rawBrief"
            
            Structure your response as:
            - Brand Visual Concept Description
            - Suggested Lighting Style (e.g., Backlit Halo, Front-Lit Acrylic, Raw Custom Neon Strip)
            - Color Palette & Aesthetic Energy
            - Manufacturing Step Recommendations
        """.trimIndent()

        callGemini(prompt)
    }

    suspend fun getAiDesignAdvice(prompt: String): String = withContext(Dispatchers.IO) {
        callGemini(prompt)
    }

    private suspend fun callGemini(prompt: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return "Note: Gemini API key has not been configured in the Secrets panel yet.\n\nRecommended concept draft: Standard premium advertising layout with neon backlit illumination and brushed titanium structures."
        }
        val request = GeminiRequest(
            contents = listOf(GeminiContent(
                parts = listOf(GeminiPart(text = prompt))
            ))
        )
        return try {
            val response = GeminiNetworkClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "No suggestions retrieved. Please verify your prompt content."
        } catch (e: Exception) {
            "API Simulation Fallback: Highly luminous acrylic signboard with brushed black aluminium framing and custom warm-white halo LED backlight tubes.\n(Error: ${e.localizedMessage})"
        }
    }
}
