package com.example.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class AdvancedSettings(
    val measurementUnit: String = "cm", // "mm", "cm", "inch", "px"
    val canvasWidth: Double = 120.0,
    val canvasHeight: Double = 80.0,
    val dpi: Int = 300, // 72 to 600+
    val colorMode: String = "RGB", // "RGB", "CMYK"
    val zoomLevel: Float = 1.0f,
    val rulersEnabled: Boolean = true,
    val guidesEnabled: Boolean = true,
    val gridEnabled: Boolean = true,
    val safeAreaEnabled: Boolean = true,
    val safeAreaMarginPercentage: Float = 5.0f,
    val bleedAreaEnabled: Boolean = true,
    val bleedAreaMarginCm: Double = 1.5,
    val cropMarksEnabled: Boolean = true,
    val printMarginLeft: Double = 2.0,
    val printMarginRight: Double = 2.0,
    val printMarginTop: Double = 2.0,
    val printMarginBottom: Double = 2.0,
    // Layer and object names
    val layerNames: List<String> = listOf("Neon Frame Outline", "LED Light Core", "Background Backing Board"),
    val layerVisibility: Map<String, Boolean> = mapOf(
        "Neon Frame Outline" to true,
        "LED Light Core" to true,
        "Background Backing Board" to true
    ),
    val logoPlacement: String = "Top-Left", // "Top-Left", "Top-Right", "Bottom-Left", "Bottom-Right", "None"
    val logoScale: Float = 1.0f,
    val watermarkText: String = "YAFTA DESIGN STUDIO",
    val watermarkOpacity: Float = 0.2f,
    val themeMode: String = "Dark Cosmic", // "Dark Cosmic", "Classic Slate", "High-Contrast"
    val uiLanguage: String = "English", // "English", "Arabic", "French"
    val displayFontFamily: String = "Roboto", // "Roboto", "Sans Serif", "Monospace", "Space Grotesk"
    val devicePreference: String = "Auto", // "Phone", "Tablet", "Auto"
    val reportsMainCategory: String = "Performance",
    val reportsVisualAesthetic: String = "Neon Gradient Grid",
    val dashboardRefreshIntervalMs: Int = 5000,
    val showQuickLaunchSection: Boolean = true
)

object SettingsSerializer {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(AdvancedSettings::class.java)

    fun serialize(settings: AdvancedSettings): String {
        return adapter.toJson(settings)
    }

    fun deserialize(json: String): AdvancedSettings? {
        return adapter.fromJson(json)
    }
}
