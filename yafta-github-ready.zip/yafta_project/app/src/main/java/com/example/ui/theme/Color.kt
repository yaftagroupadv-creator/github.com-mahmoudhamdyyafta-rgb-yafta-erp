package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Advertisement & Signage Dynamic Branding - Black & Gold Identity System
val DeepSlateBg = Color(0xFF050505)     // Deep Premium Black canvas base
val DarkSlateCard = Color(0xFF111114)   // Luxury charcoal metallic card container
val BrushedTitanium = Color(0xFFECE5D8) // Warm polished ivory-cream metallic gold text and core accents

val NeonPurple = Color(0xFFD4AF37)      // Main Luxury Metallic Gold (Primary)
val NeonCyan = Color(0xFFE5C158)        // Champagne Accent Gold (Secondary)
val NeonAmber = Color(0xFFB38F4D)       // Warm Satin Gold / Golden Ochre
val NeonMint = Color(0xFFFFF5DF)        // Softest Pale Ivory Highlight Gold
val DeepInkShadow = Color(0xFF000000)   // Absolute Deep Black backing shadows

val SignalCritical = Color(0xFF9E2C2C)  // Warm Deep Madder Burgundy for warnings/destructive states (no neon)
val TextSilver = Color(0xFFC0B299)      // Satin Brass / Muted golden-sand text secondary
val BorderGlass = Color(0xFF2C2214)     // Polished dark metallic bronze/gold border frame lines

