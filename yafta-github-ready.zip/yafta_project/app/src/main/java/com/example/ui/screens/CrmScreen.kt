package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrmScreenLayout(viewModel: YaftaViewModel) {
    val leads by viewModel.leadsList.collectAsState()
    val staff by viewModel.allStaff.collectAsState()
    val clients by viewModel.clientsList.collectAsState()
    val communicationLogs by viewModel.communicationLogsList.collectAsState()
    val projects by viewModel.projectsList.collectAsState()
    val context = LocalContext.current

    // CRM Screen Navigation Tab State
    var activeCrmTab by remember { mutableStateOf("Leads") } // "Leads" or "Clients"

    // Search query states
    var leadSearchQuery by remember { mutableStateOf("") }
    var clientSearchQuery by remember { mutableStateOf("") }

    // Tab state filters
    var selectedFilterTab by remember { mutableStateOf("All") }

    // Lead dialog triggers
    var showAddLeadDialog by remember { mutableStateOf(false) }
    var selectedLeadToConvert by remember { mutableStateOf<Lead?>(null) }

    // Client dialog triggers
    var showAddClientDialog by remember { mutableStateOf(false) }
    var clientToEdit by remember { mutableStateOf<CrmClient?>(null) }
    var clientToLogTouchpoint by remember { mutableStateOf<CrmClient?>(null) }

    // Conversion staff assigned variables
    var selectedDesignerId by remember { mutableStateOf(0L) }
    var selectedFabricatorId by remember { mutableStateOf(0L) }
    var selectedInstallerId by remember { mutableStateOf(0L) }

    // Form inputs: Add Lead/Brief
    var leadClientName by remember { mutableStateOf("") }
    var leadClientPhone by remember { mutableStateOf("") }
    var leadProjectType by remember { mutableStateOf("3D Neon Signboard") }
    var leadBriefNotes by remember { mutableStateOf("") }
    var leadBudgetVal by remember { mutableStateOf("") }

    // Form inputs: Add/Edit Client
    var clientName by remember { mutableStateOf("") }
    var clientEmail by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }
    var clientOrganization by remember { mutableStateOf("") }
    var clientAddress by remember { mutableStateOf("") }

    // Form inputs: Add Communication Log
    var logType by remember { mutableStateOf("Phone Call") }
    var logSummary by remember { mutableStateOf("") }
    var logDetail by remember { mutableStateOf("") }
    var logAgent by remember { mutableStateOf("") }

    val filterTabs = listOf("All", "New", "Briefing", "Quoted", "Converted")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .padding(24.dp)
            .testTag("crm_management_root")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // Primary CRM Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "YAFTA CRM Workstation",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = BrushedTitanium
                        )
                    )
                    Text(
                        text = "Signage accounts, customer intelligence logs & pipeline deals",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSilver
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Create New Action based on active Panel Tab
                    if (activeCrmTab == "Leads") {
                        Button(
                            onClick = { showAddLeadDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("btn_lead_intake_trigger")
                        ) {
                            Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Brief", tint = DeepSlateBg)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("New Brief Intake", fontWeight = FontWeight.Black, color = DeepSlateBg, fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                clientName = ""
                                clientEmail = ""
                                clientPhone = ""
                                clientOrganization = ""
                                clientAddress = ""
                                showAddClientDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("btn_client_signup_trigger")
                        ) {
                            Icon(imageVector = Icons.Filled.PersonAdd, contentDescription = "Add Client", tint = DeepSlateBg)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Premium Partner", fontWeight = FontWeight.Black, color = DeepSlateBg, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Dual segmented control Switcher Panel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, BorderGlass, RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                listOf(
                    "Leads" to "Opportunities & Inbound Briefs",
                    "Clients" to "Partners Directory & Touchpoint Logs"
                ).forEach { (key, title) ->
                    val isSelected = activeCrmTab == key
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NeonPurple else Color.Transparent)
                            .clickable { activeCrmTab = key }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                            color = if (isSelected) DeepSlateBg else TextSilver
                        )
                    }
                }
            }

            // TAB 1 CONTENT: Opportunities & Intake Briefs (Leads List)
            if (activeCrmTab == "Leads") {
                // Search Input Line
                OutlinedTextField(
                    value = leadSearchQuery,
                    onValueChange = { leadSearchQuery = it },
                    placeholder = { Text("Search deals by organization name or specs...", color = TextSilver, fontSize = 12.sp) },
                    prefix = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSilver, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("lead_search_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = BorderGlass,
                        focusedTextColor = BrushedTitanium,
                        unfocusedTextColor = BrushedTitanium
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                // Horizontal lead status selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filterTabs.forEach { tab ->
                        val isSelected = selectedFilterTab == tab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (isSelected) NeonPurple else BorderGlass)
                                .clickable { selectedFilterTab = tab }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = tab.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) DeepSlateBg else TextSilver
                            )
                        }
                    }
                }

                // Filter & Sort Logic for leads
                val filteredLeads = leads.filter { lead ->
                    val matchesTab = (selectedFilterTab == "All" || lead.status == selectedFilterTab)
                    val matchesQuery = lead.clientName.contains(leadSearchQuery, ignoreCase = true) || 
                                       lead.projectType.contains(leadSearchQuery, ignoreCase = true) ||
                                       lead.designBrief.contains(leadSearchQuery, ignoreCase = true)
                    matchesTab && matchesQuery
                }

                if (filteredLeads.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Filled.Contacts, contentDescription = null, tint = TextSilver, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No negotiations match current filters.", color = BrushedTitanium, fontWeight = FontWeight.Black)
                            Text("Click 'New Brief Intake' to draft an incoming signboard lead request.", color = TextSilver, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(filteredLeads, key = { it.id }) { lead ->
                            LeadCard(
                                lead = lead,
                                onStatusChange = { newStatus -> viewModel.updateLeadStatus(lead, newStatus) },
                                onDelete = { viewModel.deleteLead(lead.id) },
                                onConvertClick = {
                                    selectedLeadToConvert = lead
                                    val designers = staff.filter { it.role == "Designer" }
                                    val fabricators = staff.filter { it.role == "Fabricator" }
                                    val installers = staff.filter { it.role == "Installer" }
                                    if (designers.isNotEmpty()) selectedDesignerId = designers.first().id
                                    if (fabricators.isNotEmpty()) selectedFabricatorId = fabricators.first().id
                                    if (installers.isNotEmpty()) selectedInstallerId = installers.first().id
                                }
                            )
                        }
                    }
                }
            }

            // TAB 2 CONTENT: Clients Directory & Logs list view
            if (activeCrmTab == "Clients") {
                // Search Input Line
                OutlinedTextField(
                    value = clientSearchQuery,
                    onValueChange = { clientSearchQuery = it },
                    placeholder = { Text("Search client directory by contact name, company or phone...", color = TextSilver, fontSize = 12.sp) },
                    prefix = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSilver, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("client_search_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = BorderGlass,
                        focusedTextColor = BrushedTitanium,
                        unfocusedTextColor = BrushedTitanium
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                // Match query
                val filteredClients = clients.filter { client ->
                    client.name.contains(clientSearchQuery, ignoreCase = true) ||
                    client.organization.contains(clientSearchQuery, ignoreCase = true) ||
                    client.phone.contains(clientSearchQuery, ignoreCase = true) ||
                    client.email.contains(clientSearchQuery, ignoreCase = true)
                }

                if (filteredClients.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Filled.BusinessCenter, contentDescription = null, tint = TextSilver, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No commercial partners found in Directory.", color = BrushedTitanium, fontWeight = FontWeight.Black)
                            Text("Tap 'Add Premium Partner' to document contact coordinates.", color = TextSilver, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(filteredClients, key = { it.id }) { client ->
                            // Dynamic projects metrics for client
                            val clientProjects = projects.filter { 
                                it.clientName.trim().lowercase() == client.name.trim().lowercase() ||
                                it.clientName.trim().lowercase() == client.organization.trim().lowercase()
                            }
                            val clientLogs = communicationLogs.filter { it.clientId == client.id }

                            ClientCard(
                                client = client,
                                relatedProjects = clientProjects,
                                logs = clientLogs,
                                onEditClick = {
                                    clientToEdit = client
                                    clientName = client.name
                                    clientEmail = client.email
                                    clientPhone = client.phone
                                    clientOrganization = client.organization
                                    clientAddress = client.address
                                },
                                onLogTouchpointClick = {
                                    clientToLogTouchpoint = client
                                    logType = "Phone Call"
                                    logSummary = ""
                                    logDetail = ""
                                    logAgent = viewModel.currentSessionUser.value?.name ?: "Yafta Agent"
                                },
                                onDeleteClick = {
                                    viewModel.deleteClient(client.id)
                                    Toast.makeText(context, "Partner accounts & logs purged securely.", Toast.LENGTH_SHORT).show()
                                },
                                onDeleteLog = { logId ->
                                    viewModel.deleteCommunicationLog(logId)
                                }
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // DIALOGS & OVERLAY INTERACTIVE WIDGETS
        // ==========================================

        // 1. ADD LEAD CONVERTER FORM
        if (showAddLeadDialog) {
            AlertDialog(
                onDismissRequest = { showAddLeadDialog = false },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Client Intake & Creative Request", color = BrushedTitanium, fontWeight = FontWeight.Black) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = leadClientName,
                            onValueChange = { leadClientName = it },
                            label = { Text("Client Name / Contact Person", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth().testTag("add_lead_client_name")
                        )

                        OutlinedTextField(
                            value = leadClientPhone,
                            onValueChange = { leadClientPhone = it },
                            label = { Text("Contact Phone", color = TextSilver) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text("Estimated Creative Output Type:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("3D Neon Signboard", "Acrylic Light Box", "Flex Billboard", "LED Screen", "Creative Logo").forEach { type ->
                                val isSelected = leadProjectType == type
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                        .border(1.dp, if (isSelected) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable { leadProjectType = type }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(type, color = if (isSelected) NeonPurple else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = leadBriefNotes,
                            onValueChange = { leadBriefNotes = it },
                            label = { Text("Branding Brief & Neon Specifications", color = TextSilver) },
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = leadBudgetVal,
                            onValueChange = { leadBudgetVal = it },
                            label = { Text("Target Budget ($)", color = TextSilver) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val budget = leadBudgetVal.toDoubleOrNull()
                            if (leadClientName.trim().isEmpty() || budget == null) {
                                Toast.makeText(context, "Input Name and a valid numeric Budget.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addLead(leadClientName, leadClientPhone, leadProjectType, leadBriefNotes, budget)
                            showAddLeadDialog = false
                            leadClientName = ""
                            leadClientPhone = ""
                            leadBriefNotes = ""
                            leadBudgetVal = ""
                            Toast.makeText(context, "Added lead opportunity to negotiation pipeline.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Add to CRM", color = DeepSlateBg, fontWeight = FontWeight.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddLeadDialog = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 2. CONVERT LEAD TO PROJECTS PIPE DIALOG
        selectedLeadToConvert?.let { lead ->
            val designers = staff.filter { it.role == "Designer" }
            val fabricators = staff.filter { it.role == "Fabricator" }
            val installers = staff.filter { it.role == "Installer" }

            AlertDialog(
                onDismissRequest = { selectedLeadToConvert = null },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Commission Fabrication Job", color = BrushedTitanium, fontWeight = FontWeight.Black) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Assign certified staff members to oversee technical structural fabrication of '${lead.projectType}' and authorize financial transaction logs.",
                            color = TextSilver,
                            fontSize = 12.sp
                        )

                        // Designer Assignment
                        Column {
                            Text("Creative Signs Designer:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            if (designers.isEmpty()) {
                                Text("No Designer registered. Add Designer staff in Workforce section first.", color = NeonPurple, fontSize = 11.sp)
                            } else {
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    designers.forEach { staffVal ->
                                        val isSelected = selectedDesignerId == staffVal.id
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isSelected) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                                .border(1.dp, if (isSelected) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                                                .clickable { selectedDesignerId = staffVal.id }
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(staffVal.name, color = if (isSelected) NeonPurple else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        // Fabricator Assignment
                        Column {
                            Text("Weld/Profile Fabricator:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            if (fabricators.isEmpty()) {
                                Text("No Certified Fabricator registered. Add in Workforce first.", color = NeonCyan, fontSize = 11.sp)
                            } else {
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    fabricators.forEach { staffVal ->
                                        val isSelected = selectedFabricatorId == staffVal.id
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isSelected) NeonCyan.copy(alpha = 0.2f) else BorderGlass)
                                                .border(1.dp, if (isSelected) NeonCyan else Color.Transparent, RoundedCornerShape(8.dp))
                                                .clickable { selectedFabricatorId = staffVal.id }
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(staffVal.name, color = if (isSelected) NeonCyan else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        // Installer Assignment
                        Column {
                            Text("Cladding Installation Mount Crew:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            if (installers.isEmpty()) {
                                Text("No Certified Installer registered. Add in Workforce first.", color = NeonAmber, fontSize = 11.sp)
                            } else {
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    installers.forEach { staffVal ->
                                        val isSelected = selectedInstallerId == staffVal.id
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isSelected) NeonAmber.copy(alpha = 0.2f) else BorderGlass)
                                                .border(1.dp, if (isSelected) NeonAmber else Color.Transparent, RoundedCornerShape(8.dp))
                                                .clickable { selectedInstallerId = staffVal.id }
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(staffVal.name, color = if (isSelected) NeonAmber else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.convertLeadToProject(
                                lead = lead,
                                assignedDesigner = if (selectedDesignerId == 0L) 1L else selectedDesignerId,
                                assignedFabricator = if (selectedFabricatorId == 0L) 1L else selectedFabricatorId,
                                assignedInstaller = if (selectedInstallerId == 0L) 1L else selectedInstallerId
                            )
                            Toast.makeText(context, "Pipeline updated! Client invoice generated & Project added.", Toast.LENGTH_LONG).show()
                            selectedLeadToConvert = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonMint)
                    ) {
                        Text("Launch Signboard Commission", color = DeepSlateBg, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedLeadToConvert = null }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 3. ADD CLIENT DIALOG
        if (showAddClientDialog) {
            AlertDialog(
                onDismissRequest = { showAddClientDialog = false },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Register Custom Business Account", color = BrushedTitanium, fontWeight = FontWeight.Black) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = clientName,
                            onValueChange = { clientName = it },
                            label = { Text("Contact Full Name", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth().testTag("add_client_name")
                        )

                        OutlinedTextField(
                            value = clientOrganization,
                            onValueChange = { clientOrganization = it },
                            label = { Text("Company / Organization", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientEmail,
                            onValueChange = { clientEmail = it },
                            label = { Text("Email Coordinates", color = TextSilver) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientPhone,
                            onValueChange = { clientPhone = it },
                            label = { Text("Direct Telephone", color = TextSilver) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientAddress,
                            onValueChange = { clientAddress = it },
                            label = { Text("Corporate Address (Riyadh, Jeddah, etc)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (clientName.trim().isEmpty() || clientPhone.trim().isEmpty()) {
                                Toast.makeText(context, "Full Name & telephone are mandatory.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addClient(clientName, clientEmail, clientPhone, clientAddress, clientOrganization)
                            showAddClientDialog = false
                            Toast.makeText(context, "Client $clientName coordinates logged.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Save Partner Accounts", color = DeepSlateBg, fontWeight = FontWeight.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddClientDialog = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 4. EDIT CLIENT DIALOG
        clientToEdit?.let { orig ->
            AlertDialog(
                onDismissRequest = { clientToEdit = null },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Adjust Partner Coordinates", color = BrushedTitanium, fontWeight = FontWeight.Black) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = clientName,
                            onValueChange = { clientName = it },
                            label = { Text("Contact Full Name", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientOrganization,
                            onValueChange = { clientOrganization = it },
                            label = { Text("Company / Organization", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientEmail,
                            onValueChange = { clientEmail = it },
                            label = { Text("Email Coordinates", color = TextSilver) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientPhone,
                            onValueChange = { clientPhone = it },
                            label = { Text("Direct Telephone", color = TextSilver) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientAddress,
                            onValueChange = { clientAddress = it },
                            label = { Text("Corporate Address", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (clientName.trim().isEmpty() || clientPhone.trim().isEmpty()) {
                                Toast.makeText(context, "Full Name & telephone are mandatory.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.updateClient(
                                orig.copy(
                                    name = clientName,
                                    email = clientEmail,
                                    phone = clientPhone,
                                    address = clientAddress,
                                    organization = clientOrganization
                                )
                            )
                            clientToEdit = null
                            Toast.makeText(context, "Client details adjusted successfully.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Save Changes", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { clientToEdit = null }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 5. ADD TOUCHPOINT LOG DIALOG
        clientToLogTouchpoint?.let { client ->
            AlertDialog(
                onDismissRequest = { clientToLogTouchpoint = null },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Log Communication Touchpoint", color = BrushedTitanium, fontWeight = FontWeight.Black) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Channel Type:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Phone Call", "Email", "WhatsApp", "In-Person Meeting", "Technical Survey").forEach { type ->
                                val isSelected = logType == type
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                        .border(1.dp, if (isSelected) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable { logType = type }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(type, color = if (isSelected) NeonPurple else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = logSummary,
                            onValueChange = { logSummary = it },
                            label = { Text("Discussion Summary (e.g., Reviewed Neon Mockup)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth().testTag("add_log_summary")
                        )

                        OutlinedTextField(
                            value = logDetail,
                            onValueChange = { logDetail = it },
                            label = { Text("Elaborated Details / Actions Required", color = TextSilver) },
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = logAgent,
                            onValueChange = { logAgent = it },
                            label = { Text("Staff Auditor Name", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (logSummary.trim().isEmpty() || logAgent.trim().isEmpty()) {
                                Toast.makeText(context, "Summary & Agent Name are required.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addCommunicationLog(
                                clientId = client.id,
                                type = logType,
                                summary = logSummary,
                                detail = logDetail,
                                agentName = logAgent
                            )
                            clientToLogTouchpoint = null
                            Toast.makeText(context, "Client touchpoint archived.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Archive Log", color = DeepSlateBg, fontWeight = FontWeight.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { clientToLogTouchpoint = null }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }
    }
}

// Leads UI Card Helper
@Composable
fun LeadCard(
    lead: Lead,
    onStatusChange: (String) -> Unit,
    onDelete: () -> Unit,
    onConvertClick: () -> Unit
) {
    val statusColor = when (lead.status) {
        "New" -> NeonPurple
        "Briefing" -> NeonCyan
        "Quoted" -> NeonAmber
        "Converted" -> NeonMint
        else -> TextSilver
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateCard)
            .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = lead.clientName,
                        fontWeight = FontWeight.Black,
                        color = BrushedTitanium,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "Phone: ${lead.clientPhone} | Target Budget: $${lead.estimatedValue}",
                        color = TextSilver,
                        fontSize = 12.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .border(1.dp, statusColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = lead.status.uppercase(),
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = lead.projectType,
                color = NeonCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = lead.designBrief,
                color = TextSilver,
                fontSize = 13.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(12.dp))

            // Footer parameters/actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Quick state switcher buttons
                    if (lead.status != "Converted") {
                        listOf("New", "Briefing", "Quoted").forEach { stat ->
                            if (stat != lead.status) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BorderGlass)
                                        .clickable { onStatusChange(stat) }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(stat.uppercase(), color = TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconButton(onClick = onDelete) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription = "Purge Deals", tint = SignalCritical)
                    }

                    if (lead.status != "Converted") {
                        Button(
                            onClick = onConvertClick,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonMint),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(imageVector = Icons.Filled.PlayArrow, contentDescription = null, tint = DeepSlateBg, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Convert To Project", color = DeepSlateBg, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

// Client Card directory detail UI
@Composable
fun ClientCard(
    client: CrmClient,
    relatedProjects: List<Project>,
    logs: List<CommunicationLog>,
    onEditClick: () -> Unit,
    onLogTouchpointClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onDeleteLog: (Long) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    // Aggregate values
    val lifetimeSpend = relatedProjects.sumOf { it.totalBudget }
    val completedProjectsCount = relatedProjects.count { it.status == "Completed" }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateCard)
            .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
            .padding(20.dp)
            .testTag("client_card_${client.id}")
    ) {
        Column {
            // Header Info Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = client.name,
                        fontWeight = FontWeight.Black,
                        color = BrushedTitanium,
                        fontSize = 18.sp
                    )
                    if (client.organization.isNotEmpty()) {
                        Text(
                            text = client.organization.uppercase(),
                            color = NeonPurple,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                // Cumulative value badges
                Column(horizontalAlignment = Alignment.End) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonPurple.copy(alpha = 0.15f))
                            .border(1.dp, NeonPurple, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$${String.format("%,.0f", lifetimeSpend)} LIFE VALUE",
                            color = NeonPurple,
                            fontWeight = FontWeight.Black,
                            fontSize = 10.sp
                        )
                    }
                    Text(
                        text = "${relatedProjects.size} signs ordered (${completedProjectsCount} completed)",
                        color = TextSilver,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Coordinates details list
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Call, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = client.phone, color = TextSilver, fontSize = 12.sp)
                }
                
                if (client.email.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = client.email, color = TextSilver, fontSize = 12.sp)
                    }
                }

                if (client.address.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = client.address, color = TextSilver, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(12.dp))

            // Card Action Drawer triggers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Main toggle to expand histories
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { expanded = !expanded }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = NeonPurple,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (expanded) "HIDE DETAILS & FEED" else "SHOW DETAILS (" + (logs.size + relatedProjects.size) + ")",
                        color = NeonPurple,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = onEditClick) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Contact", tint = NeonPurple, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onLogTouchpointClick) {
                        Icon(imageVector = Icons.Default.AddComment, contentDescription = "Log Communications touch", tint = NeonCyan, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDeleteClick) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Partner File", tint = SignalCritical, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Expanded detail list of communication logs & projects histories
            if (expanded) {
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = BorderGlass, modifier = Modifier.padding(bottom = 12.dp))

                // SECTION 1: SIGNBOARD COMISSION PROJECTS HISTORY
                Text(
                    text = "COMMISSIONS TIMELINE (${relatedProjects.size} Projects)",
                    color = BrushedTitanium,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (relatedProjects.isEmpty()) {
                    Text(
                        text = "No fabrication contracts recorded with this customer file structure yet.",
                        color = TextSilver,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        relatedProjects.forEach { proj ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DeepSlateBg)
                                    .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(proj.title, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(
                                            text = "${proj.widthCm}x${proj.heightCm} cm | ${proj.signText.ifEmpty { "No sign text" }}",
                                            color = TextSilver,
                                            fontSize = 11.sp
                                        )
                                        // Due Date
                                        val formattedDueDate = DateFormat.getDateInstance(DateFormat.SHORT).format(Date(proj.dueDate))
                                        Text(
                                            text = "Due Date: $formattedDueDate",
                                            color = TextSilver,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "$${String.format("%,.2f", proj.totalBudget)}",
                                            color = NeonPurple,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 12.sp
                                        )
                                        Box(
                                            modifier = Modifier
                                                .padding(top = 4.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(NeonPurple.copy(alpha = 0.1f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(proj.status, color = NeonPurple, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // SECTION 2: COMMUNICATION TOUCHPOINT FEED
                Text(
                    text = "COMMUNICATION HISTORY FEED (${logs.size} Logs)",
                    color = BrushedTitanium,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (logs.isEmpty()) {
                    Text(
                        text = "No communication diaries logged. Tap the speech bubble icon up right to log a Phone Call, Chat thread or site survey notes.",
                        color = TextSilver,
                        fontSize = 11.sp
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        logs.forEach { log ->
                            val logIcon = when (log.type) {
                                "WhatsApp" -> Icons.Default.Chat
                                "Phone Call" -> Icons.Default.Call
                                "Email" -> Icons.Default.Email
                                "In-Person Meeting" -> Icons.Default.Person
                                "Technical Survey" -> Icons.Default.Assignment
                                else -> Icons.Default.Chat
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DeepSlateBg)
                                    .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Icon(imageVector = logIcon, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(log.summary, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }

                                        IconButton(
                                            onClick = { onDeleteLog(log.id) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Trash log", tint = SignalCritical, modifier = Modifier.size(12.dp))
                                        }
                                    }

                                    if (log.detail.isNotEmpty()) {
                                        Text(
                                            text = log.detail,
                                            color = TextSilver,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(vertical = 4.dp),
                                            lineHeight = 14.sp
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val formattedDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(log.timestamp))
                                        Text(text = formattedDate, color = TextSilver, fontSize = 10.sp)
                                        Text(text = "Logged by: ${log.agentName}", color = TextSilver, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
