package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeminiAiScreenLayout(viewModel: YaftaViewModel) {
    val context = LocalContext.current

    // Observe State from VM
    val aiIsLoading by viewModel.aiIsLoading.collectAsState()
    val aiCopywritingResult by viewModel.aiCopywritingResult.collectAsState()
    val aiMaterialResult by viewModel.aiMaterialResult.collectAsState()
    val aiBriefResult by viewModel.aiBriefResult.collectAsState()

    var activeSubWorkspace by remember { mutableStateOf("Slogans") } // "Slogans", "Advisor", "BriefRefiner"

    // Form inputs variables
    var sloganProjectName by remember { mutableStateOf("Riyadh Coffee Station") }
    var sloganKeys by remember { mutableStateOf("Cozy, dynamic, purple neon halo backlight") }
    var sloganSignText by remember { mutableStateOf("COFFEE") }

    var widthCm by remember { mutableStateOf("180") }
    var heightCm by remember { mutableStateOf("120") }
    var lettersCount by remember { mutableStateOf("6") }
    var primaryMaterial by remember { mutableStateOf("3D Acrylic & Purple LED Tube") }

    var rawBriefNotes by remember { mutableStateOf("We want a big billboard sign board on olaya street that looks modern, green background color option, neon mint modules, for the gourmet burger restaurant BurgerLab.") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        // Welcoming header title
        Text(
            text = "Yafta Creative AI Desk",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Black,
                color = BrushedTitanium
            )
        )
        Text(
            text = "Powered by Google Gemini 3.5—intelligent fabrication guides and tagline generators.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSilver,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Workspace Selector Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf("Slogans" to "Visual Taglines", "Advisor" to "Material Guide", "BriefRefiner" to "Brief Optimizer").forEach { pair ->
                val (ws, label) = pair
                val isSelected = activeSubWorkspace == ws
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) NeonPurple else BorderGlass)
                        .clickable { activeSubWorkspace = ws }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) DeepSlateBg else TextSilver
                    )
                }
            }
        }

        // ACTIVE WORKSPACE CONTROLS
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
                .border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                when (activeSubWorkspace) {
                    "Slogans" -> {
                        Text("ADVERTISING TAGLINE GENERATOR (BILINGUAL)", color = NeonPurple, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
                        
                        OutlinedTextField(
                            value = sloganProjectName,
                            onValueChange = { sloganProjectName = it },
                            label = { Text("Brand Name / Company", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )
                        OutlinedTextField(
                            value = sloganKeys,
                            onValueChange = { sloganKeys = it },
                            label = { Text("Vibe Description (e.g. Elegant Slate dark, cozy, techy)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )
                        OutlinedTextField(
                            value = sloganSignText,
                            onValueChange = { sloganSignText = it },
                            label = { Text("Literal letters on Signboard (e.g. CAFE)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                        )

                        Button(
                            onClick = { viewModel.triggerAiSlogans(sloganProjectName, sloganKeys, sloganSignText) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Illuminate Taglines with Gemini", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                        }
                    }

                    "Advisor" -> {
                        Text("INTELLIGENT FABRICATION BLUEPRINTING ESTIMATOR", color = NeonCyan, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = widthCm,
                                onValueChange = { widthCm = it },
                                label = { Text("Width (cm)", color = TextSilver) },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = heightCm,
                                onValueChange = { heightCm = it },
                                label = { Text("Height (cm)", color = TextSilver) },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = lettersCount,
                                onValueChange = { lettersCount = it },
                                label = { Text("Signboard Letters Length", color = TextSilver) },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = primaryMaterial,
                                onValueChange = { primaryMaterial = it },
                                label = { Text("Primary core material", color = TextSilver) },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Button(
                            onClick = {
                                val w = widthCm.toDoubleOrNull() ?: 180.0
                                val h = heightCm.toDoubleOrNull() ?: 120.0
                                val count = lettersCount.toIntOrNull() ?: 6
                                viewModel.triggerAiMaterials(w, h, count, primaryMaterial)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Formulate Structural advice", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                        }
                    }

                    "BriefRefiner" -> {
                        Text("CRUDE CLIENT SPECIFICATION ORGANIZER", color = NeonAmber, fontWeight = FontWeight.Black, fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
                        
                        OutlinedTextField(
                            value = rawBriefNotes,
                            onValueChange = { rawBriefNotes = it },
                            label = { Text("Raw Notes collected from Client", color = TextSilver) },
                            maxLines = 6,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonAmber, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                        )

                        Button(
                            onClick = { viewModel.triggerAiBriefOutline(rawBriefNotes) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonAmber),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Refine brief with Creative intelligence", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 3. RESULTS OUTPUT VIEWER OR LOADING PANEL
        Text(
            text = "AI OUTPUT INTENSITY RESOLUTION:",
            color = TextSilver,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSlateCard)
                .border(2.dp, Brush.linearGradient(listOf(NeonPurple, NeonCyan)), RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {
            if (aiIsLoading) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = NeonPurple)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Commissioning REST parameters with Gemini AI...", color = TextSilver, fontSize = 12.sp)
                }
            } else {
                val activeResult = when (activeSubWorkspace) {
                    "Slogans" -> aiCopywritingResult
                    "Advisor" -> aiMaterialResult
                    "BriefRefiner" -> aiBriefResult
                    else -> ""
                }

                if (activeResult.isEmpty()) {
                    Text(
                        text = "Awaiting execution trigger parameters. Config assets above and hit generate to draft visual concepts instantly.",
                        color = TextSilver,
                        fontSize = 13.sp,
                        textAlign = Alignment.Center.let { TextAlign.Center },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    SelectionContainer {
                        Text(
                            text = activeResult,
                            color = BrushedTitanium,
                            fontSize = 13.sp,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(20.dp))
        // Simple security disclaimer under Direct REST API protocol:
        Text(
            text = "⚠️ Notice: This workspace uses the Google Generative REST API under direct sandbox variables. Credentials securely bound at launch.",
            color = TextSilver.copy(alpha = 0.5f),
            fontSize = 9.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
