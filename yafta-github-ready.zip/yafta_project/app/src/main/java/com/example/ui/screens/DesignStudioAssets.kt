package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun DesignAssetsPanel(
    leftPanelCategory: String,
    onLeftPanelCategoryChange: (String) -> Unit,
    backdropTheme: String,
    onBackdropThemeChange: (String) -> Unit,
    showMockupBg: Boolean,
    onShowMockupBgChange: (Boolean) -> Unit,
    layersList: List<DesignLayer>,
    onAddLayer: (DesignLayer) -> Unit,
    onClearLayers: () -> Unit,
    onSelectedLayerIdChange: (String?) -> Unit,
    onToolsPanelClose: () -> Unit,
    onCaptureState: () -> Unit,
    onCanvasWidthChange: (String) -> Unit,
    onCanvasHeightChange: (String) -> Unit,
    signageTemplates: List<Triple<String, String, Double>>,
    presetLogosList: List<Triple<String, String, String>>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard.copy(alpha = 0.98f)),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = modifier
            .height(350.dp)
            .border(BorderStroke(1.5.dp, BorderGlass), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .size(40.dp, 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(BorderGlass)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("DESIGN WORKSPACE ASSETS", color = NeonPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onToolsPanelClose, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Filled.Close, null, tint = TextSilver, modifier = Modifier.size(16.dp))
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val categories = listOf(
                    "Templates" to Icons.Filled.AutoAwesomeMotion,
                    "Images" to Icons.Filled.Image,
                    "Logos" to Icons.Filled.Star,
                    "Text" to Icons.Filled.TextFields,
                    "Shapes" to Icons.Filled.Category,
                    "Icons" to Icons.Filled.BubbleChart,
                    "AI Tools" to Icons.Filled.AutoAwesome
                )
                categories.forEach { (cat, icon) ->
                    val isCurrent = leftPanelCategory == cat
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isCurrent) NeonPurple else DeepSlateBg)
                            .clickable { onLeftPanelCategoryChange(cat) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isCurrent) DeepSlateBg else TextSilver,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = cat,
                            color = if (isCurrent) DeepSlateBg else BrushedTitanium,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Divider(color = BorderGlass, modifier = Modifier.padding(vertical = 4.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
            ) {
                when (leftPanelCategory) {
                    "Templates" -> {
                        signageTemplates.forEach { (title, desc, cost) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DeepSlateBg),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                    .clickable {
                                        onCaptureState()
                                        onClearLayers()
                                        if (title.contains("Café")) {
                                            onCanvasWidthChange("120")
                                            onCanvasHeightChange("120")
                                            val tId1 = "cafe_text"
                                            onAddLayer(
                                                DesignLayer(
                                                    id = tId1,
                                                    name = "Main Cafe Bold Text",
                                                    type = LayerType.TEXT,
                                                    text = "THE STREET BREW",
                                                    fontName = "Bebas Neue",
                                                    fontSize = 30f,
                                                    primaryColorHex = "#FFFF00",
                                                    xPercent = 50f,
                                                    yPercent = 48f,
                                                    widthPercent = 80f,
                                                    heightPercent = 14f,
                                                    glowColorHex = "#FFFF00"
                                                )
                                            )
                                            onAddLayer(
                                                DesignLayer(
                                                    id = "cafe_circle",
                                                    name = "Backing Circle Base",
                                                    type = LayerType.SHAPE,
                                                    shapeType = ShapeType.CIRCLE,
                                                    primaryColorHex = "#00FFFF",
                                                    xPercent = 50f,
                                                    yPercent = 48f,
                                                    widthPercent = 85f,
                                                    heightPercent = 85f,
                                                    strokeColorHex = "#00FFFF",
                                                    strokeWidth = 3f
                                                )
                                            )
                                            onSelectedLayerIdChange(tId1)
                                        } else if (title.contains("Ramadan")) {
                                            onCanvasWidthChange("300")
                                            onCanvasHeightChange("100")
                                            val tId2 = "ramadan_text"
                                            onAddLayer(
                                                DesignLayer(
                                                    id = tId2,
                                                    name = "Ramadan Title",
                                                    type = LayerType.TEXT,
                                                    text = "RAMADAN KAREEM Ramadan",
                                                    fontName = "Cairo",
                                                    fontSize = 28f,
                                                    primaryColorHex = "#D4AF37",
                                                    xPercent = 50f,
                                                    yPercent = 45f,
                                                    widthPercent = 85f,
                                                    heightPercent = 16f,
                                                    glowColorHex = "#D4AF37"
                                                )
                                            )
                                            onAddLayer(
                                                DesignLayer(
                                                    id = "crescent",
                                                    name = "Crescent Glow Outline",
                                                    type = LayerType.SHAPE,
                                                    shapeType = ShapeType.CIRCLE,
                                                    primaryColorHex = "#00FF66",
                                                    xPercent = 50f,
                                                    yPercent = 45f,
                                                    widthPercent = 92f,
                                                    heightPercent = 40f,
                                                    strokeColorHex = "#00FF66",
                                                    strokeWidth = 2.5f
                                                )
                                            )
                                            onSelectedLayerIdChange(tId2)
                                        } else {
                                            val customId = UUID.randomUUID().toString()
                                            onAddLayer(
                                                DesignLayer(
                                                    id = customId,
                                                    name = "Template Head",
                                                    type = LayerType.TEXT,
                                                    text = title.uppercase(),
                                                    fontName = "Space Grotesk",
                                                    fontSize = 32f,
                                                    primaryColorHex = "#FF007F",
                                                    xPercent = 50f,
                                                    yPercent = 45f,
                                                    widthPercent = 85f,
                                                    heightPercent = 15f
                                                )
                                            )
                                            onSelectedLayerIdChange(customId)
                                        }
                                        onToolsPanelClose()
                                        Toast.makeText(context, "$title loaded", Toast.LENGTH_SHORT).show()
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(title, color = BrushedTitanium, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("Est: SAR $cost", color = NeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    "Images" -> {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Brick Storefront", "Concrete Face", "Van Side").forEach { option ->
                                val isCurrent = backdropTheme.contains(option.take(4))
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isCurrent) NeonCyan else DeepSlateBg)
                                        .clickable {
                                            onShowMockupBgChange(true)
                                            onBackdropThemeChange(
                                                when (option) {
                                                    "Brick Storefront" -> "Café Brick Storefront"
                                                    "Concrete Face" -> "Urban Concrete Face"
                                                    else -> "Vans Delivery Side"
                                                }
                                            )
                                            onToolsPanelClose()
                                        }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(option, color = if (isCurrent) DeepSlateBg else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { onShowMockupBgChange(!showMockupBg); onToolsPanelClose() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (showMockupBg) "Disable Mockup Overlay" else "Enable Mockup Overlay", fontSize = 10.sp)
                        }
                    }
                    "Logos" -> {
                        presetLogosList.forEach { (name, path, col) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(DeepSlateBg, RoundedCornerShape(8.dp))
                                    .border(1.dp, BorderGlass, RoundedCornerShape(8.dp))
                                    .clickable {
                                        onCaptureState()
                                        val logoId = UUID.randomUUID().toString()
                                        onAddLayer(
                                            DesignLayer(
                                                id = logoId,
                                                name = "$name Vector",
                                                type = LayerType.SVG_LOGO,
                                                primaryColorHex = col,
                                                xPercent = 50f,
                                                yPercent = 50f,
                                                widthPercent = 25f,
                                                heightPercent = 25f,
                                                presetAsset = path
                                            )
                                        )
                                        onSelectedLayerIdChange(logoId)
                                        onToolsPanelClose()
                                    }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.AutoAwesomeMotion, null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(name, color = BrushedTitanium, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    "Text" -> {
                        listOf(
                            "Cyber Gold Sign" to "#D4AF37",
                            "Classic Neon Red" to "#FF3366",
                            "Storefront Header" to "#00FFFF"
                        ).forEach { (option, col) ->
                            Button(
                                onClick = {
                                    onCaptureState()
                                    val textId = UUID.randomUUID().toString()
                                    onAddLayer(
                                        DesignLayer(
                                            id = textId,
                                            name = "$option Layer",
                                            type = LayerType.TEXT,
                                            text = if (option.contains("Gold")) "بوابة الشرق يافطة" else "NEW SIGN",
                                            fontName = if (option.contains("Gold")) "Cairo" else "Space Grotesk",
                                            primaryColorHex = col,
                                            fontSize = 24f,
                                            xPercent = 50f,
                                            yPercent = 50f,
                                            widthPercent = 75f,
                                            heightPercent = 12f,
                                            hasGlow = true,
                                            glowColorHex = col
                                        )
                                    )
                                    onSelectedLayerIdChange(textId)
                                    onToolsPanelClose()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                            ) {
                                Text(option, color = BrushedTitanium, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    "Shapes" -> {
                        listOf(
                            "RECTANGLE" to ShapeType.RECTANGLE,
                            "CIRCLE" to ShapeType.CIRCLE,
                            "TRIANGLE" to ShapeType.TRIANGLE
                        ).forEach { (label, shape) ->
                            Button(
                                onClick = {
                                    onCaptureState()
                                    val shapeId = UUID.randomUUID().toString()
                                    onAddLayer(
                                        DesignLayer(
                                            id = shapeId,
                                            name = label,
                                            type = LayerType.SHAPE,
                                            shapeType = shape,
                                            primaryColorHex = "#FF00FF",
                                            xPercent = 50f,
                                            yPercent = 50f,
                                            widthPercent = 30f,
                                            heightPercent = 30f,
                                            strokeColorHex = "#FF00FF"
                                        )
                                    )
                                    onSelectedLayerIdChange(shapeId)
                                    onToolsPanelClose()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                            ) {
                                Text(label, color = BrushedTitanium, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    "Icons" -> {
                        listOf(
                            "Cafe Mug" to "#00FFFF",
                            "Shopping Cart" to "#FF3366",
                            "Star Badge" to "#D4AF37"
                        ).forEach { (icon, col) ->
                            Button(
                                onClick = {
                                    onCaptureState()
                                    val iconId = UUID.randomUUID().toString()
                                    onAddLayer(
                                        DesignLayer(
                                            id = iconId,
                                            name = icon,
                                            type = LayerType.SVG_LOGO,
                                            primaryColorHex = col,
                                            xPercent = 50f,
                                            yPercent = 50f,
                                            widthPercent = 25f,
                                            heightPercent = 25f
                                        )
                                    )
                                    onSelectedLayerIdChange(iconId)
                                    onToolsPanelClose()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                            ) {
                                Text(icon, color = BrushedTitanium, fontSize = 10.sp)
                            }
                        }
                    }
                    "AI Tools" -> {
                        Button(
                            onClick = { onToolsPanelClose(); Toast.makeText(context, "AI Background Removal Triggered!", Toast.LENGTH_SHORT).show() },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Filled.AutoAwesome, null, tint = NeonPurple, modifier = Modifier.size(14.dp))
                                Text("AI Background Removal", fontSize = 10.sp)
                            }
                        }
                        Button(
                            onClick = { onToolsPanelClose(); Toast.makeText(context, "Vector Conversion Done!", Toast.LENGTH_SHORT).show() },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Filled.Brush, null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                                Text("AI Raster-to-Vector Clipart Trace", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
