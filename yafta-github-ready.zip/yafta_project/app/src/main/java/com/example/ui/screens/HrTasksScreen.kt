package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrTasksScreenLayout(viewModel: YaftaViewModel) {
    val staff by viewModel.allStaff.collectAsState()
    val projects by viewModel.projectsList.collectAsState()
    val tasks by viewModel.hrTasksList.collectAsState()
    val context = LocalContext.current

    var showAssignTaskDialog by remember { mutableStateOf(false) }
    var selectedTaskToComplete by remember { mutableStateOf<HrTask?>(null) }

    // Task Allocation States
    var selectedStaffId by remember { mutableStateOf(0L) }
    var selectedProjectId by remember { mutableStateOf(0L) }
    var taskTitle by remember { mutableStateOf("") }
    var taskType by remember { mutableStateOf("Design Sketching") } // Design Sketching, Acrylic Laser Cutting, LED Board Wiring, Site Installation

    // Complete duration state
    var completionMinutes by remember { mutableStateOf("120") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .padding(24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Workforce & Production Schedulers",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = BrushedTitanium
                        )
                    )
                    Text(
                        text = "${staff.size} active fabrication operators on schedule",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSilver
                    )
                }

                Button(
                    onClick = {
                        if (staff.isNotEmpty()) {
                            selectedStaffId = staff.first().id
                            if (projects.isNotEmpty()) selectedProjectId = projects.first().id
                            showAssignTaskDialog = true
                        } else {
                            Toast.makeText(context, "No staff registry found offline.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = null, tint = DeepSlateBg)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Deploy Workforce", fontWeight = FontWeight.Bold, color = DeepSlateBg)
                }
            }

            // High priority crew scroll row
            Text(
                text = "FACTORY FABRICATOR REGISTRIES:",
                color = TextSilver,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                staff.forEach { member ->
                    StaffVitalsChip(member)
                }
            }

            Text(
                text = "ACTIVE PRODUCTION QUEUE:",
                color = TextSilver,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (tasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Filled.Assignment, contentDescription = null, tint = TextSilver, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("All fabrication tasks cleared.", color = TextSilver, fontWeight = FontWeight.Bold)
                        Text("Assign a new production schedule using Deploy Workforce.", color = TextSilver, fontSize = 11.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(tasks, key = { it.id }) { task ->
                        val assignee = staff.find { it.id == task.userId }
                        TaskScheduleCard(
                            task = task,
                            assignedUser = assignee,
                            onCompleteClick = { selectedTaskToComplete = task },
                            onDelete = { viewModel.deleteHrTask(task.id) }
                        )
                    }
                }
            }
        }

        // 1. DEPLOY WORKFORCE SCHEDULE DIALOG
        if (showAssignTaskDialog) {
            AlertDialog(
                onDismissRequest = { showAssignTaskDialog = false },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Deploy Production Task", color = BrushedTitanium, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = taskTitle,
                            onValueChange = { taskTitle = it },
                            label = { Text("Task Designation (e.g. Arc weld frames)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text("Select Manufacturing Staff:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            staff.forEach { member ->
                                val isChecked = selectedStaffId == member.id
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isChecked) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                        .border(1.dp, if (isChecked) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable { selectedStaffId = member.id }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(member.name, color = if (isChecked) NeonPurple else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Text("Select Signboard Build Context:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (projects.isEmpty()) {
                            Text("No live orders in factory pipeline. Generic assignment.", color = NeonAmber, fontSize = 11.sp)
                        } else {
                            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                projects.forEach { proj ->
                                        val isChecked = selectedProjectId == proj.id
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isChecked) NeonCyan.copy(alpha = 0.2f) else BorderGlass)
                                                .border(1.dp, if (isChecked) NeonCyan else Color.Transparent, RoundedCornerShape(8.dp))
                                                .clickable { selectedProjectId = proj.id }
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(proj.title, color = if (isChecked) NeonCyan else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                            }
                        }

                        Text("Fabrication Process Discipline:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Design Sketching", "Acrylic Laser Cutting", "LED Board Wiring", "Site Installation").forEach { type ->
                                val isChecked = taskType == type
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isChecked) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                        .border(1.dp, if (isChecked) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable { taskType = type }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(type, color = if (isChecked) NeonPurple else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (taskTitle.isEmpty()) {
                                Toast.makeText(context, "Designation title required.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.assignStaffTask(
                                userId = if (selectedStaffId == 0L) 1L else selectedStaffId,
                                projectId = selectedProjectId,
                                title = taskTitle,
                                type = taskType
                            )
                            showAssignTaskDialog = false
                            taskTitle = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Deploy Worker", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAssignTaskDialog = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 2. COMPLETE TASK DURATION PROMPTER
        selectedTaskToComplete?.let { task ->
            AlertDialog(
                onDismissRequest = { selectedTaskToComplete = null },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Log Workshop Time", color = BrushedTitanium, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Log the amount of minutes clocked completing: \"${task.title}\". We will automatically evaluate salary margins and deduct payouts.",
                            color = TextSilver,
                            fontSize = 12.sp
                        )

                        OutlinedTextField(
                            value = completionMinutes,
                            onValueChange = { completionMinutes = it },
                            label = { Text("Duration worked in minutes", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val mins = completionMinutes.toIntOrNull()
                            if (mins == null || mins <= 0) {
                                Toast.makeText(context, "Input a valid numeric duration.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            viewModel.completeHrTask(task, mins)
                            Toast.makeText(context, "Work logged! Salary debit added to Ledger sheets.", Toast.LENGTH_LONG).show()
                            selectedTaskToComplete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonMint)
                    ) {
                        Text("Calculate Salary Payout", color = DeepSlateBg, fontWeight = FontWeight.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedTaskToComplete = null }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }
    }
}

@Composable
fun StaffVitalsChip(user: User) {
    Box(
        modifier = Modifier
            .width(160.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateCard)
            .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NeonPurple, NeonCyan))),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = user.name.take(2).uppercase(),
                    color = DeepSlateBg,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = user.name,
                fontWeight = FontWeight.Bold,
                color = BrushedTitanium,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "Class: ${user.role}",
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Wages: $${user.hourlyRate}/Hr",
                color = TextSilver,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun TaskScheduleCard(
    task: HrTask,
    assignedUser: User?,
    onCompleteClick: () -> Unit,
    onDelete: () -> Unit
) {
    val isDone = task.status == "Completed"
    val statusColor = if (isDone) NeonMint else NeonAmber

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateCard)
            .border(1.dp, if (isDone) NeonMint.copy(alpha = 0.3f) else BorderGlass, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        fontWeight = FontWeight.Black,
                        color = BrushedTitanium,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Assigned operator: ${assignedUser?.name ?: "Senior Welder"} | Discipline: ${task.taskType}",
                        color = TextSilver,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .border(1.dp, statusColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = task.status,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (isDone) {
                Spacer(modifier = Modifier.height(10.dp))
                val earned = ((task.minutesWorked.toDouble() / 60.0) * (assignedUser?.hourlyRate ?: 50.0))
                Text(
                    text = "✓ Performance Met: ${task.minutesWorked} Minutes registered (Earned: $${String.format("%.2f", earned)})",
                    color = NeonMint,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(10.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isDone) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonMint)
                            .clickable { onCompleteClick() }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Log Complete Time", color = DeepSlateBg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Box {}
                }

                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Filled.DeleteSweep, contentDescription = null, tint = SignalCritical)
                }
            }
        }
    }
}
