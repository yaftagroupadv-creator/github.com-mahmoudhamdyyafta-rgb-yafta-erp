package com.example.ui.screens

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel
import java.net.URLEncoder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreenLayout(
    viewModel: YaftaViewModel,
    onArabicPdfPrint: (String, Double, Long, String, Map<String, String>) -> Unit
) {
    val transactions by viewModel.transactionsList.collectAsState()
    val context = LocalContext.current

    var showAddTransDialog by remember { mutableStateOf(false) }

    // Forms
    var amount by remember { mutableStateOf("") }
    var transType by remember { mutableStateOf("Invoice Income") } // Invoice Income, Material Purchase, Staff Salary, Operations Cost
    var description by remember { mutableStateOf("") }
    var clientArabicName by remember { mutableStateOf("") }
    var isPaid by remember { mutableStateOf(false) }

    // Aggregate Analytics Calculations
    val totalIncomes = transactions.filter { it.type == "Invoice Income" && it.isPaid }.sumOf { it.amount }
    val totalExpenses = transactions.filter { it.type != "Invoice Income" && it.isPaid }.sumOf { it.amount }
    val pendingIncomes = transactions.filter { it.type == "Invoice Income" && !it.isPaid }.sumOf { it.amount }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .padding(24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Agency Ledger & Billing",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = BrushedTitanium
                        )
                    )
                    Text(
                        text = "Standard 15% VAT Invoices for KSA clients & suppliers",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSilver
                    )
                }

                Button(
                    onClick = { showAddTransDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = null, tint = DeepSlateBg)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Record Entry", fontWeight = FontWeight.Bold, color = DeepSlateBg)
                }
            }

            // Financial summary Card Info Bar
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text("CLEARED REVENUE (VAT INCLUDED):", color = NeonCyan, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text("$${String.format("%,.2f", totalIncomes)}", color = BrushedTitanium, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Net cash in studio bank account", color = TextSilver, fontSize = 10.sp)
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("TOTAL PAYOUTS:", color = SignalCritical, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text("$${String.format("%,.2f", totalExpenses)}", color = SignalCritical, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("UNSETTLED FUNDS:", color = NeonAmber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text("$${String.format("%,.2f", pendingIncomes)}", color = NeonAmber, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Ledger grid
            if (transactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = TextSilver, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Ledger stream is empty.", color = TextSilver, fontWeight = FontWeight.Bold)
                        Text("Log entries to monitor financial balance.", color = TextSilver, fontSize = 11.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(transactions, key = { it.id }) { trans ->
                        LedgerTransactionRow(
                            transaction = trans,
                            onUpdatePaid = { viewModel.markTransactionPaid(trans) },
                            onDelete = { viewModel.deleteTransaction(trans.id) },
                            onPrintClick = {
                                generateAndPrintArabicInvoice(context, trans)
                            },
                            onWhatsAppClick = {
                                shareInvoiceViaWhatsApp(context, trans)
                            }
                        )
                    }
                }
            }
        }

        // ADD TRANSACTION DIALOG
        if (showAddTransDialog) {
            AlertDialog(
                onDismissRequest = { showAddTransDialog = false },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Log Ledger Entry", color = BrushedTitanium, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = amount,
                            onValueChange = { amount = it },
                            label = { Text("Amount ($)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text("Transaction Nature:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Invoice Income", "Material Purchase", "Staff Salary", "Operations Cost").forEach { type ->
                                val isChecked = transType == type
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isChecked) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                        .border(1.dp, if (isChecked) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable { transType = type }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(type, color = if (isChecked) NeonPurple else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Itemization description", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = clientArabicName,
                            onValueChange = { clientArabicName = it },
                            label = { Text("Recipient Name (Standard / Arabic)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = isPaid,
                                onCheckedChange = { isPaid = it },
                                colors = CheckboxDefaults.colors(checkedColor = NeonPurple)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Has this entry cleared / been settled?", color = BrushedTitanium, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val targetAmt = amount.toDoubleOrNull()
                            if (targetAmt == null || description.isEmpty()) {
                                Toast.makeText(context, "Numeric amount and valid itemization are required.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addTransaction(
                                amount = targetAmt,
                                type = transType,
                                description = description,
                                isPaid = isPaid,
                                arabicRecipient = clientArabicName.ifEmpty { "عميد وكالة يافطة" }
                            )
                            showAddTransDialog = false
                            // Reset
                            amount = ""
                            description = ""
                            clientArabicName = ""
                            isPaid = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Add to Ledger", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddTransDialog = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }
    }
}

@Composable
fun LedgerTransactionRow(
    transaction: FinanceTransaction,
    onUpdatePaid: () -> Unit,
    onDelete: () -> Unit,
    onPrintClick: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    val itemColor = when (transaction.type) {
        "Invoice Income" -> NeonCyan
        "Material Purchase" -> PixelCriticalColorHelper()
        "Staff Salary" -> NeonAmber
        else -> TextSilver
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateCard)
            .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = transaction.description,
                        fontWeight = FontWeight.Bold,
                        color = BrushedTitanium,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Class: ${transaction.type} | To: ${transaction.arabicRecipientName}",
                        color = TextSilver,
                        fontSize = 11.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = (if (transaction.type == "Invoice Income") "+" else "-") + "$${String.format("%,.2f", transaction.amount)}",
                        fontWeight = FontWeight.Black,
                        color = itemColor,
                        fontSize = 16.sp
                    )
                    
                    Box(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (transaction.isPaid) NeonMint.copy(alpha = 0.15f) else NeonAmber.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (transaction.isPaid) "CLEARED" else "UNPAID BILL",
                            color = if (transaction.isPaid) NeonMint else NeonAmber,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(10.dp))

            // Action line
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!transaction.isPaid) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NeonMint)
                                .clickable { onUpdatePaid() }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Mark Settled", color = DeepSlateBg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Direct Print PDF invoice (Arabic-integrated)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BorderGlass)
                            .clickable { onPrintClick() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Filled.Print, contentDescription = null, tint = BrushedTitanium, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Arabic PDF Bill", color = BrushedTitanium, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Direct share WhatsApp contract
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BorderGlass)
                            .clickable { onWhatsAppClick() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Filled.Share, contentDescription = null, tint = NeonMint, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WhatsApp Client", color = NeonMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Filled.DeleteOutline, contentDescription = null, tint = SignalCritical)
                }
            }
        }
    }
}

// WhatsApp Integration implementation
fun shareInvoiceViaWhatsApp(context: Context, trans: FinanceTransaction) {
    val message = """
        *Yafta Advertising & Signage Agency* 🎨
        ---
        Hello Standard Partner,
        We logged a ledger invoice transaction:
        📄 *Description:* ${trans.description}
        💰 *Settled Total:* $${String.format("%,.2f", trans.amount)} (15% VAT included)
        🟢 *Status:* ${if (trans.isPaid) "Cleared & Settled" else "Requires Payment"}
        
        *يافطة لتصنيع اللوحات والواجهات الدعائية*
        شكرًا للتعامل مع وكالتنا!
    """.trimIndent()
    
    try {
        val encodedMsg = URLEncoder.encode(message, "UTF-8")
        val url = "https://api.whatsapp.com/send?phone=+966501234567&text=$encodedMsg"
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Bypassing action link: WhatsApp not installed on streaming target.", Toast.LENGTH_SHORT).show()
    }
}

// 100% REAL NATIVE PRINT SERVICE ARABIC/ENGLISH PDF GENERATOR
fun generateAndPrintArabicInvoice(context: Context, trans: FinanceTransaction) {
    val vatableAmt = trans.amount / 1.15
    val vatAmount = trans.amount - vatableAmt

    val htmlDocument = """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="utf-8">
            <title>فاتورة وكالة يافطة للدعاية واللوحات</title>
            <style>
                body {
                    font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
                    background-color: #FFFFFF;
                    color: #10141D;
                    padding: 30px;
                }
                .invoice-header {
                    border-bottom: 3px double #BF80FF;
                    padding-bottom: 12px;
                    margin-bottom: 24px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .invoice-header h1 {
                    margin: 0;
                    font-size: 24px;
                    color: #BF80FF;
                }
                .invoice-header h2 {
                    margin: 0;
                    font-size: 14px;
                    color: #6650a4;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 18px;
                }
                th, td {
                    border: 1px solid #CBD5E1;
                    padding: 10px;
                    text-align: right;
                }
                th {
                    background-color: #F1F5F9;
                }
                .total-block {
                    margin-top: 24px;
                    text-align: left;
                }
            </style>
        </head>
        <body>
            <div class="invoice-header">
                <div>
                    <h1>وكالة يافطة لتصنيع اللوحات والواجهات</h1>
                    <h2>Yafta Creative Signboard & Branding Agency</h2>
                </div>
                <div style="text-align: left; direction: ltr;">
                    <p><b>VAT ID:</b> 300187429100003</p>
                    <p><b>Date/التاريخ:</b> ${java.text.DateFormat.getDateInstance().format(java.util.Date(trans.timestamp))}</p>
                </div>
            </div>

            <h3>فاتورة ضريبة مبسطة ضريبة القيمة المضافة 15%</h3>
            <p><b>العميل المفوتر / Client:</b> ${trans.arabicRecipientName}</p>
            <p><b>الوصف / Itemization:</b> ${trans.description}</p>

            <table>
                <thead>
                    <tr>
                        <th>البند / Description</th>
                        <th>المبلغ الأساسي / Base Amount</th>
                        <th>ضريبة القيمة المضافة 15% / VAT Amount</th>
                        <th>الصافي شامل الضريبة / Total Settle Price</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>تصميم وتنفيذ لوحات دعائية مع التركيب</td>
                        <td>$${String.format("%.2f", vatableAmt)}</td>
                        <td>$${String.format("%.2f", vatAmount)}</td>
                        <td><b>$${String.format("%.2f", trans.amount)}</b></td>
                    </tr>
                </tbody>
            </table>

            <div class="total-block">
                <p><b>المبلغ الاجمالي الخاضع للضريبة:</b> $${String.format("%.2f", vatableAmt)}</p>
                <p><b>مجموع ضريبة القيمة المضافة:</b> $${String.format("%.2f", vatAmount)}</p>
                <h4 style="color: #BF80FF;"><b>المجموع الكلي شامل الضريبة (Total Settle Amount): $${String.format("%.2f", trans.amount)}</b></h4>
            </div>

            <hr style="border: 0; border-top: 1px dashed #CBD5E1; margin-top: 40px;">
            <p style="text-align: center; color: #64748B; font-size: 11px;">شكرًا لثقتكم بوكالة يافطة. Olaya District, Creative Space, Riyadh, Saudi Arabia</p>
        </body>
        </html>
    """.trimIndent()

    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            
            // Create target Print job natively
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val printAdapter = webView.createPrintDocumentAdapter("Yafta_Invoice_${trans.id}")
            val jobName = "Yafta Invoice Print"
            
            printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
        }
    }
    webView.loadDataWithBaseURL(null, htmlDocument, "text/html", "UTF-8", null)
}

// Simple color helper declarations matching Theme definitions
@Composable
fun PixelCriticalColorHelper() = SignalCritical
