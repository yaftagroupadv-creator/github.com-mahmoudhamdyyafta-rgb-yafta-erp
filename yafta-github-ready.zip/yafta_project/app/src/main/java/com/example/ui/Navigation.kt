package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.MainActivity
import com.example.data.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel
import kotlinx.coroutines.launch

object NavRoutes {
    const val AUTH = "auth"
    const val DASHBOARD = "dashboard"
    const val CRM = "crm"
    const val PROJECTS = "projects"
    const val INVENTORY = "inventory"
    const val FINANCE = "finance"
    const val HR = "hr_tasks"
    const val DESIGN_STUDIO = "design_studio"
    const val GEMINI_AI = "gemini_ai"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"
}

data class NavigationTab(
    val route: String,
    val title: String,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector,
    val category: String = "Operations" // Operations, Creative, Support
)

val MainNavigationTabs = listOf(
    NavigationTab(NavRoutes.DASHBOARD, "الرئيسية / Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard, "Operations"),
    NavigationTab(NavRoutes.DESIGN_STUDIO, "التصميم / Design Studio", Icons.Filled.Palette, Icons.Outlined.Palette, "Creative"),
    NavigationTab(NavRoutes.CRM, "العملاء / CRM", Icons.Filled.Business, Icons.Outlined.Business, "Operations"),
    NavigationTab(NavRoutes.FINANCE, "المالية / Finance", Icons.Filled.Payments, Icons.Outlined.Payments, "Support"),
    NavigationTab(NavRoutes.INVENTORY, "المستودع / Warehouse", Icons.Filled.Store, Icons.Outlined.Store, "Operations"),
    NavigationTab(NavRoutes.REPORTS, "التقارير / Reports", Icons.Filled.Assessment, Icons.Outlined.Assessment, "Support"),
    NavigationTab(NavRoutes.HR, "الموظفين / Staff", Icons.Filled.Groups, Icons.Outlined.Groups, "Support"),
    NavigationTab(NavRoutes.SETTINGS, "النظام / System Center", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings, "Support")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigationShell(
    viewModel: YaftaViewModel,
    onArabicPdfPrint: (String, Double, Long, String, Map<String, String>) -> Unit
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NavRoutes.AUTH
    val currentSessionUser by viewModel.currentSessionUser.collectAsState()

    // Determine device screen properties for adaptive scaling
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    LaunchedEffect(currentSessionUser) {
        if (currentSessionUser == null) {
            if (currentRoute != NavRoutes.AUTH) {
                navController.navigate(NavRoutes.AUTH) {
                    popUpTo(0) { inclusive = true }
                }
            }
        } else if (currentRoute == NavRoutes.AUTH) {
            navController.navigate(NavRoutes.DASHBOARD) {
                popUpTo(NavRoutes.AUTH) { inclusive = true }
            }
        }
    }

    var showAiSidebar by remember { mutableStateOf(false) }

    if (currentRoute == NavRoutes.AUTH) {
        Box(modifier = Modifier.fillMaxSize().background(DeepSlateBg)) {
            ShellNavHost(
                navController = navController,
                viewModel = viewModel,
                onArabicPdfPrint = onArabicPdfPrint
            )
        }
    } else {
        if (!isTablet) {
            val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
            val scope = rememberCoroutineScope()

            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    AgencySidebarDrawerContent(
                        navController = navController,
                        currentRoute = currentRoute,
                        user = currentSessionUser,
                        onLogout = { viewModel.logout() },
                        onAiCopilotClick = { showAiSidebar = true },
                        onCloseDrawer = { scope.launch { drawerState.close() } }
                    )
                },
                gesturesEnabled = currentRoute != NavRoutes.DESIGN_STUDIO
            ) {
                Scaffold(
                    topBar = {
                        if (currentRoute != NavRoutes.DESIGN_STUDIO) {
                            AgencyTopAppBar(
                                currentRoute = currentRoute,
                                onMenuClick = { scope.launch { drawerState.open() } },
                                onAiClick = { showAiSidebar = !showAiSidebar }
                            )
                        }
                    },
                    bottomBar = {
                        if (currentRoute != NavRoutes.DESIGN_STUDIO) {
                            AgencyBottomBar(navController = navController, currentRoute = currentRoute)
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(DeepSlateBg)
                    ) {
                        ShellNavHost(
                            navController = navController,
                            viewModel = viewModel,
                            onArabicPdfPrint = onArabicPdfPrint
                        )

                        GeminiCopilotSidebar(
                            isOpen = showAiSidebar,
                            onClose = { showAiSidebar = false },
                            viewModel = viewModel
                        )
                    }
                }
            }
        } else {
            // Adaptive Tablet Layout with Permanent Collapsible Sidebar
            Scaffold { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(DeepSlateBg)
                ) {
                    CollapsibleSidebar(
                        navController = navController,
                        currentRoute = currentRoute,
                        user = currentSessionUser,
                        onLogout = { viewModel.logout() },
                        onAiCopilotClick = { showAiSidebar = true }
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .background(DeepSlateBg)
                    ) {
                        ShellNavHost(
                            navController = navController,
                            viewModel = viewModel,
                            onArabicPdfPrint = onArabicPdfPrint
                        )

                        GeminiCopilotSidebar(
                            isOpen = showAiSidebar,
                            onClose = { showAiSidebar = false },
                            viewModel = viewModel
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ShellNavHost(
    navController: NavHostController,
    viewModel: YaftaViewModel,
    onArabicPdfPrint: (String, Double, Long, String, Map<String, String>) -> Unit,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = NavRoutes.AUTH,
        modifier = modifier.fillMaxSize()
    ) {
        composable(NavRoutes.AUTH) {
            AuthScreenLayout(viewModel = viewModel)
        }
        composable(NavRoutes.DASHBOARD) {
            DashboardScreenLayout(
                viewModel = viewModel,
                onNavigateToTab = { route -> navController.navigate(route) }
            )
        }
        composable(NavRoutes.CRM) {
            CrmScreenLayout(viewModel = viewModel)
        }
        composable(NavRoutes.PROJECTS) {
            ProjectsScreenLayout(viewModel = viewModel)
        }
        composable(NavRoutes.INVENTORY) {
            InventoryScreenLayout(viewModel = viewModel)
        }
        composable(NavRoutes.DESIGN_STUDIO) {
            DesignStudioScreenLayout(
                viewModel = viewModel,
                onCreatedLead = { navController.navigate(NavRoutes.CRM) },
                onReturnToDashboard = { navController.navigate(NavRoutes.DASHBOARD) },
                onNavigateToSettings = { navController.navigate(NavRoutes.SETTINGS) }
            )
        }
        composable(NavRoutes.GEMINI_AI) {
            GeminiAiScreenLayout(viewModel = viewModel)
        }
        composable(NavRoutes.FINANCE) {
            FinanceScreenLayout(
                viewModel = viewModel,
                onArabicPdfPrint = onArabicPdfPrint
            )
        }
        composable(NavRoutes.HR) {
            HrTasksScreenLayout(viewModel = viewModel)
        }
        composable(NavRoutes.REPORTS) {
            ReportsScreenLayout(viewModel = viewModel)
        }
        composable(NavRoutes.SETTINGS) {
            SettingsScreenLayout(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgencyTopAppBar(
    currentRoute: String,
    onMenuClick: () -> Unit,
    onAiClick: () -> Unit = {}
) {
    val activeTab = MainNavigationTabs.find { it.route == currentRoute }
    val titleEng = activeTab?.title?.split("/")?.lastOrNull()?.trim() ?: "YAFTA"
    val titleAra = activeTab?.title?.split("/")?.firstOrNull()?.trim() ?: "يافطة"

    Surface(
        color = DarkSlateCard,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .statusBarsPadding()
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onMenuClick,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Menu,
                    contentDescription = "Open Navigation Menu",
                    tint = NeonPurple,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = titleAra,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonPurple,
                        fontSize = 15.sp
                    )
                )
                Text(
                    text = titleEng.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = BrushedTitanium,
                        letterSpacing = 1.sp,
                        fontSize = 9.sp
                    )
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onAiClick,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(NeonPurple.copy(alpha = 0.15f))
                        .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "Open Gemini Copilot",
                        tint = NeonPurple,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BorderGlass)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Verified,
                        contentDescription = "Status Live",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AgencyBottomBar(navController: NavHostController, currentRoute: String) {
    val coreTabs = MainNavigationTabs.filter { 
        it.route in listOf(NavRoutes.DASHBOARD, NavRoutes.DESIGN_STUDIO, NavRoutes.CRM, NavRoutes.FINANCE, NavRoutes.SETTINGS) 
    }

    NavigationBar(
        containerColor = DarkSlateCard,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        coreTabs.forEach { tab ->
            val isSelected = currentRoute == tab.route
            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    if (currentRoute != tab.route) {
                        navController.navigate(tab.route) {
                            popUpTo(NavRoutes.DASHBOARD) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = {
                    Icon(
                        imageVector = if (isSelected) tab.activeIcon else tab.inactiveIcon,
                        contentDescription = tab.title,
                        tint = if (isSelected) NeonPurple else TextSilver
                    )
                },
                label = {
                    val labelText = tab.title.split("/").lastOrNull()?.trim() ?: tab.title
                    Text(
                        text = labelText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 10.sp
                        ),
                        color = if (isSelected) NeonPurple else TextSilver
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = BorderGlass
                )
            )
        }
    }
}

@Composable
fun CollapsibleSidebar(
    navController: NavHostController,
    currentRoute: String,
    user: User?,
    onLogout: () -> Unit,
    onAiCopilotClick: () -> Unit = {}
) {
    var isExpanded by remember { mutableStateOf(true) }
    val width by animateDpAsState(
        targetValue = if (isExpanded) 260.dp else 76.dp,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "sidebar_width"
    )

    Box(
        modifier = Modifier
            .fillMaxHeight()
            .width(width)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(BorderGlass, Color.Transparent)),
                shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            )
    ) {
        SidebarContent(
            navController = navController,
            currentRoute = currentRoute,
            user = user,
            onLogout = onLogout,
            isExpanded = isExpanded,
            onToggleExpand = { isExpanded = !isExpanded },
            onAiCopilotClick = onAiCopilotClick
        )
    }
}

@Composable
fun AgencySidebarDrawerContent(
    navController: NavHostController,
    currentRoute: String,
    user: User?,
    onLogout: () -> Unit,
    onAiCopilotClick: () -> Unit = {},
    onCloseDrawer: () -> Unit
) {
    ModalDrawerSheet(
        drawerContainerColor = DeepSlateBg,
        drawerContentColor = BrushedTitanium,
        modifier = Modifier
            .width(280.dp)
            .fillMaxHeight()
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(BorderGlass, Color.Transparent)),
                shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            ),
        windowInsets = WindowInsets.systemBars
    ) {
        SidebarContent(
            navController = navController,
            currentRoute = currentRoute,
            user = user,
            onLogout = onLogout,
            isExpanded = true,
            isDrawer = true,
            onToggleExpand = {},
            onItemClicked = onCloseDrawer,
            onAiCopilotClick = onAiCopilotClick
        )
    }
}

@Composable
fun SidebarContent(
    navController: NavHostController,
    currentRoute: String,
    user: User?,
    onLogout: () -> Unit,
    isExpanded: Boolean,
    isDrawer: Boolean = false,
    onToggleExpand: () -> Unit = {},
    onItemClicked: () -> Unit = {},
    onAiCopilotClick: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkSlateCard)
            .padding(vertical = 16.dp, horizontal = if (isExpanded) 16.dp else 8.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (isExpanded) Arrangement.SpaceBetween else Arrangement.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(if (isExpanded) 42.dp else 48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Brush.linearGradient(listOf(NeonPurple, NeonCyan)))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Verified,
                            contentDescription = "Yafta Logo",
                            tint = DeepSlateBg,
                            modifier = Modifier.size(if (isExpanded) 22.dp else 26.dp)
                        )
                    }
                    if (isExpanded) {
                        Column {
                            Text(
                                text = "يافطة للدعاية",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NeonPurple,
                                    fontSize = 15.sp
                                )
                            )
                            Text(
                                text = "YAFTA LEADER",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = BrushedTitanium,
                                    fontSize = 8.sp
                                )
                            )
                        }
                    }
                }

                if (isExpanded && !isDrawer) {
                    IconButton(
                        onClick = onToggleExpand,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ChevronLeft,
                            contentDescription = "Collapse Sidebar",
                            tint = TextSilver,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // User Profile Section
            if (isExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DeepInkShadow.copy(alpha = 0.5f))
                        .border(1.dp, BorderGlass, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BorderGlass)
                        ) {
                            Text(
                                text = (user?.name ?: "O").take(1).uppercase(),
                                color = NeonPurple,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }

                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = user?.name ?: "Operator Console",
                                color = BrushedTitanium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = user?.email ?: "ops@yafta.com",
                                color = TextSilver,
                                fontSize = 9.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonPurple.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = user?.role?.uppercase() ?: "ADMIN",
                                color = NeonPurple,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            } else {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(DeepInkShadow)
                        .border(1.dp, BorderGlass, CircleShape)
                        .clickable { onToggleExpand() }
                ) {
                    Text(
                        text = (user?.role ?: "A").take(1).uppercase(),
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Divider(color = BorderGlass)

            // INTERACTIVE AI COPILOT LAUNCHER
            if (isExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NeonPurple.copy(alpha = 0.12f))
                        .border(1.dp, NeonPurple.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .clickable { 
                            onAiCopilotClick()
                            onItemClicked()
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(NeonPurple.copy(alpha = 0.25f))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = NeonPurple,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini Copilot",
                                color = BrushedTitanium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "المساعد الذكي جيميناي",
                                color = NeonPurple,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(NeonPurple)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("LIVE", color = DeepSlateBg, fontSize = 7.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            } else {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NeonPurple.copy(alpha = 0.15f))
                        .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .clickable { onAiCopilotClick() }
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "Gemini Copilot",
                        tint = NeonPurple,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Divider(color = BorderGlass)

            // Navigation Items List
            val groupedTabs = MainNavigationTabs.groupBy { it.category }
            val categories = listOf("Operations", "Creative", "Support")
            val categoryLabels = mapOf(
                "Operations" to "OPERATIONS / إدارة العمليات",
                "Creative" to "CREATIVE DESK / لوحة التصميم",
                "Support" to "ENTERPRISE SUPPORT / النظام والدعم"
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
            ) {
                categories.forEach { cat ->
                    val tabsInCat = groupedTabs[cat] ?: emptyList()
                    if (tabsInCat.isNotEmpty()) {
                        if (isExpanded) {
                            Text(
                                text = categoryLabels[cat] ?: cat,
                                color = NeonAmber,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp, start = 4.dp)
                            )
                        }

                        tabsInCat.forEach { tab ->
                            val isSelected = currentRoute == tab.route
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) BorderGlass else Color.Transparent)
                                    .clickable {
                                        if (currentRoute != tab.route) {
                                            navController.navigate(tab.route) {
                                                popUpTo(NavRoutes.DASHBOARD) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                        onItemClicked()
                                    }
                                    .padding(horizontal = if (isExpanded) 12.dp else 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = if (isExpanded) Arrangement.Start else Arrangement.Center
                            ) {
                                if (isSelected && isExpanded) {
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(20.dp)
                                            .clip(RoundedCornerShape(1.5.dp))
                                            .background(NeonPurple)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                Icon(
                                    imageVector = if (isSelected) tab.activeIcon else tab.inactiveIcon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) NeonPurple else TextSilver,
                                    modifier = Modifier.size(if (isExpanded) 20.dp else 24.dp)
                                )

                                if (isExpanded) {
                                    Spacer(modifier = Modifier.width(12.dp))
                                    val parts = tab.title.split("/")
                                    val partAra = parts.firstOrNull()?.trim() ?: ""
                                    val partEng = parts.lastOrNull()?.trim() ?: ""
                                    
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = partEng,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) BrushedTitanium else TextSilver
                                            )
                                        )
                                        Text(
                                            text = partAra,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 9.sp,
                                                color = if (isSelected) NeonCyan else TextSilver.copy(alpha = 0.7f)
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom section
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Divider(color = BorderGlass)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onLogout() },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (isExpanded) Arrangement.Start else Arrangement.Center
            ) {
                if (isExpanded) Spacer(modifier = Modifier.width(12.dp))
                Icon(
                    imageVector = Icons.Filled.Logout,
                    contentDescription = "Log Out Session",
                    tint = SignalCritical,
                    modifier = Modifier.size(if (isExpanded) 20.dp else 24.dp)
                )
                if (isExpanded) {
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Log Out System",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SignalCritical
                            )
                        )
                        Text(
                            text = "خروج من النظام",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                color = SignalCritical.copy(alpha = 0.8f)
                            )
                        )
                    }
                }
            }

            if (!isExpanded && !isDrawer) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onToggleExpand() },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.ChevronRight,
                        contentDescription = "Expand Sidebar",
                        tint = NeonCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
