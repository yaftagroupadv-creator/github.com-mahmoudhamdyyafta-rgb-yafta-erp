package com.example.ui.screens

import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.data.*
import com.example.viewmodel.YaftaViewModel
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreenLayout(viewModel: YaftaViewModel) {
    val context = LocalContext.current

    // Collect variables from ViewModel
    val activeLeads by viewModel.leadsList.collectAsState()
    val activeProjects by viewModel.projectsList.collectAsState()
    val financeRecords by viewModel.transactionsList.collectAsState()
    val materialsList by viewModel.inventoryList.collectAsState()

    // Calculate executive parameters
    val totalLeads = activeLeads.size
    val convertedLeads = activeLeads.count { it.status == "Converted" }
    val conversionRate = if (totalLeads > 0) (convertedLeads.toDouble() / totalLeads * 100).toInt() else 0

    val completedProjects = activeProjects.count { it.status == "Completed" || it.status == "Installation" }
    val processingProjects = activeProjects.size - completedProjects

    val totalRevenue = financeRecords.filter { it.type == "Invoice Income" }.sumOf { it.amount }
    val totalExpenses = financeRecords.filter { it.type != "Invoice Income" }.sumOf { it.amount }
    val netProfit = totalRevenue - totalExpenses

    val lowStockMaterialsCount = materialsList.count { it.currentStock < it.minimumStockAlert }

    var selectedSection by remember { mutableStateOf("Performance") } // "Performance", "Finance", "Inventory"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
            .testTag("reports_screeen")
    ) {
        // Executive header & visual logo blur highlight
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "YAFTA EXECUTIVE INTEL",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = NeonPurple,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                )
                Text(
                    text = "Analytical Reports & Yield Performance",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = BrushedTitanium,
                        fontWeight = FontWeight.Black
                    )
                )
            }

            // Export executive summary print link button
            Button(
                onClick = {
                    triggerReportsPrint(
                        context = context,
                        leads = totalLeads,
                        converted = convertedLeads,
                        conversion = conversionRate,
                        completed = completedProjects,
                        processing = processingProjects,
                        revenue = totalRevenue,
                        expenses = totalExpenses,
                        profit = netProfit,
                        lowStock = lowStockMaterialsCount
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Print,
                    contentDescription = null,
                    tint = DeepSlateBg,
                    modifier = Modifier.size(16.dp).padding(end = 4.dp)
                )
                Text("Print Report", color = DeepSlateBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Subnavigation Section picker
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(DarkSlateCard)
                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("Performance", "Finance", "Inventory").forEach { sec ->
                val isSelected = selectedSection == sec
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) NeonPurple.copy(alpha = 0.2f) else Color.Transparent)
                        .border(1.dp, if (isSelected) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                        .clickable { selectedSection = sec }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sec,
                        color = if (isSelected) NeonPurple else TextSilver,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Animated Screen sections
        AnimatedContent(
            targetState = selectedSection,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            }
        ) { section ->
            when (section) {
                "Performance" -> {
                    PerformanceReportSection(
                        totalLeads = totalLeads,
                        convertedLeads = convertedLeads,
                        conversionRate = conversionRate,
                        completedProjects = completedProjects,
                        processingProjects = processingProjects
                    )
                }
                "Finance" -> {
                    FinanceReportSection(
                        revenue = totalRevenue,
                        expenses = totalExpenses,
                        profit = netProfit
                    )
                }
                "Inventory" -> {
                    InventoryReportSection(
                        materialsList = materialsList,
                        lowStockCount = lowStockMaterialsCount
                    )
                }
            }
        }
    }
}

@Composable
fun PerformanceReportSection(
    totalLeads: Int,
    convertedLeads: Int,
    conversionRate: Int,
    completedProjects: Int,
    processingProjects: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        // Mini stats grids
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Card(
                modifier = Modifier.weight(1f).border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Total CRM Leads", color = TextSilver, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$totalLeads", color = BrushedTitanium, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("$convertedLeads Converted", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            Card(
                modifier = Modifier.weight(1f).border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Conversion Rate", color = TextSilver, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$conversionRate%", color = NeonPurple, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Sales efficiency standard", color = TextSilver, fontSize = 11.sp)
                }
            }
        }

        // Custom drawn visual conversion chart
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "CRM Conversion Acquisition Funnel",
                    color = BrushedTitanium,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(24.dp))

                // Custom conversion funnel drawing
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val midX = size.width / 2
                        val height = size.height

                        // Funnel layers path
                        val topWidth = size.width * 0.8f
                        val midWidth = size.width * 0.5f
                        val bottomWidth = size.width * 0.2f

                        val linePath = Path().apply {
                            moveTo(midX - topWidth / 2, 0f)
                            lineTo(midX + topWidth / 2, 0f)
                            lineTo(midX + midWidth / 2, height * 0.5f)
                            lineTo(midX + bottomWidth / 2, height)
                            lineTo(midX - bottomWidth / 2, height)
                            lineTo(midX - midWidth / 2, height * 0.5f)
                            close()
                        }

                        // Fill with dual color neon gradients
                        drawPath(
                            path = linePath,
                            brush = Brush.verticalGradient(
                                colors = listOf(NeonPurple.copy(alpha = 0.15f), NeonCyan.copy(alpha = 0.15f))
                            )
                        )

                        // Outline contour
                        drawPath(
                            path = linePath,
                            color = BorderGlass,
                            style = Stroke(width = 2.dp.toPx())
                        )

                        // Draw level marks
                        drawLine(
                            color = BorderGlass,
                            start = androidx.compose.ui.geometry.Offset(midX - midWidth / 2, height * 0.5f),
                            end = androidx.compose.ui.geometry.Offset(midX + midWidth / 2, height * 0.5f),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    // Funnel text labels overlay
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Discovery Stage", color = BrushedTitanium, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("$totalLeads raw incoming briefs received", color = TextSilver, fontSize = 10.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Settle & Invoice", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("$convertedLeads commissions approved", color = TextSilver, fontSize = 10.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Conversion: $conversionRate%", color = NeonPurple, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        // Manufacturing fabrication pipeline load metric
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Fabrication Pipeline Capacity Load",
                    color = BrushedTitanium,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NeonCyan))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Fabricating ($processingProjects Signs)", color = TextSilver, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NeonPurple))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Completed ($completedProjects Signs)", color = TextSilver, fontSize = 11.sp)
                        }
                    }

                    // Custom horizontal pipeline fill meter
                    val totalProjects = completedProjects + processingProjects
                    val progress = if (totalProjects > 0) completedProjects.toFloat() / totalProjects else 0f

                    Box(
                        modifier = Modifier
                            .width(180.dp)
                            .height(24.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BorderGlass)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(if (progress > 0) progress else 0.05f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.horizontalGradient(listOf(NeonCyan, NeonPurple)))
                        )
                        Text(
                            text = "${(progress * 100).toInt()}% Done",
                            color = DeepSlateBg,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FinanceReportSection(
    revenue: Double,
    expenses: Double,
    profit: Double
) {
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        // Finance comparative grid
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Card(
                modifier = Modifier.weight(1f).border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Commission Cash Inflow", color = TextSilver, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$${String.format(Locale.US, "%.1f", revenue)}", color = NeonCyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Total incoming billing ledger", color = TextSilver, fontSize = 10.sp)
                }
            }

            Card(
                modifier = Modifier.weight(1f).border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Manufacturing Costs", color = TextSilver, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$${String.format(Locale.US, "%.1f", expenses)}", color = NeonAmber, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Salaries & stock expense", color = TextSilver, fontSize = 10.sp)
                }
            }
        }

        // Profit card
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Business Net Operating Yield", color = TextSilver, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$${String.format(Locale.US, "%.2f", profit)}",
                            color = if (profit >= 0) NeonCyan else SignalCritical,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (profit >= 0) NeonCyan.copy(alpha = 0.15f) else SignalCritical.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (profit >= 0) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
                            contentDescription = null,
                            tint = if (profit >= 0) NeonCyan else SignalCritical,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                // Custom Canvas graphical revenue bar comparative
                val totalLedger = revenue + expenses
                val scaleFactor = if (totalLedger > 0) revenue / totalLedger else 0.5

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BorderGlass)
                ) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .weight(if (scaleFactor > 0) scaleFactor.toFloat() else 0.1f)
                                .background(NeonCyan)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .weight(if (1 - scaleFactor > 0) (1 - scaleFactor).toFloat() else 0.1f)
                                .background(NeonAmber)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Income Margin (${((scaleFactor)*100).toInt()}% of total flow)", color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Cost Burden (${((1-scaleFactor)*100).toInt()}% of total flow)", color = NeonAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun InventoryReportSection(
    materialsList: List<InventoryItem>,
    lowStockCount: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "Warehouse Material Stock Safety Level",
                color = BrushedTitanium,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (lowStockCount > 0) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SignalCritical.copy(alpha = 0.1f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = null,
                        tint = SignalCritical,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Warehouse Warning: $lowStockCount raw materials current inventory are below caution points! Fabricators may experience bottleneck down-times.",
                        color = SignalCritical,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(NeonCyan.copy(alpha = 0.1f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "All raw commodities fully replenished. Fabrication workshop optimal safety buffer is active.",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Simple micro table representing material list
            materialsList.take(6).forEach { item ->
                val isCritical = item.currentStock < item.minimumStockAlert
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .border(
                            1.dp,
                            if (isCritical) SignalCritical.copy(alpha = 0.2f) else Color.Transparent,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(vertical = 4.dp, horizontal = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(item.name, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Category: ${item.materialType}", color = TextSilver, fontSize = 10.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${item.currentStock} Units",
                            color = if (isCritical) SignalCritical else NeonCyan,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isCritical) SignalCritical else NeonCyan)
                        )
                    }
                }
                Divider(color = BorderGlass.copy(alpha = 0.5f))
            }
        }
    }
}

// Native executive report printing feature via WebView print protocol
fun triggerReportsPrint(
    context: android.content.Context,
    leads: Int,
    converted: Int,
    conversion: Int,
    completed: Int,
    processing: Int,
    revenue: Double,
    expenses: Double,
    profit: Double,
    lowStock: Int
) {
    val printerService = context.getSystemService(android.content.Context.PRINT_SERVICE) as? android.print.PrintManager
    if (printerService == null) {
        Toast.makeText(context, "Native print framework unavailable.", Toast.LENGTH_SHORT).show()
        return
    }

    val htmlDocument = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Yafta Executive Report Summary</title>
            <style>
                body {
                    font-family: 'Segoe UI', Arial, sans-serif;
                    background-color: #ffffff;
                    color: #121212;
                    margin: 40px;
                    direction: ltr;
                }
                .header-table {
                    width: 100%;
                    border-bottom: 3px double #6200EE;
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                }
                .logo {
                    font-size: 28px;
                    font-weight: 900;
                    color: #6200EE;
                    letter-spacing: 2px;
                }
                .grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 20px;
                    margin-bottom: 30px;
                }
                .metrics-card {
                    border: 1px solid #e0e0e0;
                    border-radius: 8px;
                    padding: 20px;
                    background-color: #fafafa;
                }
                .metrics-card h3 {
                    margin: 0 0 10px 0;
                    color: #6200EE;
                }
                .val-highlight {
                    font-size: 24px;
                    font-weight: 800;
                    color: #121212;
                }
                .disclaimer {
                    font-size: 10px;
                    color: #777777;
                    text-align: center;
                    border-top: 1px solid #e0e0e0;
                    padding-top: 20px;
                    margin-top: 50px;
                }
            </style>
        </head>
        <body>
            <table class="header-table">
                <tr>
                    <td>
                        <div class="logo">YAFTA BRANDING STUDIO</div>
                        <div style="font-size: 13px; color: #555555;">Executive Strategic Business Yield Performance</div>
                    </td>
                    <td align="right" style="font-size: 12px; color: #777777;">
                        Date Generated: ${Date()}<br>
                        Confidentiality: Internal Executive Use Only
                    </td>
                </tr>
            </table>

            <h2>1. SALES & CONVERSION ANALYSIS</h2>
            <div class="grid">
                <div class="metrics-card">
                    <h3>CRM Acquisition Pipelines</h3>
                    <p>Total Leads Captured: <strong>$leads</strong></p>
                    <p>Successfully Settle & Commissioned: <strong>$converted</strong></p>
                </div>
                <div class="metrics-card">
                    <h3>Yield Profit Efficiency</h3>
                    <p class="val-highlight">$conversion% Effective Rate</p>
                    <p style="margin: 0; color: #555555;">Formula parameter: (Converted / Initial registered briefs)</p>
                </div>
            </div>

            <h2>2. WORKSHOP PIPELINE & LOGISTICS</h2>
            <div class="grid">
                <div class="metrics-card">
                    <h3>Signboard Fabrication Backlog</h3>
                    <p>Active Work in Manufacturing: <strong>$processing</strong> signs</p>
                    <p>Delivered / Installed signs: <strong>$completed</strong> signs</p>
                </div>
                <div class="metrics-card">
                    <h3>Warehouse Stock Buffer Alert</h3>
                    <p class="val-highlight" style="color: ${if (lowStock > 0) "#B00020" else "#03DAC6"};">$lowStock Critical Assets</p>
                    <p style="margin: 0; color: #555555;">Meters of neon coil or LED elements below target cautions</p>
                </div>
            </div>

            <h2>3. FINANCIAL LEDGER STATS</h2>
            <div class="grid">
                <div class="metrics-card">
                    <h3>Total Cash Flow Inflow</h3>
                    <p class="val-highlight" style="color: #03DAC6;">$${String.format(Locale.US, "%.2f", revenue)}</p>
                </div>
                <div class="metrics-card">
                    <h3>Total Cash Outflow / Burden</h3>
                    <p class="val-highlight" style="color: #CF6679;">$${String.format(Locale.US, "%.2f", expenses)}</p>
                </div>
            </div>

            <div style="background-color: #6200EE; color: #ffffff; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
                <h3 style="margin: 0 0 10px 0;">NET OPERATING MARGIN ESTIMATE</h3>
                <div style="font-size: 32px; font-weight: 900;">$${String.format(Locale.US, "%.2f", profit)}</div>
            </div>

            <div class="disclaimer">
                Notice: This printable analytical dispatch was compiled automatically via Yafta Sandbox REST architecture. Secure cloud integrity verified.
            </div>
        </body>
        </html>
    """.trimIndent()

    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            val printAdapter = webView.createPrintDocumentAdapter("Yafta Executive Brief")
            printerService.print(
                "Yafta Executive Summary",
                printAdapter,
                android.print.PrintAttributes.Builder().build()
            )
        }
    }
    webView.loadDataWithBaseURL(null, htmlDocument, "text/html", "utf-8", null)
}
