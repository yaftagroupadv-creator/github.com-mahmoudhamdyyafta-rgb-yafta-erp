package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun GeminiCopilotSidebar(
    isOpen: Boolean,
    onClose: () -> Unit,
    viewModel: YaftaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Observe State from ViewModel
    val aiIsLoading by viewModel.aiIsLoading.collectAsState()
    val aiCopywritingResult by viewModel.aiCopywritingResult.collectAsState()
    val aiMaterialResult by viewModel.aiMaterialResult.collectAsState()
    val aiBriefResult by viewModel.aiBriefResult.collectAsState()
    val aiStudioResult by viewModel.aiStudioResult.collectAsState()

    var activeCopilotTab by remember { mutableStateOf("Slogans") } // "Slogans", "Advisor", "BriefRefiner", "Chat"

    // Inputs - Rebranded from demo data to Yafta For Advertising defaults
    var brandName by remember { mutableStateOf("Yafta Premium") }
    var vibeKeys by remember { mutableStateOf("Sleek modern minimalism, luxury gold accents, brushed metal texture") }
    var signboardText by remember { mutableStateOf("YAFTA") }

    var widthCm by remember { mutableStateOf("150") }
    var heightCm by remember { mutableStateOf("100") }
    var lettersCount by remember { mutableStateOf("5") }
    var primaryMaterial by remember { mutableStateOf("3D Acrylic & LED Modules") }

    var rawBriefNotes by remember { mutableStateOf("Client wants an upscale brushed-titanium advertising signboard on King Fahd Road with champagne-gold back-lit LED letters. Text should read 'YAFTA'. The overall finish must feel ultra-luxurious, tailored for high-end boutique storefronts.") }

    var customChatPrompt by remember { mutableStateOf("Suggest matching background and text colors for a luxurious jewelry store signboard.") }

    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        // Backdrop Overlay Scrim
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.6f))
                .clickable { onClose() }
        ) {
            // Main Sliding Menu - Adaptive and Reduced Width
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.82f)
                    .widthIn(max = 310.dp)
                    .background(DarkSlateCard)
                    .border(1.dp, BorderGlass, RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp))
                    .clickable(enabled = false) {} // Prevent click-through closing
                    .align(Alignment.CenterEnd)
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = NeonPurple,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "GEMINI COPILOT",
                                    color = BrushedTitanium,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "المساعد الذكي جيميناي",
                                    color = NeonPurple,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        IconButton(
                            onClick = onClose,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(BorderGlass)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close Copilot",
                                tint = BrushedTitanium,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Divider(color = BorderGlass, modifier = Modifier.padding(bottom = 12.dp))

                    // AI Tool Tab Selector (Horizontal scrolling)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("Slogans", "Marketing / ترويج", NeonPurple),
                            Triple("Advisor", "Specs / مواد", NeonCyan),
                            Triple("BriefRefiner", "Brief / فكرة", NeonAmber),
                            Triple("Chat", "Ask AI / استشارة", NeonMint)
                        ).forEach { (tag, label, themeColor) ->
                            val isSelected = activeCopilotTab == tag
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) themeColor.copy(alpha = 0.25f) else BorderGlass)
                                    .border(
                                        1.dp,
                                        if (isSelected) themeColor else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { activeCopilotTab = tag }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) BrushedTitanium else TextSilver,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    // Dynamic Control Fields block based on active tab
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            when (activeCopilotTab) {
                                "Slogans" -> {
                                    Text(
                                        text = "TAGLINE GENERATOR / كاتب إعلاني",
                                        color = NeonPurple,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    OutlinedTextField(
                                        value = brandName,
                                        onValueChange = { brandName = it },
                                        label = { Text("Brand Name / الاسم التجاري", color = TextSilver, fontSize = 11.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonPurple,
                                            unfocusedBorderColor = BorderGlass,
                                            focusedTextColor = BrushedTitanium,
                                            unfocusedTextColor = BrushedTitanium
                                        ),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                                    )
                                    OutlinedTextField(
                                        value = vibeKeys,
                                        onValueChange = { vibeKeys = it },
                                        label = { Text("Design Vibe / طبيعة الهوية", color = TextSilver, fontSize = 11.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonPurple,
                                            unfocusedBorderColor = BorderGlass,
                                            focusedTextColor = BrushedTitanium,
                                            unfocusedTextColor = BrushedTitanium
                                        ),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                                    )
                                    OutlinedTextField(
                                        value = signboardText,
                                        onValueChange = { signboardText = it },
                                        label = { Text("Signboard text / النص المكتوب", color = TextSilver, fontSize = 11.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonPurple,
                                            unfocusedBorderColor = BorderGlass,
                                            focusedTextColor = BrushedTitanium,
                                            unfocusedTextColor = BrushedTitanium
                                        ),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                                    )
                                    Button(
                                        onClick = {
                                            viewModel.triggerAiSlogans(brandName, vibeKeys, signboardText)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Draft Slogans / ابتكار نصوص", color = DeepSlateBg, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }

                                "Advisor" -> {
                                    Text(
                                        text = "MATERIAL QUANTITIES ESTIMATOR / مقدّر المواد والخصائص",
                                        color = NeonCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = widthCm,
                                            onValueChange = { widthCm = it },
                                            label = { Text("Widthcm / عرض سم", color = TextSilver, fontSize = 10.sp) },
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = NeonCyan,
                                                unfocusedBorderColor = BorderGlass,
                                                focusedTextColor = BrushedTitanium,
                                                unfocusedTextColor = BrushedTitanium
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = heightCm,
                                            onValueChange = { heightCm = it },
                                            label = { Text("Heightcm / ارتفاع سم", color = TextSilver, fontSize = 10.sp) },
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = NeonCyan,
                                                unfocusedBorderColor = BorderGlass,
                                                focusedTextColor = BrushedTitanium,
                                                unfocusedTextColor = BrushedTitanium
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    OutlinedTextField(
                                        value = lettersCount,
                                        onValueChange = { lettersCount = it },
                                        label = { Text("Letters Count / عدد الحروف", color = TextSilver, fontSize = 11.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonCyan,
                                            unfocusedBorderColor = BorderGlass,
                                            focusedTextColor = BrushedTitanium,
                                            unfocusedTextColor = BrushedTitanium
                                        ),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                                    )
                                    OutlinedTextField(
                                        value = primaryMaterial,
                                        onValueChange = { primaryMaterial = it },
                                        label = { Text("Target Material / المادة الأساسية", color = TextSilver, fontSize = 11.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonCyan,
                                            unfocusedBorderColor = BorderGlass,
                                            focusedTextColor = BrushedTitanium,
                                            unfocusedTextColor = BrushedTitanium
                                        ),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                                    )
                                    Button(
                                        onClick = {
                                            val w = widthCm.toDoubleOrNull() ?: 150.0
                                            val h = heightCm.toDoubleOrNull() ?: 100.0
                                            val count = lettersCount.toIntOrNull() ?: 6
                                            viewModel.triggerAiMaterials(w, h, count, primaryMaterial)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Estimate Specs / تقدير الكميات", color = DeepSlateBg, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }

                                "BriefRefiner" -> {
                                    Text(
                                        text = "BRIEF OPTIMIZER / تهيئة متطلبات الفكرة",
                                        color = NeonAmber,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    OutlinedTextField(
                                        value = rawBriefNotes,
                                        onValueChange = { rawBriefNotes = it },
                                        label = { Text("Raw Client Specifications / متطلبات العميل الخام", color = TextSilver, fontSize = 11.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonAmber,
                                            unfocusedBorderColor = BorderGlass,
                                            focusedTextColor = BrushedTitanium,
                                            unfocusedTextColor = BrushedTitanium
                                        ),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                        minLines = 4,
                                        maxLines = 6
                                    )
                                    Button(
                                        onClick = {
                                            viewModel.triggerAiBriefOutline(rawBriefNotes)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonAmber),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Refine brief / تحسين وتدقيق المخطط", color = DeepSlateBg, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }

                                "Chat" -> {
                                    Text(
                                        text = "AI DESIGN & PRODUCTION ADVISOR / استشارة إنتاجية وهندسية",
                                        color = NeonMint,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    OutlinedTextField(
                                        value = customChatPrompt,
                                        onValueChange = { customChatPrompt = it },
                                        label = { Text("Ask anything about signage or design / سؤال هندسي", color = TextSilver, fontSize = 11.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonMint,
                                            unfocusedBorderColor = BorderGlass,
                                            focusedTextColor = BrushedTitanium,
                                            unfocusedTextColor = BrushedTitanium
                                        ),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                        minLines = 3,
                                        maxLines = 5
                                    )
                                    Button(
                                        onClick = {
                                            viewModel.triggerAiStudioAction(customChatPrompt)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonMint),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Consult Gemini / استشارة الذكاء الاصطناعي", color = DeepSlateBg, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Results Output Box
                            Text(
                                text = "OUTPUT RESOLUTION / النتيجة الذكية:",
                                color = TextSilver,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DeepInkShadow.copy(alpha = 0.4f))
                                    .border(1.dp, BorderGlass, RoundedCornerShape(12.dp))
                                    .padding(12.dp)
                            ) {
                                if (aiIsLoading) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        CircularProgressIndicator(color = NeonPurple, modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("Consulting Gemini AI...", color = TextSilver, fontSize = 10.sp)
                                    }
                                } else {
                                    val currentResult = when (activeCopilotTab) {
                                        "Slogans" -> aiCopywritingResult
                                        "Advisor" -> aiMaterialResult
                                        "BriefRefiner" -> aiBriefResult
                                        "Chat" -> aiStudioResult
                                        else -> ""
                                    }

                                    if (currentResult.isEmpty()) {
                                        Text(
                                            text = "Awaiting parameters above. Configure inputs and click the button to trigger instant generative AI results.",
                                            color = TextSilver.copy(alpha = 0.6f),
                                            fontSize = 11.sp,
                                            lineHeight = 16.sp,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    } else {
                                        Column {
                                            SelectionContainer {
                                                Text(
                                                    text = currentResult,
                                                    color = BrushedTitanium,
                                                    fontSize = 11.sp,
                                                    lineHeight = 18.sp
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Button(
                                                onClick = {
                                                    clipboardManager.setText(AnnotatedString(currentResult))
                                                    Toast.makeText(context, "Copied results to clipboard!", Toast.LENGTH_SHORT).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = BorderGlass),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                                modifier = Modifier.align(Alignment.End).height(32.dp),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.ContentCopy,
                                                    contentDescription = null,
                                                    tint = NeonPurple,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Copy / نسخ نصوص", color = BrushedTitanium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Disclaimer notice
                    Text(
                        text = "🔒 Sandbox execution bound dynamically over Generative REST channels.",
                        color = TextSilver.copy(alpha = 0.4f),
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                }
            }
        }
    }
}
