package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel
import java.util.UUID

// DATA STRUCTS FOR ADVANCED MULTI-LAYER VECTORS
enum class LayerType {
    TEXT, SHAPE, SVG_LOGO, MOCKUP_FRAME
}

enum class ShapeType {
    RECTANGLE, CIRCLE, STAR, TRIANGLE, LINE
}

data class VectorNode(
    var id: String = UUID.randomUUID().toString(),
    var xPercent: Float,
    var yPercent: Float
)

data class DesignLayer(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: LayerType,
    val text: String = "",
    val fontName: String = "Inter",
    val fontCategory: String = "Sans-Serif",
    val fontSize: Float = 28f,
    val primaryColorHex: String = "#00FFFF",
    val strokeColorHex: String = "#000000",
    val strokeWidth: Float = 0f,
    val xPercent: Float = 50f, // center coordinates
    val yPercent: Float = 50f,
    val widthPercent: Float = 30f,
    val heightPercent: Float = 20f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val isLocked: Boolean = false,
    val isHidden: Boolean = false,
    val letterSpacing: Float = 0f,
    val lineSpacing: Float = 0f,
    val hasGlow: Boolean = true,
    val glowColorHex: String = "#00FFFF",
    val glowRadius: Float = 15f,
    val isCurved: Boolean = false,
    val curveAngle: Float = 0f,
    val shapeType: ShapeType = ShapeType.RECTANGLE,
    val presetAsset: String = "",
    val customNodes: List<VectorNode> = emptyList()
)

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DesignStudioScreenLayout(
    viewModel: YaftaViewModel,
    onCreatedLead: () -> Unit,
    onReturnToDashboard: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {}
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    val settings by viewModel.settingsState.collectAsState()

    // WORKSPACE METRIC STATES
    var selectedUnit by remember(settings.measurementUnit) { mutableStateOf(settings.measurementUnit) } // mm, cm, m, inch
    var canvasWidth by remember(settings.canvasWidth) { mutableStateOf(settings.canvasWidth.toString()) }
    var canvasHeight by remember(settings.canvasHeight) { mutableStateOf(settings.canvasHeight.toString()) }
    
    // PRODUCTION CONTROLS
    var colorMode by remember(settings.colorMode) { mutableStateOf(settings.colorMode) } // RGB, CMYK
    var dpiSetting by remember(settings.dpi) { mutableStateOf(settings.dpi) } // 72, 150, 300, 600
    var showBleedField by remember(settings.bleedAreaEnabled) { mutableStateOf(settings.bleedAreaEnabled) }
    var showSafeField by remember(settings.safeAreaEnabled) { mutableStateOf(settings.safeAreaEnabled) }
    var showMockupBg by remember { mutableStateOf(false) }
    var backdropTheme by remember { mutableStateOf("Studio Slate Wall") } // "Studio Slate Wall", "Café Brick Storefront", "Urban Concrete Face", "Vans Delivery Side"

    // INTERACTION PRESETS
    var zoomFactor by remember { mutableStateOf(1.0f) }
    var showGrid by remember(settings.gridEnabled) { mutableStateOf(settings.gridEnabled) }
    var showGuides by remember(settings.guidesEnabled) { mutableStateOf(settings.guidesEnabled) }
    
    // MOBILE MOBILE-FIRST UI STATE FLAGS
    var showToolsPanel by remember { mutableStateOf(false) } // Elements menu bottom sheet
    var showLayersPanel by remember { mutableStateOf(false) } // Layers collapsible queue
    var showPropertiesPanel by remember { mutableStateOf(false) } // Properties bottom sheet

    // DIRECT SIDE LAYOUT CATEGORIES
    var leftPanelCategory by remember { mutableStateOf("Templates") } // "Templates", "Images", "Logos", "Text", "Shapes", "Icons", "AI Tools"

    // ACTIVE LAYER ENGINE
    val layersList = remember { mutableStateListOf<DesignLayer>() }
    var selectedLayerId by remember { mutableStateOf<String?>(null) }
    val activeLayer = layersList.firstOrNull { it.id == selectedLayerId }

    // HISTORICAL UNDO / REDO STATE MACHINE
    val undoStack = remember { mutableStateListOf<List<DesignLayer>>() }
    val redoStack = remember { mutableStateListOf<List<DesignLayer>>() }

    fun captureStateForUndo() {
        undoStack.add(layersList.toList())
        redoStack.clear()
    }

    fun performUndo() {
        if (undoStack.isNotEmpty()) {
            val lastState = undoStack.removeLast()
            redoStack.add(layersList.toList())
            layersList.clear()
            layersList.addAll(lastState)
        }
    }

    fun performRedo() {
        if (redoStack.isNotEmpty()) {
            val nextState = redoStack.removeLast()
            undoStack.add(layersList.toList())
            layersList.clear()
            layersList.addAll(nextState)
        }
    }

    // AUTO-LOAD DEMO SIGNAGE ON INITIAL START
    LaunchedEffect(Unit) {
        if (layersList.isEmpty()) {
            layersList.add(
                DesignLayer(
                    id = "demo_header_text",
                    name = "Active Neon Branding Title",
                    type = LayerType.TEXT,
                    text = "NEON DESIGN WORKSPACE",
                    fontName = "Space Grotesk",
                    fontSize = 32f,
                    primaryColorHex = "#00FFFF",
                    xPercent = 50f,
                    yPercent = 45f,
                    widthPercent = 85f,
                    heightPercent = 15f,
                    letterSpacing = 1.2f,
                    glowColorHex = "#00FFFF",
                    glowRadius = 15f
                )
            )
            layersList.add(
                DesignLayer(
                    id = "demo_neon_border",
                    name = "Outer Glass Frame",
                    type = LayerType.SHAPE,
                    shapeType = ShapeType.RECTANGLE,
                    primaryColorHex = "#FF007F",
                    xPercent = 50f,
                    yPercent = 45f,
                    widthPercent = 90f,
                    heightPercent = 38f,
                    strokeColorHex = "#FF007F",
                    strokeWidth = 3.5f,
                    hasGlow = true,
                    glowColorHex = "#FF007F",
                    glowRadius = 10f
                )
            )
            selectedLayerId = "demo_header_text"
        }
    }

    // FONT LIBRARY
    val fontCategories = listOf("All", "Arabic Calligraphy", "Modern English", "Neon Cyber", "Serif Elegant", "Display Bold")
    var selectedFontCategory by remember { mutableStateOf("All") }
    var fontQuerySearch by remember { mutableStateOf("") }
    val favoriteFontsList = remember { mutableStateListOf("Space Grotesk", "Cairo", "Bebas Neue") }

    val fullFontLibrary = listOf(
        Triple("Cairo", "Arabic Calligraphy", "Professional Arabic Branding Font"),
        Triple("Amiri", "Arabic Calligraphy", "Classic Quranic Naskh Typography"),
        Triple("Tajawal", "Arabic Calligraphy", "Modern Geometry Arabic Tech"),
        Triple("Reem Kufi", "Arabic Calligraphy", "Geometric Traditional Kufic Style"),
        Triple("Space Grotesk", "Neon Cyber", "Futuristic Tech Monospace"),
        Triple("Bebas Neue", "Display Bold", "Ultra-impact Clean Signage Brand"),
        Triple("Cinzel", "Serif Elegant", "Luxury Trajan Roman Capital Lines"),
        Triple("Montserrat", "Modern English", "Geometric Clean Standard Architectural"),
        Triple("Inter", "Modern English", "Highly Legible Interface Scale"),
        Triple("Great Vibes", "Display Bold", "Sleek Fluid Script Signature")
    )

    val displayedFonts = fullFontLibrary.filter {
        (selectedFontCategory == "All" || it.second == selectedFontCategory) &&
        (fontQuerySearch.isEmpty() || it.first.contains(fontQuerySearch, ignoreCase = true))
    }

    // LOGO PRESETS
    val presetLogosList = listOf(
        Triple("Retro Cafe Cup", "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z", "#FFFF00"),
        Triple("Radiant Crown", "M12 2l4 6 5-3-2 11H5L3 5l5 3z", "#D4AF37"),
        Triple("Cyber Flash Bolt", "M12 2L4 12h7v8l8-10h-7z", "#33FF66"),
        Triple("Sleek Crescent", "M12 3a9 9 0 1 0 9 9 9.01 9.01 0 0 0-9-9z", "#00FFFF")
    )

    // CANVAS AREA METRIC CONVERSIONS
    val widthFloat = canvasWidth.toDoubleOrNull() ?: 150.0
    val heightFloat = canvasHeight.toDoubleOrNull() ?: 100.0
    val widthMeters = when (selectedUnit) {
        "mm" -> widthFloat / 1000.0
        "inch" -> widthFloat * 0.0254
        "m" -> widthFloat
        else -> widthFloat / 100.0
    }
    val heightMeters = when (selectedUnit) {
        "mm" -> heightFloat / 1000.0
        "inch" -> heightFloat * 0.0254
        "m" -> heightFloat
        else -> heightFloat / 100.0
    }
    val totalAreaSquareMeters = widthMeters * heightMeters
    val totalPerimeterMeters = (widthMeters + heightMeters) * 2.0

    // ERP INDUSTRIAL ESTIMATOR STATES & COLLAPSIBLE DRAWER
    var showCollapsibleErpDetails by remember { mutableStateOf(false) }

    val activeTextLayers = layersList.filter { it.type == LayerType.TEXT }
    val totalLettersCharacterCount = activeTextLayers.sumOf { it.text.trim().replace(" ", "").length }
    
    val estimatedLedModules = (totalAreaSquareMeters * 115 + totalLettersCharacterCount * 12).toInt().coerceAtLeast(10)
    val estimatedTransformers = if (estimatedLedModules > 80) (estimatedLedModules / 80) + 1 else 1
    val aluminumProfileMeters = totalPerimeterMeters * 1.12
    val acrylicSheetsM2 = totalAreaSquareMeters * 1.05
    val vinylPrintedM2 = totalAreaSquareMeters * 0.8
    val inkVolumeMillilitres = totalAreaSquareMeters * 12.0

    // COST CONFIGS
    val unitLedCost = 1.80
    val unitTransformerCost = 35.00
    val unitProfileCost = 25.00
    val unitAcrylicCost = 50.00
    val unitVinylCost = 20.00
    val unitInkCost = 0.30

    val rawMaterialCost = (estimatedLedModules * unitLedCost) +
                           (estimatedTransformers * unitTransformerCost) +
                           (aluminumProfileMeters * unitProfileCost) +
                           (acrylicSheetsM2 * unitAcrylicCost) +
                           (vinylPrintedM2 * unitVinylCost) +
                           (inkVolumeMillilitres * unitInkCost)
    
    val fabricationLabourCost = (totalLettersCharacterCount * 12.0) + (totalAreaSquareMeters * 75.0) + 50.0
    val siteInstallationCost = totalAreaSquareMeters * 130.0 + 150.0
    val overallProductionCost = rawMaterialCost + fabricationLabourCost + siteInstallationCost
    
    var marginSliderValue by remember { mutableStateOf(2.0f) }
    val suggestedRetailPrice = overallProductionCost * marginSliderValue
    val standardKsaVatAmount = suggestedRetailPrice * 0.15
    val clientPriceWithVat = suggestedRetailPrice + standardKsaVatAmount
    val absoluteClientProfit = suggestedRetailPrice - overallProductionCost

    // CANVA STYLE EDITABLE SIGNAGE TEMPLATES
    val signageTemplates = listOf(
        Triple("Premium Café Glow", "Double sided circular neon box optimized for storefront entrance. Dynamic light Cyan backglow.", 150.0),
        Triple("Ramadan Holy Banner", "Modern gold vinyl printing banner with beautiful ambient crescent moon and green LEDs.", 240.0),
        Triple("3D Acrylic LED Letters", "Luxury high-density storefront letters with individual RGB controller chips.", 180.0),
        Triple("Truck Wrap / Mat Sign", "Full body wrap sign optimized for transport delivery vehicles. Waterproof UV output.", 350.0),
        Triple("Engraved Desk Acrylic", "Sleek tabletop sign using polished wooden blocks & glowing translucent text paths.", 60.0)
    )

    // GEMINI DESIGN ENGINE STATES
    val aiStudioResult by viewModel.aiStudioResult.collectAsState()
    val aiIsLoading by viewModel.aiIsLoading.collectAsState()
    var showAiAdvicePanel by remember { mutableStateOf(false) }
    var aiFeatureClickedTitle by remember { mutableStateOf("Ready to Guide") }

    // INTEGRATION DIALOGS
    var showSaveLeadDialog by remember { mutableStateOf(false) }
    var leadClientBusinessName by remember { mutableStateOf("") }
    var leadContactPhoneNum by remember { mutableStateOf("") }
    var showCpuSvgExportViewer by remember { mutableStateOf(false) }
    var showCanvasSettingsMenu by remember { mutableStateOf(false) }
    var showPrintSetupMenu by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // ==================== TOP BAR ====================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSlateCard.copy(alpha = 0.95f))
                    .border(1.dp, BorderGlass, RoundedCornerShape(0.dp))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // 5. Hide bottom navigation and show only a small floating return button.
                    IconButton(
                        onClick = { onReturnToDashboard() },
                        modifier = Modifier
                            .size(36.dp)
                            .background(NeonPurple.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Return to Dashboard",
                            tint = NeonPurple,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(2.dp))
                    Column {
                        Text(
                            text = "SIGNAGE CAD STUDIO",
                            color = BrushedTitanium,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Mobile Workbench v3.5",
                            color = TextSilver,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Compact top-bar utility controls (Undo, Redo, Size, Setup)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { performUndo() },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (undoStack.isNotEmpty()) NeonPurple else TextSilver.copy(alpha = 0.3f),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { performRedo() },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (redoStack.isNotEmpty()) NeonPurple else TextSilver.copy(alpha = 0.3f),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Workspace parameters layout setup trigger
                    IconButton(
                        onClick = { onNavigateToSettings() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SettingsInputComponent,
                            contentDescription = "Canvas Setup in System Center",
                            tint = TextSilver,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Print setup setup
                    IconButton(
                        onClick = { onNavigateToSettings() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Print,
                            contentDescription = "Print Options in System Center",
                            tint = TextSilver,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Compact ERP summary badge (Tap to toggle full sheet breakdown)
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (showCollapsibleErpDetails) NeonMint.copy(alpha = 0.2f) else DarkSlateCard
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showCollapsibleErpDetails = !showCollapsibleErpDetails }
                            .border(1.dp, if (showCollapsibleErpDetails) NeonMint else BorderGlass, RoundedCornerShape(8.dp))
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Calculate, contentDescription = null, tint = NeonMint, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "SAR ${String.format("%.0f", clientPriceWithVat)}",
                                color = NeonMint,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // ==================== CANVAS WORKSPACE & DIRECT TOOL SECTIONS ====================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(DeepSlateBg)
            ) {
                /*
                // Inactive desktop panel block
                if (false) {
                    Row(
                        modifier = Modifier
                            .width(320.dp)
                            .fillMaxHeight()
                            .background(DarkSlateCard)
                            .border(1.dp, BorderGlass, RoundedCornerShape(0.dp))
                    ) {
                        // Narrow Category Icon Strip
                        Column(
                            modifier = Modifier
                                .width(64.dp)
                                .fillMaxHeight()
                                .background(DeepSlateBg)
                                .border(1.dp, BorderGlass)
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            val leftCategoriesList = listOf(
                                "Templates" to Icons.Filled.AutoAwesomeMotion,
                                "Images" to Icons.Filled.Image,
                                "Logos" to Icons.Filled.Star,
                                "Text" to Icons.Filled.TextFields,
                                "Shapes" to Icons.Filled.Category,
                                "Icons" to Icons.Filled.BubbleChart,
                                "AI Tools" to Icons.Filled.AutoAwesome
                            )

                            leftCategoriesList.forEach { (catName, icon) ->
                                val isSelected = leftPanelCategory == catName
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) NeonPurple else Color.Transparent)
                                        .clickable { leftPanelCategory = catName }
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = catName,
                                            tint = if (isSelected) DeepSlateBg else TextSilver,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = catName,
                                            color = if (isSelected) DeepSlateBg else TextSilver,
                                            fontSize = 7.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        // Broad Content Details Selector
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(12.dp)
                        ) {
                            Text(
                                text = leftPanelCategory.uppercase(),
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            when (leftPanelCategory) {
                                "Templates" -> {
                                    Text(
                                        text = "Apply production templates with auto-set parameters:",
                                        color = TextSilver,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    signageTemplates.forEach { (title, desc, cost) ->
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = DeepSlateBg),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                                .clickable {
                                                    captureStateForUndo()
                                                    layersList.clear()

                                                    // Auto-generate layers based on clicked template
                                                    when {
                                                        title.contains("Café") -> {
                                                            canvasWidth = "120"
                                                            canvasHeight = "120"
                                                            layersList.add(
                                                                DesignLayer(
                                                                    id = "cafe_text",
                                                                    name = "Main Cafe Bold Text",
                                                                    type = LayerType.TEXT,
                                                                    text = "THE STREET BREW",
                                                                    fontName = "Bebas Neue",
                                                                    fontSize = 30f,
                                                                    primaryColorHex = "#FFFF00",
                                                                    xPercent = 50f,
                                                                    yPercent = 48f,
                                                                    widthPercent = 80f,
                                                                    heightPercent = 14f,
                                                                    glowColorHex = "#FFFF00"
                                                                )
                                                            )
                                                            layersList.add(
                                                                DesignLayer(
                                                                    id = "cafe_circle",
                                                                    name = "Backing Circle Base",
                                                                    type = LayerType.SHAPE,
                                                                    shapeType = ShapeType.CIRCLE,
                                                                    primaryColorHex = "#00FFFF",
                                                                    xPercent = 50f,
                                                                    yPercent = 48f,
                                                                    widthPercent = 85f,
                                                                    heightPercent = 85f,
                                                                    strokeColorHex = "#00FFFF",
                                                                    strokeWidth = 3f
                                                                )
                                                            )
                                                        }
                                                        title.contains("Ramadan") -> {
                                                            canvasWidth = "300"
                                                            canvasHeight = "100"
                                                            layersList.add(
                                                                DesignLayer(
                                                                    id = "ramadan_text",
                                                                    name = "Ramadan Calligraphy Title",
                                                                    type = LayerType.TEXT,
                                                                    text = "RAMADAN KAREEM رمضان",
                                                                    fontName = "Cairo",
                                                                    fontSize = 28f,
                                                                    primaryColorHex = "#D4AF37",
                                                                    xPercent = 50f,
                                                                    yPercent = 45f,
                                                                    widthPercent = 85f,
                                                                    heightPercent = 16f,
                                                                    glowColorHex = "#D4AF37"
                                                                )
                                                            )
                                                            layersList.add(
                                                                DesignLayer(
                                                                    id = "crescent_shape",
                                                                    name = "Glow Crescent Decoration",
                                                                    type = LayerType.SHAPE,
                                                                    shapeType = ShapeType.CIRCLE,
                                                                    primaryColorHex = "#00FF66",
                                                                    xPercent = 50f,
                                                                    yPercent = 45f,
                                                                    widthPercent = 92f,
                                                                    heightPercent = 40f,
                                                                    strokeColorHex = "#00FF66",
                                                                    strokeWidth = 2.5f
                                                                )
                                                            )
                                                        }
                                                        else -> {
                                                            layersList.add(
                                                                DesignLayer(
                                                                    id = "custom_t_lay",
                                                                    name = "Template Head",
                                                                    type = LayerType.TEXT,
                                                                    text = title.uppercase(),
                                                                    fontName = "Space Grotesk",
                                                                    fontSize = 32f,
                                                                    primaryColorHex = "#FF007F",
                                                                    xPercent = 50f,
                                                                    yPercent = 45f,
                                                                    widthPercent = 85f,
                                                                    heightPercent = 15f
                                                                )
                                                            )
                                                        }
                                                    }
                                                    Toast.makeText(context, "$title template loaded", Toast.LENGTH_SHORT).show()
                                                }
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp)) {
                                                Text(title, color = BrushedTitanium, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                Text(desc, color = TextSilver, fontSize = 8.sp, lineHeight = 11.sp)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text("Est. Value: SAR $cost", color = NeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                "Images" -> {
                                    Text("Mockup Backsplashes & Environments:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf("Brick Storefront", "Concrete Face", "Van Side").forEach { option ->
                                            val isCurrent = backdropTheme.contains(option.take(4))
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (isCurrent) NeonCyan else DeepSlateBg)
                                                    .clickable {
                                                        showMockupBg = true
                                                        backdropTheme = when (option) {
                                                            "Brick Storefront" -> "Café Brick Storefront"
                                                            "Concrete Face" -> "Urban Concrete Face"
                                                            else -> "Vans Delivery Side"
                                                        }
                                                    }
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = option.take(8),
                                                    color = if (isCurrent) DeepSlateBg else TextSilver,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("Simulated Camera Feed Mockups:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    
                                    Button(
                                        onClick = { 
                                            showMockupBg = !showMockupBg
                                            Toast.makeText(context, "Backdrop rendering toggled", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(if (showMockupBg) "Disable Mockup Backdrop" else "Enable Mockup Backdrop", fontSize = 9.sp)
                                    }
                                }

                                "Logos" -> {
                                    Text("One-click vector brand shapes:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    presetLogosList.forEach { (name, path, col) ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                                .background(DeepSlateBg, RoundedCornerShape(8.dp))
                                                .border(1.dp, BorderGlass, RoundedCornerShape(8.dp))
                                                .clickable {
                                                    captureStateForUndo()
                                                    layersList.add(
                                                        DesignLayer(
                                                            name = "$name Vector",
                                                            type = LayerType.SVG_LOGO,
                                                            primaryColorHex = col,
                                                            xPercent = (40..60).random().toFloat(),
                                                            yPercent = (40..60).random().toFloat(),
                                                            widthPercent = 25f,
                                                            heightPercent = 25f,
                                                            presetAsset = path
                                                        )
                                                    )
                                                }
                                                .padding(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Filled.AutoAwesomeMotion, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(name, color = BrushedTitanium, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }

                                "Text" -> {
                                    Text("Typography Layout Additions:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    val typographyOptions = listOf(
                                        "Aesthetic Cyber Glow" to "#00FFFF",
                                        "Classic Arabic Sign" to "#FFCC00",
                                        "Bold Storefront Head" to "#FF007F",
                                        "Mini Sub-Heading" to "#FFFFFF"
                                    )

                                    typographyOptions.forEach { (option, col) ->
                                        Button(
                                            onClick = {
                                                captureStateForUndo()
                                                layersList.add(
                                                    DesignLayer(
                                                        name = "$option Layer",
                                                        type = LayerType.TEXT,
                                                        text = if (option.contains("Arabic")) "بوابة الشرق يافطة" else "CUSTOM COREL WORK",
                                                        fontName = if (option.contains("Arabic")) "Cairo" else "Space Grotesk",
                                                        primaryColorHex = col,
                                                        fontSize = 24f,
                                                        xPercent = (45..55).random().toFloat(),
                                                        yPercent = (45..55).random().toFloat(),
                                                        widthPercent = 75f,
                                                        heightPercent = 12f,
                                                        hasGlow = true,
                                                        glowColorHex = col
                                                    )
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 3.dp)
                                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                        ) {
                                            Text(option, color = BrushedTitanium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                "Shapes" -> {
                                    Text("Standard core shape libraries:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    listOf(
                                        "RECONSTRUCT RECTANGLE" to ShapeType.RECTANGLE,
                                        "PERFECT HALO CIRCLE" to ShapeType.CIRCLE,
                                        "TRIANGULAR ACCENT" to ShapeType.TRIANGLE,
                                        "HORIZONTAL TRIM LINE" to ShapeType.LINE
                                    ).forEach { (label, shape) ->
                                        Button(
                                            onClick = {
                                                captureStateForUndo()
                                                layersList.add(
                                                    DesignLayer(
                                                        name = label.take(12),
                                                        type = LayerType.SHAPE,
                                                        shapeType = shape,
                                                        primaryColorHex = "#FF00FF",
                                                        xPercent = (40..60).random().toFloat(),
                                                        yPercent = (40..60).random().toFloat(),
                                                        widthPercent = if (shape == ShapeType.LINE) 80f else 30f,
                                                        heightPercent = if (shape == ShapeType.LINE) 4f else 30f,
                                                        strokeColorHex = "#FF00FF"
                                                    )
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 3.dp)
                                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                        ) {
                                            Text(label, color = BrushedTitanium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                "Icons" -> {
                                    Text("Branding vector assets:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    listOf(
                                        "Cafe Mug Block" to "#00FFFF",
                                        "Retail Shopping Cart" to "#FF3366",
                                        "Star Banner Badge" to "#D4AF37",
                                        "Ramadan Moon" to "#00FF66"
                                    ).forEach { (iconLabel, colorH) ->
                                        Button(
                                            onClick = {
                                                captureStateForUndo()
                                                layersList.add(
                                                    DesignLayer(
                                                        name = "$iconLabel SVG",
                                                        type = LayerType.SVG_LOGO,
                                                        primaryColorHex = colorH,
                                                        xPercent = 50f,
                                                        yPercent = 52f,
                                                        widthPercent = 25f,
                                                        heightPercent = 25f
                                                    )
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 3.dp)
                                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                        ) {
                                            Text(iconLabel, color = BrushedTitanium, fontSize = 9.sp)
                                        }
                                    }
                                }

                                "AI Tools" -> {
                                    Text("Canva-Style Production AI Assist:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(8.dp))

                                    // 1. BG Remove
                                    Button(
                                        onClick = {
                                            Toast.makeText(context, "AI Background Removal completed successfully on canvas frame!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                    ) {
                                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("AI Background Removal", fontSize = 9.sp)
                                    }

                                    // 2. Object Cleanup
                                    Button(
                                        onClick = {
                                            Toast.makeText(context, "Vectorized cleanup completed!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                    ) {
                                        Icon(Icons.Filled.Brush, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("AI Object & Logo Cleanup", fontSize = 9.sp)
                                    }

                                    // 3. Image Enhancement & Resize
                                    Button(
                                        onClick = {
                                            Toast.makeText(context, "Bilinear upscale to 600DPI finished!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepSlateBg),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                                    ) {
                                        Icon(Icons.Filled.HighQuality, contentDescription = null, tint = NeonMint, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("AI Upscaling & Enhancer", fontSize = 9.sp)
                                    }

                                    // 4. Align and Smart Resize helper for different advertising dimensions
                                    Button(
                                        onClick = {
                                            captureStateForUndo()
                                            canvasWidth = "240"
                                            canvasHeight = "120" // automatic layout scale adjustment
                                            Toast.makeText(context, "Smart Realized to standard 2.4X1.2m outdoor signage!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple.copy(alpha = 0.2f)),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, NeonPurple, RoundedCornerShape(10.dp))
                                    ) {
                                        Icon(Icons.Filled.AspectRatio, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("AI Smart Signage Resize", fontSize = 9.sp, color = BrushedTitanium, fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Divider(color = BorderGlass)
                                    Spacer(modifier = Modifier.height(10.dp))

                                    // 5. Ask Gemini AI Suggestions
                                    Text("Analyze Layout via Gemini Client:", color = TextSilver, fontSize = 9.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Button(
                                        onClick = {
                                            showAiAdvicePanel = true
                                            aiFeatureClickedTitle = "AI Layout & Palette Advisor"
                                            viewModel.triggerAiStudioAction(
                                                "Suggest cohesive design properties, neon glow attributes, and installation guidelines for an advertising sign measuring $canvasWidth x $canvasHeight cm. Present 4 modern KSA business style combinations."
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = DeepSlateBg, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Query AI Core Assistant", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DeepSlateBg)
                                    }
                                }
                            }
                        }
                    }
                }
                */

                // ==================== CENTER WORKSPACE (Modular Canvas area) ====================
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DeepSlateBg)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    DesignCustomCanvas(
                        layersList = layersList,
                        selectedLayerId = selectedLayerId,
                        onLayerSelect = { selectedLayerId = it },
                        zoomFactor = zoomFactor,
                        showGrid = showGrid,
                        showGuides = showGuides,
                        showBleedField = showBleedField,
                        showSafeField = showSafeField,
                        showMockupBg = showMockupBg,
                        backdropTheme = backdropTheme,
                        colorMode = colorMode,
                        isTablet = isTablet
                    )
                }

                // ==================== MOBILE PORTRAIT TOOLBARS & CANVA UX OVERLAYS ====================
                val currentActiveLayer = activeLayer

                // 1. Floating Action Strip (Adding elements, triggering Gemini layout advisor)
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FloatingActionButton(
                        onClick = { showToolsPanel = !showToolsPanel },
                        containerColor = NeonPurple,
                        contentColor = DeepSlateBg,
                        shape = CircleShape,
                        modifier = Modifier.size(52.dp).border(1.5.dp, BorderGlass, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (showToolsPanel) Icons.Filled.Close else Icons.Filled.Add,
                            contentDescription = "Add Design Elements",
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    FloatingActionButton(
                        onClick = {
                            showAiAdvicePanel = true
                            aiFeatureClickedTitle = "AI Layout Advisor"
                            viewModel.triggerAiStudioAction(
                                "Suggest cohesive design properties, neon glow attributes, and installation guidelines for an advertising sign measuring $canvasWidth x $canvasHeight cm."
                            )
                        },
                        containerColor = DarkSlateCard.copy(alpha = 0.9f),
                        contentColor = NeonPurple,
                        shape = CircleShape,
                        modifier = Modifier.size(44.dp).border(1.dp, BorderGlass, CircleShape)
                    ) {
                        Icon(Icons.Filled.AutoAwesome, null, modifier = Modifier.size(18.dp))
                    }
                }

                // 2. Layers button & toggle card
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 16.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Button(
                        onClick = { showLayersPanel = !showLayersPanel },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (showLayersPanel) NeonCyan else DarkSlateCard.copy(alpha = 0.9f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(40.dp).border(1.dp, if (showLayersPanel) NeonCyan else BorderGlass, RoundedCornerShape(12.dp)),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Layers,
                            contentDescription = null,
                            tint = if (showLayersPanel) DeepSlateBg else NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LAYERS (${layersList.size})",
                            color = if (showLayersPanel) DeepSlateBg else BrushedTitanium,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 3. Compact selected element property prompt
                if (selectedLayerId != null && currentActiveLayer != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NeonPurple.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 76.dp)
                            .border(1.dp, NeonPurple, RoundedCornerShape(10.dp))
                            .clickable { showPropertiesPanel = !showPropertiesPanel }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (currentActiveLayer.type == LayerType.TEXT) Icons.Filled.TextFields else Icons.Filled.Category,
                                contentDescription = null,
                                tint = NeonPurple,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "ACTIVE: ${currentActiveLayer.name.take(15).uppercase()}",
                                color = BrushedTitanium,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(NeonPurple)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (showPropertiesPanel) "CLOSE" else "EDIT",
                                    color = DeepSlateBg,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                // 4. Slide-in Drawer Layers Manager Panel
                androidx.compose.animation.AnimatedVisibility(
                    visible = showLayersPanel,
                    enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                    exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 12.dp)
                ) {
                    DesignLayersPanel(
                        layersList = layersList,
                        selectedLayerId = selectedLayerId,
                        onLayerSelect = { selectedLayerId = it },
                        onPropertiesPanelOpen = { showPropertiesPanel = it },
                        onLayersPanelClose = { showLayersPanel = false },
                        onCaptureState = { captureStateForUndo() },
                        onLayerUpdate = { index, updated -> layersList[index] = updated },
                        onLayerRemove = { layersList.remove(it) },
                        onSelectedLayerIdClear = { selectedLayerId = null }
                    )
                }

                // 5. Sliding Drawer Elements Panel
                androidx.compose.animation.AnimatedVisibility(
                    visible = showToolsPanel,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                ) {
                    DesignAssetsPanel(
                        leftPanelCategory = leftPanelCategory,
                        onLeftPanelCategoryChange = { leftPanelCategory = it },
                        backdropTheme = backdropTheme,
                        onBackdropThemeChange = { backdropTheme = it },
                        showMockupBg = showMockupBg,
                        onShowMockupBgChange = { showMockupBg = it },
                        layersList = layersList,
                        onAddLayer = { layersList.add(it) },
                        onClearLayers = { layersList.clear() },
                        onSelectedLayerIdChange = { selectedLayerId = it },
                        onToolsPanelClose = { showToolsPanel = false },
                        onCaptureState = { captureStateForUndo() },
                        onCanvasWidthChange = { canvasWidth = it },
                        onCanvasHeightChange = { canvasHeight = it },
                        signageTemplates = signageTemplates,
                        presetLogosList = presetLogosList
                    )
                }

                // 6. Sliding Drawer Properties Editor Sheet
                androidx.compose.animation.AnimatedVisibility(
                    visible = showPropertiesPanel && selectedLayerId != null && currentActiveLayer != null,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                ) {
                    val activeLayer = currentActiveLayer!!
                    val activeIndex = layersList.indexOf(activeLayer)
                    if (activeIndex != -1) {
                        DesignPropertiesPanel(
                            activeLayer = activeLayer,
                            activeIndex = activeIndex,
                            layersList = layersList,
                            onLayerUpdate = { index, updated -> layersList[index] = updated },
                            onPropertiesPanelClose = { showPropertiesPanel = false }
                        )
                    }
                }

                // ==================== RIGHT PANEL DEACTIVATED ====================
                /*
                if (false) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                        modifier = Modifier
                            .width(320.dp)
                            .fillMaxHeight()
                            .border(1.dp, BorderGlass, RoundedCornerShape(0.dp)),
                        shape = RoundedCornerShape(0.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            
                            // Properties Title
                            Text("ELEMENT PROPERTIES", color = NeonCyan, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)

                            // Layer Manager listing
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DeepSlateBg),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "Active Layers Stack (${layersList.size}):",
                                        color = BrushedTitanium,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    
                                    layersList.forEach { layer ->
                                        val isLayerSelected = selectedLayerId == layer.id
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 2.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (isLayerSelected) NeonPurple.copy(alpha = 0.15f) else Color.Transparent)
                                                .clickable { selectedLayerId = layer.id }
                                                .padding(horizontal = 6.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = if (layer.type == LayerType.TEXT) Icons.Filled.TextFields else Icons.Filled.Category,
                                                    contentDescription = null,
                                                    tint = if (isLayerSelected) NeonPurple else TextSilver,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = layer.name.take(18),
                                                    color = if (isLayerSelected) BrushedTitanium else TextSilver,
                                                    fontSize = 8.sp,
                                                    fontWeight = if (isLayerSelected) FontWeight.Bold else FontWeight.Normal,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                // Lock Layer
                                                IconButton(
                                                    onClick = {
                                                        val index = layersList.indexOf(layer)
                                                        if (index != -1) {
                                                            captureStateForUndo()
                                                            layersList[index] = layer.copy(isLocked = !layer.isLocked)
                                                        }
                                                    },
                                                    modifier = Modifier.size(20.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (layer.isLocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                                                        contentDescription = null,
                                                        tint = if (layer.isLocked) NeonPurple else TextSilver.copy(alpha = 0.5f),
                                                        modifier = Modifier.size(10.dp)
                                                    )
                                                }

                                                // Hide Layer
                                                IconButton(
                                                    onClick = {
                                                        val index = layersList.indexOf(layer)
                                                        if (index != -1) {
                                                            captureStateForUndo()
                                                            layersList[index] = layer.copy(isHidden = !layer.isHidden)
                                                        }
                                                    },
                                                    modifier = Modifier.size(20.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (layer.isHidden) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                                        contentDescription = null,
                                                        tint = if (layer.isHidden) TextSilver.copy(alpha = 0.3f) else NeonCyan,
                                                        modifier = Modifier.size(10.dp)
                                                    )
                                                }

                                                // Delete Layer
                                                IconButton(
                                                    onClick = {
                                                        captureStateForUndo()
                                                        layersList.remove(layer)
                                                        if (selectedLayerId == layer.id) {
                                                            selectedLayerId = null
                                                        }
                                                    },
                                                    modifier = Modifier.size(20.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Filled.Delete,
                                                        contentDescription = "Delete",
                                                        tint = SignalCritical.copy(alpha = 0.8f),
                                                        modifier = Modifier.size(10.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Properties Editor for the selected layer
                            if (activeLayer != null) {
                                val index = layersList.indexOf(activeLayer)
                                
                                Text(
                                    text = "ADJUST LAYER: ${activeLayer.name.uppercase()}",
                                    color = NeonPurple,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                // Real-time coordinates positioners
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("X Pos (%) : ${activeLayer.xPercent.toInt()}", color = TextSilver, fontSize = 8.sp)
                                        Slider(
                                            value = activeLayer.xPercent,
                                            onValueChange = {
                                                if (!activeLayer.isLocked) {
                                                    layersList[index] = activeLayer.copy(xPercent = it)
                                                }
                                            },
                                            valueRange = 0f..100f,
                                            colors = SliderDefaults.colors(thumbColor = NeonPurple)
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Y Pos (%) : ${activeLayer.yPercent.toInt()}", color = TextSilver, fontSize = 8.sp)
                                        Slider(
                                            value = activeLayer.yPercent,
                                            onValueChange = {
                                                if (!activeLayer.isLocked) {
                                                    layersList[index] = activeLayer.copy(yPercent = it)
                                                }
                                            },
                                            valueRange = 0f..100f,
                                            colors = SliderDefaults.colors(thumbColor = NeonPurple)
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Width (%) : ${activeLayer.widthPercent.toInt()}", color = TextSilver, fontSize = 8.sp)
                                        Slider(
                                            value = activeLayer.widthPercent,
                                            onValueChange = {
                                                if (!activeLayer.isLocked) {
                                                    layersList[index] = activeLayer.copy(widthPercent = it)
                                                }
                                            },
                                            valueRange = 5f..100f,
                                            colors = SliderDefaults.colors(thumbColor = NeonCyan)
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Rotation (°) : ${activeLayer.rotation.toInt()}", color = TextSilver, fontSize = 8.sp)
                                        Slider(
                                            value = activeLayer.rotation,
                                            onValueChange = {
                                                if (!activeLayer.isLocked) {
                                                    layersList[index] = activeLayer.copy(rotation = it)
                                                }
                                            },
                                            valueRange = 0f..360f,
                                            colors = SliderDefaults.colors(thumbColor = NeonCyan)
                                        )
                                    }
                                }

                                // Color & Branding Picker Palette hex
                                Text("COLORS & NEON HIGHLIGHTS", color = BrushedTitanium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    listOf("#00FFFF", "#FF007F", "#FFFF00", "#00FF66", "#BF80FF", "#FFFFFF").forEach { hexColor ->
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(Color(android.graphics.Color.parseColor(hexColor)))
                                                .border(
                                                    width = if (activeLayer.primaryColorHex == hexColor) 1.5.dp else 0.dp,
                                                    color = BrushedTitanium,
                                                    shape = CircleShape
                                                )
                                                .clickable {
                                                    if (!activeLayer.isLocked) {
                                                        layersList[index] = activeLayer.copy(
                                                            primaryColorHex = hexColor,
                                                            glowColorHex = hexColor
                                                        )
                                                    }
                                                }
                                        )
                                    }
                                }
                                
                                OutlinedTextField(
                                    value = activeLayer.primaryColorHex,
                                    onValueChange = {
                                        if (it.startsWith("#") && it.length <= 7) {
                                            layersList[index] = activeLayer.copy(primaryColorHex = it)
                                        }
                                    },
                                    label = { Text("Selected Color Hex Value", fontSize = 8.sp) },
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, focusedTextColor = BrushedTitanium),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                // Typography Settings (renders only if TEXT is selected)
                                if (activeLayer.type == LayerType.TEXT) {
                                    Text("TYPOGRAPHY & LETTERING", color = BrushedTitanium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    
                                    OutlinedTextField(
                                        value = activeLayer.text,
                                        onValueChange = {
                                            layersList[index] = activeLayer.copy(text = it)
                                        },
                                        label = { Text("Display Content", fontSize = 8.sp) },
                                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, focusedTextColor = BrushedTitanium),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    // Font selection
                                    Text("Applied Font Typeface Filter:", color = TextSilver, fontSize = 8.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        listOf("Cairo", "Space Grotesk", "Bebas Neue", "Inter").forEach { font ->
                                            val isF = activeLayer.fontName == font
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (isF) NeonPurple else DeepSlateBg)
                                                    .clickable {
                                                        layersList[index] = activeLayer.copy(fontName = font)
                                                    }
                                                    .padding(vertical = 6.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(font.take(6), color = if (isF) DeepSlateBg else TextSilver, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Letter Spacing (SP) : ${activeLayer.letterSpacing.toInt()}", color = TextSilver, fontSize = 8.sp)
                                    Slider(
                                        value = activeLayer.letterSpacing,
                                        onValueChange = {
                                            layersList[index] = activeLayer.copy(letterSpacing = it)
                                        },
                                        valueRange = 0f..8f,
                                        colors = SliderDefaults.colors(thumbColor = NeonMint)
                                    )

                                    // Curved Text on path toggle
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Curved Path Effect:", color = TextSilver, fontSize = 9.sp)
                                        Switch(
                                            checked = activeLayer.isCurved,
                                            onCheckedChange = {
                                                layersList[index] = activeLayer.copy(isCurved = it)
                                            },
                                            colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                                        )
                                    }
                                }

                                // Effects (Neon Halo glows and thick stroke outline parameters)
                                Text("EFFECTS & NEON TUBING OUTLINES", color = BrushedTitanium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Fluorescent Halo Glow:", color = TextSilver, fontSize = 9.sp)
                                    Switch(
                                        checked = activeLayer.hasGlow,
                                        onCheckedChange = {
                                            layersList[index] = activeLayer.copy(hasGlow = it)
                                        },
                                        colors = SwitchDefaults.colors(checkedThumbColor = NeonPurple)
                                    )
                                }

                                if (activeLayer.hasGlow) {
                                    Text("Neon Glow Intensity (Radius): ${activeLayer.glowRadius.toInt()}", color = TextSilver, fontSize = 8.sp)
                                    Slider(
                                        value = activeLayer.glowRadius,
                                        onValueChange = {
                                            layersList[index] = activeLayer.copy(glowRadius = it)
                                        },
                                        valueRange = 5f..35f,
                                        colors = SliderDefaults.colors(thumbColor = NeonPurple)
                                    )
                                }

                                Text("CNC Cutter Stroke Width: ${activeLayer.strokeWidth.toInt()}", color = TextSilver, fontSize = 8.sp)
                                Slider(
                                    value = activeLayer.strokeWidth,
                                    onValueChange = {
                                        layersList[index] = activeLayer.copy(strokeWidth = it)
                                    },
                                    valueRange = 0f..8f,
                                    colors = SliderDefaults.colors(thumbColor = NeonCyan)
                                )

                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(DeepSlateBg, RoundedCornerShape(10.dp))
                                        .padding(14.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "SELECT ANY CANVAS LAYER TO CONFIGURE DETAILED SIZING, STROKES, GLOWS AND ARABIC FONTS.",
                                        color = TextSilver,
                                        fontSize = 8.sp,
                                        textAlign = TextAlign.Center,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
                */
            }
        }

        // ==================== COLLAPSIBLE ERP COSTING & CALCULATIONS PANEL (Overlay Slide Sheets) ====================
        AnimatedVisibility(
            visible = showCollapsibleErpDetails,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                modifier = Modifier
                    .border(2.dp, NeonMint, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Filled.Calculate, contentDescription = null, tint = NeonMint)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "INDUSTRIAL MATERIAL BREAKDOWN & INTEGRAL BILLING (KSA VAT)",
                                color = NeonMint,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 0.5.sp
                            )
                        }

                        IconButton(
                            onClick = { showCollapsibleErpDetails = false },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(imageVector = Icons.Filled.Close, contentDescription = "Close", tint = TextSilver)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Estimated quantities
                        Column(modifier = Modifier.weight(1.2f)) {
                            Text("ESTIMATED QUANTITIES CONSUMED:", color = TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            listOf(
                                "Fluorescent LED Modules" to "$estimatedLedModules modules (~SAR ${String.format("%,.1f", estimatedLedModules * unitLedCost)})",
                                "Power Transformers 12V" to "$estimatedTransformers units (~SAR ${String.format("%,.1f", estimatedTransformers * unitTransformerCost)})",
                                "Anodized Backing Metal Frames" to "${String.format("%.2f", aluminumProfileMeters)} meters (~SAR ${String.format("%,.1f", aluminumProfileMeters * unitProfileCost)})",
                                "Clear Acrylic Backing Base" to "${String.format("%.2f", acrylicSheetsM2)} m² (~SAR ${String.format("%,.1f", acrylicSheetsM2 * unitAcrylicCost)})",
                                "Vinyl Matte UV Printing" to "${String.format("%.2f", vinylPrintedM2)} m² (~SAR ${String.format("%,.1f", vinylPrintedM2 * unitVinylCost)})",
                                "Industrial Pigmented Inks" to "${String.format("%.2f", inkVolumeMillilitres)} mL (~SAR ${String.format("%,.1f", inkVolumeMillilitres * unitInkCost)})"
                            ).forEach { (item, value) ->
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
                                ) {
                                    Text("• $item:", color = TextSilver, fontSize = 8.sp)
                                    Text(value, color = BrushedTitanium, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Financial breakdown card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DeepSlateBg),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Raw Materials:", color = TextSilver, fontSize = 8.sp)
                                    Text("SAR ${String.format("%,.1f", rawMaterialCost)}", color = BrushedTitanium, fontSize = 8.sp)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Fabrication Labor:", color = TextSilver, fontSize = 8.sp)
                                    Text("SAR ${String.format("%,.1f", fabricationLabourCost)}", color = BrushedTitanium, fontSize = 8.sp)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Professional Installation:", color = TextSilver, fontSize = 8.sp)
                                    Text("SAR ${String.format("%,.1f", siteInstallationCost)}", color = BrushedTitanium, fontSize = 8.sp)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Aggregate Cost price:", color = TextSilver, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                                    Text("SAR ${String.format("%,.1f", overallProductionCost)}", color = TextSilver, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                                }

                                Divider(color = BorderGlass, modifier = Modifier.padding(vertical = 4.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Profit Multiplier: ${String.format("%.1f", marginSliderValue)}x", color = NeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    Slider(
                                        value = marginSliderValue,
                                        onValueChange = { marginSliderValue = it },
                                        valueRange = 1.2f..3.0f,
                                        modifier = Modifier.width(90.dp),
                                        colors = SliderDefaults.colors(thumbColor = NeonCyan)
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Offer price (Excl. VAT):", color = TextSilver, fontSize = 8.sp)
                                    Text("SAR ${String.format("%,.1f", suggestedRetailPrice)}", color = BrushedTitanium, fontSize = 8.sp)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Standard VAT 15%:", color = TextSilver, fontSize = 8.sp)
                                    Text("SAR ${String.format("%,.1f", standardKsaVatAmount)}", color = TextSilver, fontSize = 8.sp)
                                }

                                Divider(color = BorderGlass, modifier = Modifier.padding(vertical = 4.dp))

                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column {
                                        Text("TOTAL CUSTOMER BILL", color = NeonMint, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                                        Text("SAR ${String.format("%,.1f", clientPriceWithVat)}", color = NeonMint, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("NET MARGIN", color = NeonPurple, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                                        Text("${String.format("%.0f", (absoluteClientProfit / suggestedRetailPrice) * 100)}%", color = NeonPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    
                    // Directly pushing from details
                    Button(
                        onClick = {
                            if (layersList.isEmpty()) {
                                Toast.makeText(context, "Add vector items first!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            showSaveLeadDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonMint),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.IntegrationInstructions, contentDescription = null, tint = DeepSlateBg, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PUSH LIVE CONTRACT INTEGRITY PROPOSAL TO YAFTA CRM & INVENTORY DIRECTORIES", color = DeepSlateBg, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ==================== OVERLAYS & SETTINGS MENUS ====================

        // 1. Canvas Dimensions & Backdrops Setting Modal
        if (showCanvasSettingsMenu) {
            AlertDialog(
                onDismissRequest = { showCanvasSettingsMenu = false },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("WORKSPACE BOUNDARIES SETUP", color = BrushedTitanium, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Configure real physical properties of layout board:", color = TextSilver, fontSize = 10.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = canvasWidth,
                                onValueChange = { canvasWidth = it },
                                label = { Text("Width", color = TextSilver, fontSize = 9.sp) },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = canvasHeight,
                                onValueChange = { canvasHeight = it },
                                label = { Text("Height", color = TextSilver, fontSize = 9.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        
                        Text("Applied Measuring Unit:", color = TextSilver, fontSize = 9.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("mm", "cm", "m", "inch").forEach { u ->
                                val active = selectedUnit == u
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (active) NeonPurple else DeepSlateBg)
                                        .clickable { selectedUnit = u }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(u, color = if (active) DeepSlateBg else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showCanvasSettingsMenu = false },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Accept Sizing", color = DeepSlateBg)
                    }
                }
            )
        }

        // 2. Print setups menu overlay
        PrintSetupDialog(
            showPrintSetupMenu = showPrintSetupMenu,
            onDismiss = { showPrintSetupMenu = false },
            colorMode = colorMode,
            onColorModeChange = { colorMode = it },
            dpiSetting = dpiSetting,
            onDpiSettingChange = { dpiSetting = it },
            showBleedField = showBleedField,
            onShowBleedFieldChange = { showBleedField = it },
            showSafeField = showSafeField,
            onShowSafeFieldChange = { showSafeField = it }
        )

        // 3. Save design integrated to CRM & ERP dialogue
        SaveLeadDialog(
            showSaveLeadDialog = showSaveLeadDialog,
            onDismiss = { showSaveLeadDialog = false },
            leadClientBusinessName = leadClientBusinessName,
            onLeadClientBusinessNameChange = { leadClientBusinessName = it },
            leadContactPhoneNum = leadContactPhoneNum,
            onLeadContactPhoneNumChange = { leadContactPhoneNum = it },
            viewModel = viewModel,
            totalAreaSquareMeters = totalAreaSquareMeters,
            canvasWidth = canvasWidth,
            selectedUnit = selectedUnit,
            canvasHeight = canvasHeight,
            estimatedLedModules = estimatedLedModules,
            aluminumProfileMeters = aluminumProfileMeters,
            suggestedRetailPrice = suggestedRetailPrice,
            acrylicSheetsM2 = acrylicSheetsM2,
            unitAcrylicCost = unitAcrylicCost,
            widthFloat = widthFloat,
            heightFloat = heightFloat,
            activeText = activeTextLayers.firstOrNull()?.text ?: "Signboard",
            onCreatedLead = onCreatedLead
        )

        // 4. PowerTRACE SVG Exporter dialog
        PowerTraceExportDialog(
            showCpuSvgExportViewer = showCpuSvgExportViewer,
            onDismiss = { showCpuSvgExportViewer = false },
            canvasWidth = canvasWidth,
            canvasHeight = canvasHeight,
            layersList = layersList
        )

        // 5. Gemini Assistant Response Overlay side panel
        if (showAiAdvicePanel) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(320.dp)
                    .align(Alignment.CenterStart)
            ) {
                AiAdviceSidePanel(
                    showAiAdvicePanel = showAiAdvicePanel,
                    onDismiss = { showAiAdvicePanel = false },
                    aiFeatureClickedTitle = aiFeatureClickedTitle,
                    aiIsLoading = aiIsLoading,
                    aiStudioResult = aiStudioResult
                )
            }
        }
    }
}

@Composable
fun Icons.AsymmetricSendAndArchiveIcon() = Icons.Filled.SendAndArchive

val Icons.Filled.SendAndArchive: ImageVector
    get() = Icons.Filled.CloudUpload
