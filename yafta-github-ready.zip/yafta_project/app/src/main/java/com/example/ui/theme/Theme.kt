package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    onPrimary = DeepSlateBg,
    secondary = NeonCyan,
    onSecondary = DeepSlateBg,
    tertiary = NeonAmber,
    onTertiary = DeepSlateBg,
    background = DeepSlateBg,
    onBackground = BrushedTitanium,
    surface = DarkSlateCard,
    onSurface = BrushedTitanium,
    error = SignalCritical,
    onError = BrushedTitanium,
    outline = BorderGlass
)

private val LightColorScheme = lightColorScheme(
    primary = NeonPurple,
    onPrimary = DeepSlateBg,
    secondary = NeonCyan,
    onSecondary = DeepSlateBg,
    tertiary = NeonAmber,
    onTertiary = DeepSlateBg,
    background = DeepSlateBg, // Always keep the dark creative-studio style active for consistent branding!
    onBackground = BrushedTitanium,
    surface = DarkSlateCard,
    onSurface = BrushedTitanium,
    error = SignalCritical,
    onError = BrushedTitanium,
    outline = BorderGlass
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to strictly enforce our premium branding design system!
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
