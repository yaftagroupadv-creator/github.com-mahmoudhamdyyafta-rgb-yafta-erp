package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM companies ORDER BY id ASC")
    fun getAllCompanies(): Flow<List<Company>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompany(company: Company)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanies(companies: List<Company>)

    @Update
    suspend fun updateCompany(company: Company)

    @Delete
    suspend fun deleteCompany(company: Company)

    @Query("DELETE FROM companies")
    suspend fun clearAllCompanies()
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: Long): User?

    @Query("SELECT * FROM users ORDER BY name ASC")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<User>)

    @Update
    suspend fun updateUser(user: User)

    @Query("DELETE FROM users")
    suspend fun clearAllUsers()
}

@Dao
interface LeadDao {
    @Query("SELECT * FROM leads ORDER BY timestamp DESC")
    fun getAllLeads(): Flow<List<Lead>>

    @Query("SELECT * FROM leads WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getLeadsByCompany(companyId: Long): Flow<List<Lead>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLead(lead: Lead): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeads(leads: List<Lead>)

    @Update
    suspend fun updateLead(lead: Lead)

    @Query("DELETE FROM leads WHERE id = :id")
    suspend fun deleteLeadById(id: Long)

    @Query("DELETE FROM leads")
    suspend fun clearAllLeads()
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY dueDate ASC")
    fun getAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE companyId = :companyId ORDER BY dueDate ASC")
    fun getProjectsByCompany(companyId: Long): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): Project?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProjects(projects: List<Project>)

    @Update
    suspend fun updateProject(project: Project)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)

    @Query("DELETE FROM projects")
    suspend fun clearAllProjects()
}

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_items ORDER BY name ASC")
    fun getAllInventory(): Flow<List<InventoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryItem(item: InventoryItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(items: List<InventoryItem>)

    @Update
    suspend fun updateInventoryItem(item: InventoryItem)

    @Query("DELETE FROM inventory_items WHERE id = :id")
    suspend fun deleteInventoryItem(id: Long)

    @Query("DELETE FROM inventory_items")
    suspend fun clearAllInventory()
}

@Dao
interface FinanceDao {
    @Query("SELECT * FROM finance_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<FinanceTransaction>>

    @Query("SELECT * FROM finance_transactions WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getTransactionsByCompany(companyId: Long): Flow<List<FinanceTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FinanceTransaction): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<FinanceTransaction>)

    @Update
    suspend fun updateTransaction(transaction: FinanceTransaction)

    @Query("DELETE FROM finance_transactions WHERE id = :id")
    suspend fun deleteTransaction(id: Long)

    @Query("DELETE FROM finance_transactions")
    suspend fun clearAllTransactions()
}

@Dao
interface HrTaskDao {
    @Query("SELECT * FROM hr_tasks ORDER BY timestamp DESC")
    fun getAllTasks(): Flow<List<HrTask>>

    @Query("SELECT * FROM hr_tasks WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTasksByUser(userId: Long): Flow<List<HrTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: HrTask): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<HrTask>)

    @Update
    suspend fun updateTask(task: HrTask)

    @Query("DELETE FROM hr_tasks WHERE id = :id")
    suspend fun deleteTask(id: Long)

    @Query("DELETE FROM hr_tasks")
    suspend fun clearAllTasks()
}

@Dao
interface CrmClientDao {
    @Query("SELECT * FROM crm_clients ORDER BY timestamp DESC")
    fun getAllClients(): Flow<List<CrmClient>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: CrmClient): Long

    @Update
    suspend fun updateClient(client: CrmClient)

    @Query("DELETE FROM crm_clients WHERE id = :id")
    suspend fun deleteClientById(id: Long)

    @Query("DELETE FROM crm_clients")
    suspend fun clearAllClients()
}

@Dao
interface CommunicationLogDao {
    @Query("SELECT * FROM crm_communication_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<CommunicationLog>>

    @Query("SELECT * FROM crm_communication_logs WHERE clientId = :clientId ORDER BY timestamp DESC")
    fun getLogsByClient(clientId: Long): Flow<List<CommunicationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: CommunicationLog): Long

    @Update
    suspend fun updateLog(log: CommunicationLog)

    @Query("DELETE FROM crm_communication_logs WHERE id = :id")
    suspend fun deleteLogById(id: Long)

    @Query("DELETE FROM crm_communication_logs WHERE clientId = :clientId")
    suspend fun deleteLogsByClientId(clientId: Long)
}

