package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel
import com.example.ui.NavRoutes

/**
 * REUSABLE BRANDING DESIGN SYSTEM (Unified Core Components)
 */

@Composable
fun PremiumGlassmorphicCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    borderIndicator: Color? = null,
    interactionSource: MutableInteractionSource? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val cardModifier = modifier
        .clip(RoundedCornerShape(16.dp))
        .background(
            Brush.verticalGradient(
                colors = listOf(
                    DarkSlateCard.copy(alpha = 0.95f),
                    DeepSlateBg.copy(alpha = 0.98f)
                )
            )
        )
        .border(
            BorderStroke(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        BorderGlass,
                        (borderIndicator ?: NeonPurple).copy(alpha = 0.2f),
                        BorderGlass
                    )
                )
            ),
            shape = RoundedCornerShape(16.dp)
        )

    if (onClick != null) {
        Column(
            modifier = cardModifier
                .clickable(
                    interactionSource = interactionSource ?: remember { MutableInteractionSource() },
                    indication = LocalIndication.current,
                    onClick = onClick
                )
                .padding(18.dp),
            content = content
        )
    } else {
        Column(
            modifier = cardModifier
                .then(
                    if (interactionSource != null) Modifier.hoverable(interactionSource) else Modifier
                )
                .padding(18.dp),
            content = content
        )
    }
}

@Composable
fun AnimatedGoldCounter(
    value: Double,
    prefix: String = "",
    suffix: String = "",
    color: Color = NeonPurple,
    fontSize: Int = 22
) {
    var finalVal by remember { mutableStateOf(0.0) }
    LaunchedEffect(value) {
        finalVal = value
    }
    val animatedValue by animateFloatAsState(
        targetValue = finalVal.toFloat(),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "gold_counter"
    )
    Text(
        text = "$prefix${String.format("%,.0f", animatedValue)}$suffix",
        color = color,
        style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Black,
            fontSize = fontSize.sp,
            letterSpacing = 0.5.sp
        )
    )
}

/**
 * THE REFACTORED EXECUTIVE OPERATING ENVIRONMENT (HIGH-DENSITY COMPACT WORKFLOW)
 */
@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreenLayout(
    viewModel: YaftaViewModel,
    onNavigateToTab: (String) -> Unit
) {
    val context = LocalContext.current
    val user by viewModel.currentSessionUser.collectAsState()
    
    // Core Module Lists (Consolidated into single state sources to avoid overlapping)
    val projects by viewModel.projectsList.collectAsState()
    val leads by viewModel.leadsList.collectAsState()
    val inventory by viewModel.inventoryList.collectAsState()
    val transactions by viewModel.transactionsList.collectAsState()
    val staffList by viewModel.allStaff.collectAsState()

    // Screen Adaptive Geometry Configuration
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    // Consolidated workflow nested states
    var activeNestedTab by remember { mutableStateOf(0) } // 0 = Hub Summary, 1 = Creative Desk, 2 = Operations Queue, 3 = Financial Ledger
    
    // Bottom Sheets & Popup Controllers
    var showQuickLeadSheet by remember { mutableStateOf(false) }
    var showQuickProjectSheet by remember { mutableStateOf(false) }
    var showQuickExpenseSheet by remember { mutableStateOf(false) }
    var showQuickCadSheet by remember { mutableStateOf(false) }

    // Quick Lead Form states
    var leadClientName by remember { mutableStateOf("") }
    var leadClientPhone by remember { mutableStateOf("") }
    var leadModelType by remember { mutableStateOf("3D Illuminated Sign") } // 3D Illuminated Sign, Neon Acrylic Board, CNC Router Panel, LED Box
    var leadBudgetAmt by remember { mutableStateOf("") }
    var leadNotesVal by remember { mutableStateOf("") }

    // Quick Custom Project Form States
    var projTitle by remember { mutableStateOf("") }
    var projClientName by remember { mutableStateOf("") }
    var projBudget by remember { mutableStateOf("") }
    var projNotes by remember { mutableStateOf("") }
    var projWidth by remember { mutableStateOf("120") }
    var projHeight by remember { mutableStateOf("80") }
    var projText by remember { mutableStateOf("YAFTA") }
    var projColor by remember { mutableStateOf("#D4AF37") }

    // Quick Expense Form States
    var expAmount by remember { mutableStateOf("") }
    var expType by remember { mutableStateOf("Material Purchase") } // Material Purchase, Operations Cost, Staff Salary
    var expDescription by remember { mutableStateOf("") }
    var expRecipient by remember { mutableStateOf("") }

    // Quick Inventory Form States
    var showQuickInventorySheet by remember { mutableStateOf(false) }
    var invName by remember { mutableStateOf("") }
    var invType by remember { mutableStateOf("Acrylic Sheets") } // Acrylic Sheets, Flex Rolls, Led Modules, Transformers, Aluminium Profiles
    var invStock by remember { mutableStateOf("") }
    var invMinStock by remember { mutableStateOf("") }
    var invUnitPrice by remember { mutableStateOf("") }

    // Floating Menu Toggle State
    var isFabMenuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = isTablet.let { if (it) 32.dp else 16.dp })
                .padding(top = 24.dp, bottom = 96.dp)
        ) {
            
            // BRAND HEADER BLOCK (Yafta Billboard Brand Identity)
            var isHeaderVisible by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                isHeaderVisible = true
            }

            AnimatedVisibility(
                visible = isHeaderVisible,
                enter = fadeIn(animationSpec = tween(1000)) + expandVertically(animationSpec = tween(800)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                val screenWidth = LocalConfiguration.current.screenWidthDp
                val mainTitleSize = when {
                    screenWidth >= 960 -> 68.sp
                    screenWidth >= 600 -> 54.sp
                    else -> 42.sp
                }
                val subtitleSize = when {
                    screenWidth >= 960 -> 16.sp
                    screenWidth >= 600 -> 13.sp
                    else -> 10.sp
                }
                val letterSpacingMain = when {
                    screenWidth >= 960 -> 6.sp
                    screenWidth >= 600 -> 4.sp
                    else -> 2.5.sp
                }
                val letterSpacingSub = when {
                    screenWidth >= 960 -> 8.sp
                    screenWidth >= 600 -> 6.sp
                    else -> 3.5.sp
                }
                val brandPadding = if (screenWidth >= 600) 32.dp else 20.dp

                val interactionSource = remember { MutableInteractionSource() }
                val isHovered by interactionSource.collectIsHoveredAsState()

                // Animate properties based on hover state
                val glowIntensity by animateFloatAsState(
                    targetValue = if (isHovered) 0.22f else 0.08f,
                    animationSpec = tween(400)
                )
                val borderAlpha by animateFloatAsState(
                    targetValue = if (isHovered) 0.5f else 0.2f,
                    animationSpec = tween(400)
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF111114).copy(alpha = 0.85f), // DarkSlateCard
                                    Color(0xFF050505).copy(alpha = 0.95f)  // DeepSlateBg
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFFD4AF37).copy(alpha = borderAlpha), // Glowing Gold
                                    Color(0xFF2C2214).copy(alpha = 0.4f)         // Dark bronze
                                )
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            onClick = {}
                        )
                        .padding(vertical = brandPadding, horizontal = brandPadding)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 1. Active status / Breathing Live Indicator pill
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(30.dp))
                                .background(Color(0xFFD4AF37).copy(alpha = 0.06f))
                                .border(1.dp, Color(0xFFD4AF37).copy(alpha = 0.15f), RoundedCornerShape(30.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            val infiniteTransition = rememberInfiniteTransition()
                            val breatheAlpha by infiniteTransition.animateFloat(
                                initialValue = 0.3f,
                                targetValue = 1.0f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1400, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                )
                            )

                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE5C158).copy(alpha = breatheAlpha)) // Glowing gold
                            )
                            Text(
                                text = "SYSTEM LIVE",
                                color = Color(0xFFFFF5DF),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "•",
                                color = Color(0xFFD4AF37).copy(alpha = 0.3f),
                                fontSize = 8.sp
                            )
                            Text(
                                text = "يافطة للدعاية والإعلان",
                                color = Color(0xFFC0B299),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // 2. YAFTA gold gradient title with subtle ambient glow
                        Box(contentAlignment = Alignment.Center) {
                            Box(
                                modifier = Modifier
                                    .size(width = 240.dp, height = 60.dp)
                                    .background(
                                        Brush.radialGradient(
                                            colors = listOf(
                                                Color(0xFFD4AF37).copy(alpha = glowIntensity),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            Text(
                                text = "YAFTA",
                                style = TextStyle(
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFFD4AF37), // Primary Gold
                                            Color(0xFFE6C768), // Secondary Gold
                                            Color(0xFFFFF5DF), // Highlight
                                            Color(0xFFB38F4D)  // Backing shadow Gold
                                        )
                                    ),
                                    letterSpacing = letterSpacingMain,
                                    fontWeight = FontWeight.Black,
                                    fontSize = mainTitleSize
                                ),
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // 3. Separator lines on both sides: ───── FOR ADVERTISING ─────
                        Row(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .widthIn(max = 480.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(1.dp)
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(Color.Transparent, Color(0xFFD4AF37).copy(alpha = 0.4f))
                                        )
                                    )
                            )
                            Text(
                                text = "FOR ADVERTISING",
                                color = Color(0xFFA0A0A0), // `#A0A0A0` Secondary
                                fontSize = subtitleSize,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = letterSpacingSub,
                                modifier = Modifier.padding(horizontal = 14.dp),
                                textAlign = TextAlign.Center
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(1.dp)
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(Color(0xFFD4AF37).copy(alpha = 0.4f), Color.Transparent)
                                        )
                                    )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 4. Subtitle metadata
                        Text(
                            text = "PREMIUM ENTERPRISE HUD  •  OPERATOR: ${(user?.name ?: "BRANDING PARTNER").uppercase()}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFFC0B299).copy(alpha = 0.7f), // Muted gold-sand text
                                letterSpacing = 1.2.sp,
                                fontSize = 9.sp
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // NESTED SEGMENTS SWITCHER BAR (Isolates views under a single compact environment)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, BorderGlass, RoundedCornerShape(14.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val menuTabs = listOf("Executive", "Creative", "Operations", "Finance")
                val arabicTabs = listOf("الرئيسية", "التصميم", "الإنتاج", "الحسابات")
                val iconsLst = listOf(Icons.Filled.Dashboard, Icons.Filled.Palette, Icons.Filled.PrecisionManufacturing, Icons.Filled.Payments)

                menuTabs.forEachIndexed { index, title ->
                    val isSelected = activeNestedTab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) NeonPurple else Color.Transparent)
                            .clickable { activeNestedTab = index }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = iconsLst[index],
                                contentDescription = null,
                                tint = if (isSelected) DeepSlateBg else TextSilver,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = arabicTabs[index],
                                color = if (isSelected) DeepSlateBg else TextSilver,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // DUAL-CONTENT RENDERING BASED ON ACTIVE NESTED TAB
            AnimatedContent(
                targetState = activeNestedTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) with fadeOut(animationSpec = tween(180))
                },
                label = "dashboard_tabs"
            ) { targetTab ->
                when (targetTab) {
                    0 -> ExecutiveTabContent(
                        leads = leads,
                        projects = projects,
                        inventory = inventory,
                        transactions = transactions,
                        onNavigate = onNavigateToTab
                    )
                    1 -> CreativeTabContent(
                        projects = projects,
                        aiBrief = viewModel.aiBriefResult.collectAsState().value,
                        aiIsLoading = viewModel.aiIsLoading.collectAsState().value,
                        triggerAiBrief = { viewModel.triggerAiBriefOutline(it) },
                        onNavigate = onNavigateToTab
                    )
                    2 -> OperationsTabContent(
                        projects = projects,
                        onUpdateStatus = { proj, sc -> viewModel.updateProjectStatus(proj, sc) },
                        onNavigate = onNavigateToTab
                    )
                    3 -> FinanceTabContent(
                        transactions = transactions,
                        onMarkPaid = { viewModel.markTransactionPaid(it) },
                        onNavigate = onNavigateToTab
                    )
                }
            }
        }

        // FLOATING DYNAMIC QUICK ACTIONS SPEED DIAL MENU WITH INTEGRATED ACTIONS
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp),
            contentAlignment = Alignment.BottomEnd
        ) {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Expanded Action Items
                AnimatedVisibility(
                    visible = isFabMenuExpanded,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        // Action 1: New CRM Lead
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.clickable {
                                showQuickLeadSheet = true
                                isFabMenuExpanded = false
                            }
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                                border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "New Lead / عميل جديد",
                                    color = BrushedTitanium,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                            FloatingActionButton(
                                onClick = {
                                    showQuickLeadSheet = true
                                    isFabMenuExpanded = false
                                },
                                containerColor = NeonPurple,
                                contentColor = DeepSlateBg,
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(imageVector = Icons.Filled.Contacts, contentDescription = "New Lead", modifier = Modifier.size(18.dp))
                            }
                        }

                        // Action 2: New Project
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.clickable {
                                showQuickProjectSheet = true
                                isFabMenuExpanded = false
                            }
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                                border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "New Project / مشروع جديد",
                                    color = BrushedTitanium,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                            FloatingActionButton(
                                onClick = {
                                    showQuickProjectSheet = true
                                    isFabMenuExpanded = false
                                },
                                containerColor = NeonPurple,
                                contentColor = DeepSlateBg,
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(imageVector = Icons.Filled.Build, contentDescription = "New Project", modifier = Modifier.size(18.dp))
                            }
                        }

                        // Action 3: New Inventory Item
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.clickable {
                                showQuickInventorySheet = true
                                isFabMenuExpanded = false
                            }
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
                                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "New Material / مادة بمستودع",
                                    color = BrushedTitanium,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                            FloatingActionButton(
                                onClick = {
                                    showQuickInventorySheet = true
                                    isFabMenuExpanded = false
                                },
                                containerColor = NeonCyan,
                                contentColor = DeepSlateBg,
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(imageVector = Icons.Filled.Store, contentDescription = "New Inventory Item", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                // Main Floating Action Button
                ExtendedFloatingActionButton(
                    onClick = { isFabMenuExpanded = !isFabMenuExpanded },
                    containerColor = if (isFabMenuExpanded) SignalCritical else NeonPurple,
                    contentColor = DeepSlateBg,
                    shape = RoundedCornerShape(16.dp),
                    elevation = FloatingActionButtonDefaults.elevation(8.dp),
                    modifier = Modifier.border(1.5.dp, NeonMint.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                ) {
                    Icon(
                        imageVector = if (isFabMenuExpanded) Icons.Filled.Close else Icons.Filled.Add,
                        contentDescription = "Expand menu",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isFabMenuExpanded) "Close / إغلاق" else "Quick Actions / إجراءات سريعة",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        /**
         * DYNAMIC BOTTOM DIALOGS (Clean Sheet Overlays)
         */

        // 1. QUICK LEAD SHEET
        if (showQuickLeadSheet) {
            AlertDialog(
                onDismissRequest = { showQuickLeadSheet = false },
                containerColor = DarkSlateCard,
                modifier = Modifier
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.Contacts, contentDescription = null, tint = NeonPurple)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Yafta Lead Generator / تسجيل عميل يافطة", color = BrushedTitanium, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        OutlinedTextField(
                            value = leadClientName,
                            onValueChange = { leadClientName = it },
                            label = { Text("Client Corporate Name / اسم الشركة", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = leadClientPhone,
                            onValueChange = { leadClientPhone = it },
                            label = { Text("Contact Phone / رقم التواصل", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = leadBudgetAmt,
                            onValueChange = { leadBudgetAmt = it },
                            label = { Text("Initial Budget Estimate (SAR) / الميزانية المقدرة", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = leadNotesVal,
                            onValueChange = { leadNotesVal = it },
                            label = { Text("Design Brief Draft / تفاصيل اللوحة", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val est = leadBudgetAmt.toDoubleOrNull() ?: 0.0
                            if (leadClientName.isEmpty()) {
                                Toast.makeText(context, "Please configure valid client details", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addLead(
                                clientName = leadClientName,
                                clientPhone = leadClientPhone,
                                projectType = leadModelType,
                                designBrief = leadNotesVal,
                                estimatedValue = est
                            )
                            Toast.makeText(context, "Lead saved successfully!", Toast.LENGTH_SHORT).show()
                            showQuickLeadSheet = false
                            // Reset
                            leadClientName = ""
                            leadClientPhone = ""
                            leadBudgetAmt = ""
                            leadNotesVal = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Deploy Lead", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showQuickLeadSheet = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 2. QUICK DESIGN CAD CREATOR
        if (showQuickCadSheet) {
            AlertDialog(
                onDismissRequest = { showQuickCadSheet = false },
                containerColor = DarkSlateCard,
                modifier = Modifier
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.Palette, contentDescription = null, tint = NeonCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("CAD Signage Mockup Tool", color = BrushedTitanium, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = "Render and test premium corporate identity templates directly.",
                            color = TextSilver,
                            fontSize = 11.sp
                        )
                        OutlinedTextField(
                            value = projTitle,
                            onValueChange = { projTitle = it },
                            label = { Text("Display Label / العنوان", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = projText,
                            onValueChange = { projText = it },
                            label = { Text("Custom Engraved Sign Text / نص اللوحة", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Use the CAD workspace tab for precise dimension vectors and live previews.",
                            color = NeonPurple,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showQuickCadSheet = false
                            onNavigateToTab(NavRoutes.DESIGN_STUDIO)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                    ) {
                        Text("Go to CAD Lab", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showQuickCadSheet = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 3. QUICK INDUSTRIAL SIGN PRODUCTION SHEET
        if (showQuickProjectSheet) {
            AlertDialog(
                onDismissRequest = { showQuickProjectSheet = false },
                containerColor = DarkSlateCard,
                modifier = Modifier
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.Hardware, contentDescription = null, tint = NeonPurple)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Industrial Signage Project", color = BrushedTitanium, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        OutlinedTextField(
                            value = projTitle,
                            onValueChange = { projTitle = it },
                            label = { Text("Project Title (e.g. Mega 3D LED Board)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = projClientName,
                            onValueChange = { projClientName = it },
                            label = { Text("Client Name / اسم العميل", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = projBudget,
                            onValueChange = { projBudget = it },
                            label = { Text("Total Contract Value (SAR)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = projNotes,
                            onValueChange = { projNotes = it },
                            label = { Text("Engineering Materials Checklist / المكونات", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val amtVal = projBudget.toDoubleOrNull() ?: 1000.0
                            if (projTitle.isEmpty() || projClientName.isEmpty()) {
                                Toast.makeText(context, "Please complete fields", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val designerId = staffList.firstOrNull { it.role == "Designer" }?.id ?: 1L
                            val fabricatorId = staffList.firstOrNull { it.role == "Fabricator" }?.id ?: 2L
                            val installerId = staffList.firstOrNull { it.role == "Installer" }?.id ?: 3L

                            viewModel.addCustomProject(
                                title = projTitle,
                                clientName = projClientName,
                                budget = amtVal,
                                notes = projNotes,
                                widthCm = projWidth.toDoubleOrNull() ?: 120.0,
                                heightCm = projHeight.toDoubleOrNull() ?: 80.0,
                                colorHex = projColor,
                                signText = projText,
                                assignedDesigner = designerId,
                                assignedFabricator = fabricatorId,
                                assignedInstaller = installerId
                            )
                            Toast.makeText(context, "Production Job scheduled!", Toast.LENGTH_SHORT).show()
                            showQuickProjectSheet = false
                            // Reset
                            projTitle = ""
                            projClientName = ""
                            projBudget = ""
                            projNotes = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Issue Production Order", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showQuickProjectSheet = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 5. QUICK INVENTORY SHEETS / MATERIAL DIALOG
        if (showQuickInventorySheet) {
            AlertDialog(
                onDismissRequest = { showQuickInventorySheet = false },
                containerColor = DarkSlateCard,
                modifier = Modifier
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.Store, contentDescription = null, tint = NeonCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Add Inventory Material / تسجيل مادة", color = BrushedTitanium, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        OutlinedTextField(
                            value = invName,
                            onValueChange = { invName = it },
                            label = { Text("Material/Item Name (e.g. Red Laser Plexiglass)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = invType,
                            onValueChange = { invType = it },
                            label = { Text("Item Material Type (e.g. LED Light)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = invStock,
                            onValueChange = { invStock = it },
                            label = { Text("Current Quality Stock Count", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = invMinStock,
                            onValueChange = { invMinStock = it },
                            label = { Text("Minimum Stock Warning Alert Level", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = invUnitPrice,
                            onValueChange = { invUnitPrice = it },
                            label = { Text("Unit Price (SAR)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val stockVal = invStock.toDoubleOrNull() ?: 1.0
                            val minStockVal = invMinStock.toDoubleOrNull() ?: 1.0
                            val priceVal = invUnitPrice.toDoubleOrNull() ?: 0.0

                            if (invName.isEmpty() || invType.isEmpty()) {
                                Toast.makeText(context, "Please configure valid material names", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            viewModel.addInventoryItem(
                                name = invName,
                                materialType = invType,
                                currentStock = stockVal,
                                minimumStockAlert = minStockVal,
                                unitPrice = priceVal
                            )

                            Toast.makeText(context, "New warehouse stock added!", Toast.LENGTH_SHORT).show()
                            showQuickInventorySheet = false

                            // Reset
                            invName = ""
                            invType = "Acrylic Sheets"
                            invStock = ""
                            invMinStock = ""
                            invUnitPrice = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                    ) {
                        Text("Add to Warehouse", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showQuickInventorySheet = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }

        // 4. QUICK EXPENSE LEDGER RECORD SHEET
        if (showQuickExpenseSheet) {
            AlertDialog(
                onDismissRequest = { showQuickExpenseSheet = false },
                containerColor = DarkSlateCard,
                modifier = Modifier
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.AddCard, contentDescription = null, tint = NeonPurple)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Log Raw Materials / Expense Receipt", color = BrushedTitanium, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        OutlinedTextField(
                            value = expAmount,
                            onValueChange = { expAmount = it },
                            label = { Text("Taxable Amount (SAR)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = expDescription,
                            onValueChange = { expDescription = it },
                            label = { Text("Expense Itemization / التفاصيل الضريبية", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = expRecipient,
                            onValueChange = { expRecipient = it },
                            label = { Text("Supplier Name / المورد", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val ramt = expAmount.toDoubleOrNull() ?: 0.0
                            if (expDescription.isEmpty() || ramt <= 0.0) {
                                Toast.makeText(context, "Log a valid non-zero transaction value", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.addTransaction(
                                amount = ramt,
                                type = expType,
                                description = expDescription,
                                isPaid = true,
                                arabicRecipient = expRecipient.ifEmpty { "وكالة يافطة" }
                            )
                            Toast.makeText(context, "Expense documented!", Toast.LENGTH_SHORT).show()
                            showQuickExpenseSheet = false
                            // Reset
                            expAmount = ""
                            expDescription = ""
                            expRecipient = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Record Entry", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showQuickExpenseSheet = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }
    }
}

/**
 * TAB CONCEPTS SECTION (Strict Separation of Concerns)
 */

// TAB 0: THE HUB EXECUTIVE SUITE
@Composable
fun ExecutiveTabContent(
    leads: List<Lead>,
    projects: List<Project>,
    inventory: List<InventoryItem>,
    transactions: List<FinanceTransaction>,
    onNavigate: (String) -> Unit
) {
    // Isolated metrics calculations in Hub
    val pipelineVal = leads.filter { it.status != "Lost" }.sumOf { it.estimatedValue }
    val activeSignsNum = projects.filter { it.status != "Completed" }.size
    val totalRevenueVal = transactions.filter { it.isPaid && it.type == "Invoice Income" }.sumOf { it.amount }
    val criticalInventoryRefills = inventory.filter { it.currentStock <= it.minimumStockAlert }.size

    Column(
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        // High-fidelity Stats Display
        Text(
            text = "REAL-TIME STUDIO LEDGER / الملخص المالي والعمليات",
            color = NeonPurple,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            PremiumGlassmorphicCard(modifier = Modifier.weight(1.3f)) {
                Text("Settled Revenue (إجمالي الدخل)", color = TextSilver, style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(4.dp))
                AnimatedGoldCounter(value = totalRevenueVal, prefix = "SAR ")
                Spacer(modifier = Modifier.height(4.dp))
                Text("Includes 15% Standard KSA VAT", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            PremiumGlassmorphicCard(modifier = Modifier.weight(1f)) {
                Text("Leads Pipeline (الصفقات)", color = TextSilver, style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(4.dp))
                AnimatedGoldCounter(value = pipelineVal, prefix = "SAR ")
                Spacer(modifier = Modifier.height(4.dp))
                Text("Active Opportunities", color = TextSilver, fontSize = 9.sp)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            PremiumGlassmorphicCard(modifier = Modifier.weight(1f)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Factory Workloads", color = TextSilver, style = MaterialTheme.typography.bodySmall)
                    Icon(imageVector = Icons.Filled.PrecisionManufacturing, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$activeSignsNum Active Signs",
                    color = BrushedTitanium,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text("Under assembly line", color = TextSilver, fontSize = 9.sp)
            }

            PremiumGlassmorphicCard(modifier = Modifier.weight(1f)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Material Alerts", color = TextSilver, style = MaterialTheme.typography.bodySmall)
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = null,
                        tint = if (criticalInventoryRefills > 0) SignalCritical else NeonMint,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$criticalInventoryRefills Items Low",
                    color = if (criticalInventoryRefills > 0) SignalCritical else BrushedTitanium,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = if (criticalInventoryRefills > 0) "Needs Refill!" else "Warehouse secure",
                    color = if (criticalInventoryRefills > 0) SignalCritical else NeonCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // DETAILED MODULAR GRID (pending CRM tasks, current inventory status, & recent project milestones)
        ModularStudioGrid(
            leads = leads,
            inventory = inventory,
            projects = projects,
            onNavigate = onNavigate
        )

        // STUDIO CONTROL WORKSPACES
        Text(
            text = "YAFTA CREATIVE STUDIO ROOMS / قاعات التصميم والذكاء الاصطناعي",
            color = TextSilver,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, BorderGlass, RoundedCornerShape(12.dp))
                    .clickable { onNavigate(NavRoutes.DESIGN_STUDIO) }
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Filled.Brush, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("CAD Designer Studio", color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Neon customizer & live render", color = TextSilver, fontSize = 10.sp)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSlateCard)
                    .border(1.dp, BorderGlass, RoundedCornerShape(12.dp))
                    .clickable { onNavigate(NavRoutes.GEMINI_AI) }
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonPurple.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Filled.AutoAwesome, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Gemini Creative AI", color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Slogans & technical copy keys", color = TextSilver, fontSize = 10.sp)
                    }
                }
            }
        }

        // RECENT PROJECT QUEUES LIST
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE ILLUMINATED PROJECTS / تتبع لوحات الخط المباشر",
                color = TextSilver,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "Show All",
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onNavigate(NavRoutes.PROJECTS) }
            )
        }

        if (projects.isEmpty()) {
            PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Icon(imageVector = Icons.Filled.Wallpaper, contentDescription = null, tint = TextSilver, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No Active signboards currently under fabrication.", color = TextSilver, fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                projects.take(3).forEach { proj ->
                    ActiveProjectSummaryItem(proj)
                }
            }
        }
    }
}

// TAB 1: THE CREATIVE DESIGN SUITE (De-tangling & Separation of Concerns)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreativeTabContent(
    projects: List<Project>,
    aiBrief: String,
    aiIsLoading: Boolean,
    triggerAiBrief: (String) -> Unit,
    onNavigate: (String) -> Unit
) {
    var rawBriefNotes by remember { mutableStateOf("") }

    Column(
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        // Creative showroom intro text
        Text(
            text = "CREATIVE SHOWROOM LAB & ENGRAVING BLUES / لوحة التحكم الإبداعية والهندسية",
            color = NeonPurple,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp
        )

        PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Text("CAD Studio Vector Launcher / لوحة التصميم الهندسي", color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Construct architectural custom neon and acrylic dimensions. Output vectors direct to CNC fiber laser cutting systems.",
                color = TextSilver,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = { onNavigate(NavRoutes.DESIGN_STUDIO) },
                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Filled.Architecture, contentDescription = null, tint = DeepSlateBg)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Launch Full CAD Configurator", color = DeepSlateBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Gemini AI Copy outline generator module
        PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Text("AI Creative Copywriter / الكاتب الإبداعي الذكي", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Draft core business briefs below to refine technical specifications and signage dimensions automatically via Gemini model.",
                color = TextSilver,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = rawBriefNotes,
                onValueChange = { rawBriefNotes = it },
                label = { Text("Rough Client Specs / مواصفات أولية", color = TextSilver, fontSize = 11.sp) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium),
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (rawBriefNotes.isNotEmpty()) {
                        triggerAiBrief(rawBriefNotes)
                    }
                },
                enabled = !aiIsLoading,
                colors = ButtonDefaults.buttonColors(containerColor = DarkSlateCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, BorderGlass, RoundedCornerShape(10.dp))
            ) {
                if (aiIsLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = NeonCyan, strokeWidth = 2.dp)
                } else {
                    Icon(imageVector = Icons.Filled.AutoAwesome, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Draft Brief Technical Specs", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (aiBrief.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = BorderGlass)
                Spacer(modifier = Modifier.height(10.dp))
                Text("Refined Gemini Engineering Outline:", color = NeonMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DeepSlateBg)
                        .padding(10.dp)
                ) {
                    Text(text = aiBrief, color = BrushedTitanium, fontSize = 11.sp)
                }
            }
        }
    }
}

// TAB 2: OPERATIONS FABRICATION QUEUES KANBAN
@Composable
fun OperationsTabContent(
    projects: List<Project>,
    onUpdateStatus: (Project, String) -> Unit,
    onNavigate: (String) -> Unit
) {
    val kanbanStages = listOf("Design Draft", "Printing/Laser Cut", "Fabrication & Wiring", "Installation", "Completed")
    var selectedStageIndex by remember { mutableStateOf(0) }

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "FACTORY FABRICATION PIPELINES / خطوط الإنتاج والقص ليزر",
            color = NeonPurple,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp
        )

        // Stage Selector Slider (Kanban tabs switcher)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            kanbanStages.forEachIndexed { idx, stage ->
                val isSelectedStage = selectedStageIndex == idx
                val count = projects.count { it.status == stage }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelectedStage) NeonPurple else DarkSlateCard)
                        .border(1.dp, BorderGlass, RoundedCornerShape(8.dp))
                        .clickable { selectedStageIndex = idx }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$stage ($count)",
                            color = if (isSelectedStage) DeepSlateBg else BrushedTitanium,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        val filteredProj = projects.filter { it.status == kanbanStages[selectedStageIndex] }

        if (filteredProj.isEmpty()) {
            PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(imageVector = Icons.Filled.Inbox, contentDescription = null, tint = TextSilver, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("No projects currently in [${kanbanStages[selectedStageIndex]}] stage.", color = TextSilver, fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                filteredProj.forEach { proj ->
                    PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(proj.title, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Client: ${proj.clientName} | Budget: SAR ${proj.totalBudget}", color = TextSilver, fontSize = 10.sp)
                                if (proj.notes.isNotEmpty()) {
                                    Text("Specs: ${proj.notes}", color = NeonCyan, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }

                            // Cycle status controller button
                            IconButton(
                                onClick = {
                                    val nextStatusIndex = (selectedStageIndex + 1) % kanbanStages.size
                                    onUpdateStatus(proj, kanbanStages[nextStatusIndex])
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NeonPurple.copy(alpha = 0.15f))
                            ) {
                                Icon(imageVector = Icons.Filled.Forward, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        // CNC Router pilot controls references
        PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth(), borderIndicator = NeonCyan) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Filled.Memory, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("CNC Fiber Laser System Pilot / الماكينة الذكية للقص ليزر", color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("Fiber Laser Tube ready. Current pressure secured: 5.4 Bar Gas", color = TextSilver, fontSize = 9.sp)
                }
            }
        }
    }
}

// TAB 3: FINANCE EXPENSE & INCOME LEDGERS
@Composable
fun FinanceTabContent(
    transactions: List<FinanceTransaction>,
    onMarkPaid: (FinanceTransaction) -> Unit,
    onNavigate: (String) -> Unit
) {
    // Analytics calculations
    val totalIncomes = transactions.filter { it.type == "Invoice Income" && it.isPaid }.sumOf { it.amount }
    val totalExpenses = transactions.filter { it.type != "Invoice Income" && it.isPaid }.sumOf { it.amount }
    val pendingIncomes = transactions.filter { it.type == "Invoice Income" && !it.isPaid }.sumOf { it.amount }

    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "KSA FINANCIAL LEDGER & VAT STREAMS / الميزانية والضرائب",
            color = NeonPurple,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp
        )

        // Triple summary stats layout with animated counters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PremiumGlassmorphicCard(modifier = Modifier.weight(1.3f)) {
                Text("Settled Balance", color = TextSilver, fontSize = 10.sp)
                Spacer(modifier = Modifier.height(4.dp))
                AnimatedGoldCounter(value = totalIncomes, prefix = "SAR ", fontSize = 15)
                Spacer(modifier = Modifier.height(2.dp))
                Text("Cleared Studio Cash", color = NeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }

            PremiumGlassmorphicCard(modifier = Modifier.weight(1f)) {
                Text("Outflows Paid", color = SignalCritical, fontSize = 10.sp)
                Spacer(modifier = Modifier.height(4.dp))
                AnimatedGoldCounter(value = totalExpenses, prefix = "SAR ", color = SignalCritical, fontSize = 15)
                Spacer(modifier = Modifier.height(2.dp))
                Text("Suppliers & Wages", color = TextSilver, fontSize = 8.sp)
            }

            PremiumGlassmorphicCard(modifier = Modifier.weight(1f)) {
                Text("Unsettled Funds", color = NeonAmber, fontSize = 10.sp)
                Spacer(modifier = Modifier.height(4.dp))
                AnimatedGoldCounter(value = pendingIncomes, prefix = "SAR ", color = NeonAmber, fontSize = 15)
                Spacer(modifier = Modifier.height(2.dp))
                Text("Active Contracts", color = TextSilver, fontSize = 8.sp)
            }
        }

        // Ledger entry list (recent 4 transactions)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RECENT LEDGER DEPLOYMENTS / أحدث القيود والمقبوضات",
                color = TextSilver,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "Show Invoices",
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onNavigate(NavRoutes.FINANCE) }
            )
        }

        if (transactions.isEmpty()) {
            PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                ) {
                    Icon(imageVector = Icons.Filled.Payments, contentDescription = null, tint = TextSilver, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Cash ledger stream is currently empty.", color = TextSilver, fontSize = 11.sp, textAlign = TextAlign.Center)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                transactions.take(4).forEach { trans ->
                    PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth(), borderIndicator = if (trans.isPaid) NeonMint else NeonAmber) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Text(trans.description, color = BrushedTitanium, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("Ref Recipient: ${trans.arabicRecipientName} | VAT: 15% Included", color = TextSilver, fontSize = 9.sp)
                            }

                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(0.8f)) {
                                Text(
                                    text = "SAR ${String.format("%,.1f", trans.amount)}",
                                    color = if (trans.type == "Invoice Income") NeonPurple else SignalCritical,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )

                                if (!trans.isPaid) {
                                    Button(
                                        onClick = { onMarkPaid(trans) },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonAmber),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(24.dp)
                                    ) {
                                        Text("Settle Entry", color = DeepSlateBg, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                    }
                                } else {
                                    Text("Paid / تم الدفع", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * COMPRESSED ACTIVE SUMMARY ROW ITEM
 */
@Composable
fun ActiveProjectSummaryItem(project: Project) {
    val progressPercent = when (project.status) {
        "Design Draft" -> 0.15f
        "Client Approval" -> 0.35f
        "Printing/Laser Cut" -> 0.55f
        "Fabrication & Wiring" -> 0.75f
        "Installation" -> 0.90f
        "Completed" -> 1.0f
        else -> 0.1f
    }
    val statusColor = when (project.status) {
        "Design Draft" -> NeonPurple
        "Client Approval" -> NeonMint
        "Printing/Laser Cut" -> NeonCyan
        "Fabrication & Wiring" -> NeonAmber
        "Installation" -> SignalCritical
        "Completed" -> NeonMint
        else -> TextSilver
    }

    PremiumGlassmorphicCard(modifier = Modifier.fillMaxWidth(), borderIndicator = statusColor) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    text = project.title,
                    color = BrushedTitanium,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Client: ${project.clientName} | Budget: SAR ${project.totalBudget}",
                    color = TextSilver,
                    fontSize = 10.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(statusColor.copy(alpha = 0.12f))
                    .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = project.status,
                    color = statusColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
                progress = progressPercent,
                color = statusColor,
                trackColor = BorderGlass,
                modifier = Modifier
                    .weight(1f)
                    .height(4.dp)
                    .clip(CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${(progressPercent * 100).toInt()}%",
                color = TextSilver,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * MODULAR DASHBOARD INTELLIGENCE GRID SYSTEM
 * Displays summary cards for pending CRM tasks, current inventory status, and recent project milestones.
 */
@Composable
fun ModularStudioGrid(
    leads: List<Lead>,
    inventory: List<InventoryItem>,
    projects: List<Project>,
    onNavigate: (String) -> Unit
) {
    val isTablet = LocalConfiguration.current.screenWidthDp >= 600

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "MODULAR OPERATIONS INTELLIGENCE / لوحة مراقبة العمليات والمهام",
            color = TextSilver,
            fontWeight = FontWeight.ExtraBold,
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
        )

        if (isTablet) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    PendingCrmTasksCard(leads = leads, onNavigate = onNavigate)
                }
                Box(modifier = Modifier.weight(1f)) {
                    CurrentInventoryStatusCard(inventory = inventory, onNavigate = onNavigate)
                }
                Box(modifier = Modifier.weight(1f)) {
                    RecentProjectMilestonesCard(projects = projects, onNavigate = onNavigate)
                }
            }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                PendingCrmTasksCard(leads = leads, onNavigate = onNavigate)
                CurrentInventoryStatusCard(inventory = inventory, onNavigate = onNavigate)
                RecentProjectMilestonesCard(projects = projects, onNavigate = onNavigate)
            }
        }
    }
}

@Composable
fun PendingCrmTasksCard(
    leads: List<Lead>,
    onNavigate: (String) -> Unit
) {
    val pendingLeads = leads.filter { it.status in listOf("New", "Briefing", "Quoted") }
    val interactionSource = remember { MutableInteractionSource() }
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val isActive = isHovered || isPressed

    val translationY by animateDpAsState(
        targetValue = if (isActive) (-6).dp else 0.dp,
        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
        label = "lift_crm"
    )

    PremiumGlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 190.dp)
            .offset(y = translationY),
        onClick = { onNavigate(NavRoutes.CRM) },
        borderIndicator = NeonPurple,
        interactionSource = interactionSource
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Assignment,
                    contentDescription = null,
                    tint = NeonPurple,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Pending CRM Tasks",
                        color = BrushedTitanium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "المتابعات التسويقية المعلقة",
                        color = TextSilver,
                        fontSize = 10.sp
                    )
                }
            }
            
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(NeonPurple.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "${pendingLeads.size} Active",
                    color = NeonCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        
        Spacer(modifier = Modifier.height(14.dp))
        
        if (pendingLeads.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "All CRM items resolved",
                    color = TextSilver,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "جميع المتابعات مكتملة",
                    color = NeonCyan,
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                pendingLeads.take(2).forEach { lead ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BorderGlass.copy(alpha = 0.2f))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = lead.clientName,
                                color = BrushedTitanium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = lead.projectType,
                                color = TextSilver,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "SAR ${String.format("%,.0f", lead.estimatedValue)}",
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(BorderGlass)
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = lead.status,
                                    color = NeonPurple,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = isActive,
            enter = fadeIn() + expandVertically(expandFrom = Alignment.Top),
            exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Top)
        ) {
            Column {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "View Details / عرض التفاصيل",
                        color = NeonPurple,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Filled.ArrowForward,
                        contentDescription = null,
                        tint = NeonPurple,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CurrentInventoryStatusCard(
    inventory: List<InventoryItem>,
    onNavigate: (String) -> Unit
) {
    val lowStockItems = inventory.filter { it.currentStock <= it.minimumStockAlert }
    val displayItems = (lowStockItems + inventory.filter { it.currentStock > it.minimumStockAlert }).take(2)
    val interactionSource = remember { MutableInteractionSource() }
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val isActive = isHovered || isPressed

    val translationY by animateDpAsState(
        targetValue = if (isActive) (-6).dp else 0.dp,
        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
        label = "lift_inv"
    )

    PremiumGlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 190.dp)
            .offset(y = translationY),
        onClick = { onNavigate(NavRoutes.INVENTORY) },
        borderIndicator = NeonCyan,
        interactionSource = interactionSource
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Store,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Warehouse Stock",
                        color = BrushedTitanium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "مستوى مخزون المواد",
                        color = TextSilver,
                        fontSize = 10.sp
                    )
                }
            }
            
            if (lowStockItems.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(SignalCritical.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "${lowStockItems.size} Alerts",
                        color = NeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonPurple.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "Optimal",
                        color = NeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(14.dp))
        
        if (inventory.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().height(100.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No inventory track data found", color = TextSilver, fontSize = 11.sp)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                displayItems.forEach { item ->
                    val isCritical = item.currentStock <= item.minimumStockAlert
                    val ratio = if (item.minimumStockAlert > 0) (item.currentStock / (item.minimumStockAlert * 3)).coerceIn(0.0, 1.0) else 0.5
                    
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BorderGlass.copy(alpha = 0.2f))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.name,
                                color = BrushedTitanium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${item.currentStock.toInt()} Units",
                                color = if (isCritical) SignalCritical else NeonCyan,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        LinearProgressIndicator(
                            progress = ratio.toFloat(),
                            color = if (isCritical) SignalCritical else NeonPurple,
                            trackColor = BorderGlass,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = if (isCritical) "Refill required! (Alert Limit: ${item.minimumStockAlert.toInt()})" else "Sufficient stock level",
                                color = if (isCritical) SignalCritical else TextSilver,
                                fontSize = 8.sp
                            )
                            Text(
                                text = "${(ratio * 100).toInt()}% ratio",
                                color = TextSilver,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = isActive,
            enter = fadeIn() + expandVertically(expandFrom = Alignment.Top),
            exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Top)
        ) {
            Column {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "View Details / عرض التفاصيل",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Filled.ArrowForward,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun RecentProjectMilestonesCard(
    projects: List<Project>,
    onNavigate: (String) -> Unit
) {
    val activeProj = projects.filter { it.status != "Completed" }
    val displayProjects = activeProj.sortedBy { it.dueDate }.take(2)
    val interactionSource = remember { MutableInteractionSource() }
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val isActive = isHovered || isPressed

    val translationY by animateDpAsState(
        targetValue = if (isActive) (-6).dp else 0.dp,
        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
        label = "lift_proj"
    )

    PremiumGlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 190.dp)
            .offset(y = translationY),
        onClick = { onNavigate(NavRoutes.PROJECTS) },
        borderIndicator = NeonPurple,
        interactionSource = interactionSource
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Flag,
                    contentDescription = null,
                    tint = NeonPurple,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Active Milestones",
                        color = BrushedTitanium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "معالم مراحل الإنتاج الجارية",
                        color = TextSilver,
                        fontSize = 10.sp
                    )
                }
            }
            
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(NeonPurple.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "${activeProj.size} Active",
                    color = NeonCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        
        Spacer(modifier = Modifier.height(14.dp))
        
        if (activeProj.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "No active production orders",
                    color = TextSilver,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "لا يوجد طلبات جارية حالياً",
                    color = NeonCyan,
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                displayProjects.forEach { proj ->
                    val progressPercent = when (proj.status) {
                        "Design Draft" -> 0.2f
                        "Client Approval" -> 0.4f
                        "Printing/Laser Cut" -> 0.6f
                        "Fabrication & Wiring" -> 0.8f
                        "Installation" -> 0.9f
                        else -> 1.0f
                    }
                    val arabicStatus = when (proj.status) {
                        "Design Draft" -> "مسودة التصميم"
                        "Client Approval" -> "اعتماد العميل"
                        "Printing/Laser Cut" -> "قص ليزر وطباعة"
                        "Fabrication & Wiring" -> "تجميع وتوصيل الكتروني"
                        "Installation" -> "موقع التركيب النهائي"
                        else -> "مكتمل"
                    }
                    
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BorderGlass.copy(alpha = 0.2f))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = proj.title,
                                color = BrushedTitanium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${(progressPercent * 100).toInt()}%",
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Phase: $arabicStatus",
                            color = NeonPurple,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        LinearProgressIndicator(
                            progress = progressPercent,
                            color = NeonPurple,
                            trackColor = BorderGlass,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = isActive,
            enter = fadeIn() + expandVertically(expandFrom = Alignment.Top),
            exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Top)
        ) {
            Column {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "View Details / عرض التفاصيل",
                        color = NeonPurple,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Filled.ArrowForward,
                        contentDescription = null,
                        tint = NeonPurple,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}
