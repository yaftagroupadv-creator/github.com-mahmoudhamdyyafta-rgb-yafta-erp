package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun DesignPropertiesPanel(
    activeLayer: DesignLayer,
    activeIndex: Int,
    layersList: List<DesignLayer>,
    onLayerUpdate: (Int, DesignLayer) -> Unit,
    onPropertiesPanelClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard.copy(alpha = 0.98f)),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = modifier
            .fillMaxHeight(0.6f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = if (activeLayer.type == LayerType.TEXT) Icons.Filled.TextFields else Icons.Filled.Category,
                        contentDescription = null,
                        tint = NeonPurple,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        "PROPERTIES: ${activeLayer.name.uppercase()}",
                        color = BrushedTitanium,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onPropertiesPanelClose, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Filled.Close, null, tint = TextSilver, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Coord X: ${activeLayer.xPercent.toInt()}%", color = TextSilver, fontSize = 9.sp)
                    Slider(
                        value = activeLayer.xPercent,
                        onValueChange = { if (!activeLayer.isLocked) onLayerUpdate(activeIndex, activeLayer.copy(xPercent = it)) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Coord Y: ${activeLayer.yPercent.toInt()}%", color = TextSilver, fontSize = 9.sp)
                    Slider(
                        value = activeLayer.yPercent,
                        onValueChange = { if (!activeLayer.isLocked) onLayerUpdate(activeIndex, activeLayer.copy(yPercent = it)) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
                    )
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Scale Width: ${activeLayer.widthPercent.toInt()}%", color = TextSilver, fontSize = 9.sp)
                    Slider(
                        value = activeLayer.widthPercent,
                        onValueChange = { if (!activeLayer.isLocked) onLayerUpdate(activeIndex, activeLayer.copy(widthPercent = it)) },
                        valueRange = 5f..100f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Rotate Degree: ${activeLayer.rotation.toInt()}°", color = TextSilver, fontSize = 9.sp)
                    Slider(
                        value = activeLayer.rotation,
                        onValueChange = { if (!activeLayer.isLocked) onLayerUpdate(activeIndex, activeLayer.copy(rotation = it)) },
                        valueRange = 0f..360f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text("GLOW HIGHLIGHT PALETTE", color = BrushedTitanium, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("#00FFFF", "#FF007F", "#FFFF00", "#00FF66", "#FFFFFF").forEach { hexColor ->
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(android.graphics.Color.parseColor(hexColor)))
                            .border(
                                width = if (activeLayer.primaryColorHex == hexColor) 1.5.dp else 0.dp,
                                color = BrushedTitanium,
                                shape = CircleShape
                            )
                            .clickable {
                                if (!activeLayer.isLocked) {
                                    onLayerUpdate(activeIndex, activeLayer.copy(primaryColorHex = hexColor, glowColorHex = hexColor))
                                }
                            }
                    )
                }
            }

            if (activeLayer.type == LayerType.TEXT) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = activeLayer.text,
                    onValueChange = { onLayerUpdate(activeIndex, activeLayer.copy(text = it)) },
                    label = { Text("Sign Board Heading Text", fontSize = 8.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = BrushedTitanium, focusedLabelColor = NeonPurple)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text("Traditional Arabic Family Fonts:", color = TextSilver, fontSize = 8.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("Cairo", "Space Grotesk", "Bebas Neue").forEach { font ->
                        val isC = activeLayer.fontName == font
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isC) NeonPurple else DeepSlateBg)
                                .clickable { onLayerUpdate(activeIndex, activeLayer.copy(fontName = font)) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(font.take(6), color = if (isC) DeepSlateBg else TextSilver, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Curved Path Outline Decorator:", color = TextSilver, fontSize = 9.sp)
                    Switch(
                        checked = activeLayer.isCurved,
                        onCheckedChange = { onLayerUpdate(activeIndex, activeLayer.copy(isCurved = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Neon Halogen Glow Active:", color = TextSilver, fontSize = 9.sp)
                Switch(
                    checked = activeLayer.hasGlow,
                    onCheckedChange = { onLayerUpdate(activeIndex, activeLayer.copy(hasGlow = it)) },
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonPurple)
                )
            }

            if (activeLayer.hasGlow) {
                Text("Glow Blur Softness: ${activeLayer.glowRadius.toInt()}", color = TextSilver, fontSize = 8.sp)
                Slider(
                    value = activeLayer.glowRadius,
                    onValueChange = { onLayerUpdate(activeIndex, activeLayer.copy(glowRadius = it)) },
                    valueRange = 5f..35f,
                    colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
                )
            }

            Text("CNC Contour Contour Line: ${activeLayer.strokeWidth.toInt()}", color = TextSilver, fontSize = 8.sp)
            Slider(
                value = activeLayer.strokeWidth,
                onValueChange = { onLayerUpdate(activeIndex, activeLayer.copy(strokeWidth = it)) },
                valueRange = 0f..8f,
                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
            )
        }
    }
}
