package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreenLayout(viewModel: YaftaViewModel) {
    val warehouseStock by viewModel.inventoryList.collectAsState()
    val context = LocalContext.current

    var showAddItemDialog by remember { mutableStateOf(false) }

    // Forms States
    var name by remember { mutableStateOf("") }
    var materialType by remember { mutableStateOf("LED") } // LED, Acrylic, Flex, Transformer, Metal Profile
    var initialStock by remember { mutableStateOf("") }
    var minStockAlert by remember { mutableStateOf("") }
    var costPrice by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .padding(24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Warehouse & Sign Raw Stocks",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = BrushedTitanium
                        )
                    )
                    Text(
                        text = "${warehouseStock.size} primary components stockpiled for physical builds",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSilver
                    )
                }

                Button(
                    onClick = { showAddItemDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = null, tint = DeepSlateBg)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Receive Stock", fontWeight = FontWeight.Bold, color = DeepSlateBg)
                }
            }

            if (warehouseStock.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Filled.Inventory2, contentDescription = null, tint = TextSilver, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No stock items details inside directory.", color = TextSilver, fontWeight = FontWeight.Bold)
                        Text("Initiate inventory by tapping Receive Stock up right.", color = TextSilver, fontSize = 11.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(warehouseStock, key = { it.id }) { item ->
                        InventoryStockCard(
                            item = item,
                            onModifyQty = { newQty ->
                                viewModel.modifyInventoryQuantity(item, newQty)
                                Toast.makeText(context, "Stock levels adjusted.", Toast.LENGTH_SHORT).show()
                            },
                            onDelete = { viewModel.deleteInventoryItem(item.id) }
                        )
                    }
                }
            }
        }

        // ADD INVENTORY ITEM DIALOG
        if (showAddItemDialog) {
            AlertDialog(
                onDismissRequest = { showAddItemDialog = false },
                containerColor = DarkSlateCard,
                modifier = Modifier.border(1.dp, BorderGlass, RoundedCornerShape(16.dp)),
                title = { Text("Material Log Intake", color = BrushedTitanium, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Component Label (e.g. Amber Neon Flex 12V)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text("Commodity Category:", color = TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("LED", "Acrylic", "Flex", "Transformer", "Metal Profile", "Vinyl").forEach { type ->
                                val isMaterialSelected = materialType == type
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isMaterialSelected) NeonPurple.copy(alpha = 0.2f) else BorderGlass)
                                        .border(1.dp, if (isMaterialSelected) NeonPurple else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable { materialType = type }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(type, color = if (isMaterialSelected) NeonPurple else TextSilver, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = initialStock,
                            onValueChange = { initialStock = it },
                            label = { Text("Amount Received (Units / Meters)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = minStockAlert,
                            onValueChange = { minStockAlert = it },
                            label = { Text("Minimum Caution Level (Alert under)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = costPrice,
                            onValueChange = { costPrice = it },
                            label = { Text("Cost Unit Buying Price ($)", color = TextSilver) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonPurple, unfocusedBorderColor = BorderGlass, focusedTextColor = BrushedTitanium, unfocusedTextColor = BrushedTitanium),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val qty = initialStock.toDoubleOrNull()
                            val limit = minStockAlert.toDoubleOrNull()
                            val buyCost = costPrice.toDoubleOrNull()

                            if (name.isEmpty() || qty == null || limit == null || buyCost == null) {
                                Toast.makeText(context, "Fill out details with valid numeric parameters.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            viewModel.addInventoryItem(name, materialType, qty, limit, buyCost)
                            showAddItemDialog = false
                            // Reset
                            name = ""
                            initialStock = ""
                            minStockAlert = ""
                            costPrice = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) {
                        Text("Log Received Stock", color = DeepSlateBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddItemDialog = false }) {
                        Text("Cancel", color = TextSilver)
                    }
                }
            )
        }
    }
}

@Composable
fun InventoryStockCard(
    item: InventoryItem,
    onModifyQty: (Double) -> Unit,
    onDelete: () -> Unit
) {
    val isAlertState = item.currentStock <= item.minimumStockAlert
    val statusColor = if (isAlertState) SignalCritical else NeonCyan

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateCard)
            .border(1.dp, if (isAlertState) SignalCritical.copy(alpha = 0.5f) else BorderGlass, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.name,
                        fontWeight = FontWeight.Black,
                        color = BrushedTitanium,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "Warehouse Class: ${item.materialType} | Custom wholesale cost: $${item.unitPrice}",
                        color = TextSilver,
                        fontSize = 12.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .border(1.dp, statusColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isAlertState) "ALARM: REFILL UNIT" else "SECURED IN WAREHOUSE",
                        color = statusColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Current state details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LODGED QUANTITY: ${item.currentStock} Units",
                    color = BrushedTitanium,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Caution Threshold: <${item.minimumStockAlert} Units",
                    color = TextSilver,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(12.dp))

            // Quick adjustment tools
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Adhoc Level Adjust:", color = TextSilver, fontSize = 11.sp)
                    
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(BorderGlass)
                            .clickable { if (item.currentStock >= 5.0) onModifyQty(item.currentStock - 5.0) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("-5", color = BrushedTitanium, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(BorderGlass)
                            .clickable { onModifyQty(item.currentStock + 5.0) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("+5", color = BrushedTitanium, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Filled.Delete, contentDescription = "Trash Stock", tint = SignalCritical)
                }
            }
        }
    }
}
