package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun DesignLayersPanel(
    layersList: List<DesignLayer>,
    selectedLayerId: String?,
    onLayerSelect: (String) -> Unit,
    onPropertiesPanelOpen: (Boolean) -> Unit,
    onLayersPanelClose: () -> Unit,
    onCaptureState: () -> Unit,
    onLayerUpdate: (Int, DesignLayer) -> Unit,
    onLayerRemove: (DesignLayer) -> Unit,
    onSelectedLayerIdClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard.copy(alpha = 0.98f)),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .width(260.dp)
            .fillMaxHeight(0.65f)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("WORKBENCH LAYERS", color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onLayersPanelClose, modifier = Modifier.size(20.dp)) {
                    Icon(Icons.Filled.Close, null, tint = TextSilver, modifier = Modifier.size(14.dp))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Divider(color = BorderGlass)
            Spacer(modifier = Modifier.height(6.dp))

            if (layersList.isEmpty()) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text("No Layers Present", color = TextSilver, fontSize = 9.sp)
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(layersList) { layer ->
                        val sel = selectedLayerId == layer.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (sel) NeonPurple.copy(alpha = 0.15f) else Color.Transparent)
                                .clickable {
                                    onLayerSelect(layer.id)
                                    onPropertiesPanelOpen(true)
                                }
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (layer.type == LayerType.TEXT) Icons.Filled.TextFields else Icons.Filled.Category,
                                    contentDescription = null,
                                    tint = if (sel) NeonPurple else TextSilver,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = layer.name,
                                    color = if (sel) BrushedTitanium else TextSilver,
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row {
                                IconButton(
                                    onClick = {
                                        onCaptureState()
                                        val idx = layersList.indexOf(layer)
                                        if (idx != -1) {
                                            onLayerUpdate(idx, layer.copy(isLocked = !layer.isLocked))
                                        }
                                    },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        imageVector = if (layer.isLocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                                        contentDescription = null,
                                        tint = if (layer.isLocked) NeonPurple else TextSilver.copy(alpha = 0.4f),
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        onCaptureState()
                                        val idx = layersList.indexOf(layer)
                                        if (idx != -1) {
                                            onLayerUpdate(idx, layer.copy(isHidden = !layer.isHidden))
                                        }
                                    },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        imageVector = if (layer.isHidden) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        contentDescription = null,
                                        tint = if (layer.isHidden) TextSilver.copy(alpha = 0.3f) else NeonCyan,
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        onCaptureState()
                                        onLayerRemove(layer)
                                        if (selectedLayerId == layer.id) {
                                            onSelectedLayerIdClear()
                                            onPropertiesPanelOpen(false)
                                        }
                                    },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = null,
                                        tint = SignalCritical.copy(alpha = 0.8f),
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
