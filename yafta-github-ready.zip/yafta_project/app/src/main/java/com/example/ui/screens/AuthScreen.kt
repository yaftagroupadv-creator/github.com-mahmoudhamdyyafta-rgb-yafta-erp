package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreenLayout(viewModel: YaftaViewModel) {
    var isLogin by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("Admin") } // Admin, Designer, Fabricator, Installer
    var showPassword by remember { mutableStateOf(false) }

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg),
        contentAlignment = Alignment.Center
    ) {
        // Decorative ambient halo background
        Box(
            modifier = Modifier
                .size(400.dp)
                .background(Brush.radialGradient(listOf(NeonPurple.copy(alpha = 0.15f), Color.Transparent)))
                .align(Alignment.TopStart)
        )
        Box(
            modifier = Modifier
                .size(400.dp)
                .background(Brush.radialGradient(listOf(NeonCyan.copy(alpha = 0.1f), Color.Transparent)))
                .align(Alignment.BottomEnd)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 460.dp)
                .padding(16.dp)
                .border(2.dp, Brush.linearGradient(listOf(NeonPurple, NeonCyan)), RoundedCornerShape(24.dp))
                .shadow(24.dp, RoundedCornerShape(24.dp), ambientColor = NeonPurple, spotColor = NeonCyan),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header agency badge
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "Yafta Glow",
                    tint = NeonPurple,
                    modifier = Modifier
                        .size(48.dp)
                        .padding(bottom = 8.dp)
                )

                Text(
                    text = "يافطة للدعاية والإعلان",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonPurple,
                        textAlign = TextAlign.Center
                    )
                )
                Text(
                    text = "YAFTA FOR ADVERTISING",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        color = BrushedTitanium,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.padding(top = 4.dp)
                )
                Text(
                    text = "Signage, Premium Printing & Luxury Branding Operating System",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSilver,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp, bottom = 24.dp)
                )

                // Tab Switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BorderGlass)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isLogin) NeonPurple else Color.Transparent)
                            .clickable { isLogin = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Login",
                            fontWeight = FontWeight.Bold,
                            color = if (isLogin) DeepSlateBg else TextSilver
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (!isLogin) NeonCyan else Color.Transparent)
                            .clickable { isLogin = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Register",
                            fontWeight = FontWeight.Bold,
                            color = if (!isLogin) DeepSlateBg else TextSilver
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Inputs
                if (!isLogin) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Display Name", color = TextSilver) },
                        leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, tint = NeonCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = BorderGlass,
                            focusedTextColor = BrushedTitanium,
                            unfocusedTextColor = BrushedTitanium
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("username_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Roles pickers
                    Text(
                        text = "Your Fabrication Team Role:",
                        color = TextSilver,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.align(Alignment.Start).padding(bottom = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Designer", "Fabricator", "Installer").forEach { roleOption ->
                            val isSelected = role == roleOption
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NeonCyan.copy(alpha = 0.2f) else BorderGlass)
                                    .border(1.dp, if (isSelected) NeonCyan else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { role = roleOption },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = roleOption,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) NeonCyan else TextSilver
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address", color = TextSilver) },
                    leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null, tint = NeonPurple) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = BorderGlass,
                        focusedTextColor = BrushedTitanium,
                        unfocusedTextColor = BrushedTitanium
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("email_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password", color = TextSilver) },
                    leadingIcon = { Icon(Icons.AsymmetricVerifyPasswordIcon(), contentDescription = null, tint = NeonPurple) },
                    trailingIcon = {
                        IconButton(onClick = { showPassword = !showPassword }) {
                            Icon(
                                imageVector = if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = "Toggle password view",
                                tint = TextSilver
                            )
                        }
                    },
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonPurple,
                        unfocusedBorderColor = BorderGlass,
                        focusedTextColor = BrushedTitanium,
                        unfocusedTextColor = BrushedTitanium
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("password_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons
                Button(
                    onClick = {
                        if (email.isEmpty() || password.isEmpty()) {
                            Toast.makeText(context, "Please complete fields.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (isLogin) {
                            viewModel.login(email, password) { success, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            if (name.isEmpty()) {
                                Toast.makeText(context, "Full name required.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.register(email, password, name, role) { success ->
                                if (success) {
                                    Toast.makeText(context, "Registration Complete!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "User exists.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLogin) NeonPurple else NeonCyan
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (isLogin) "ENTER PORTAL / دخول" else "REGISTER / تسجيل",
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        color = DeepSlateBg
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Fast Prepopulated Test accounts bypass to ensure frictionless builds and audits
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BorderGlass.copy(alpha = 0.5f))
                        .clickable {
                            email = "agency@yafta.com"
                            password = "yafta"
                            isLogin = true
                            viewModel.login(email, password) { success, msg ->
                                Toast.makeText(context, "Fast Login Success: Welcome!", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "⚡ QUICK KEY BYPASS (TAP TO ACCESS)",
                            color = NeonAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Bypass with default: agency@yafta.com / yafta",
                            color = TextSilver,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

// Custom Helper icon creation to skip missing custom import errors
@Composable
fun Icons.AsymmetricVerifyPasswordIcon() = Icons.Filled.LockPassword

val Icons.Filled.LockPassword: ImageVector
    get() = Icons.Filled.Lock
