package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Company::class,
        User::class,
        Lead::class,
        Project::class,
        InventoryItem::class,
        FinanceTransaction::class,
        HrTask::class,
        CrmClient::class,
        CommunicationLog::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao
    abstract fun userDao(): UserDao
    abstract fun leadDao(): LeadDao
    abstract fun projectDao(): ProjectDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun financeDao(): FinanceDao
    abstract fun hrTaskDao(): HrTaskDao
    abstract fun crmClientDao(): CrmClientDao
    abstract fun communicationLogDao(): CommunicationLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                var instance: AppDatabase? = null
                val built = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "yafta_agency_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            kotlinx.coroutines.delay(200)
                            val dbInstance = instance ?: INSTANCE
                            dbInstance?.let { prepopulateDatabase(it) }
                        }
                    }
                })
                .build()
                instance = built
                INSTANCE = built
                built
            }
        }

        private suspend fun prepopulateDatabase(db: AppDatabase) {
            // 1. Setup creative agency default branches
            val branchId = db.companyDao().insertCompany(
                Company(
                    name = "Yafta Advertising - Riyadh Branch",
                    vatNumber = "VAT-30018-AR",
                    address = "Olaya District, Creative Space, Riyadh"
                ).let { it }
            )

            // 2. Prepopulate active designers & installation staffs
            // password sha-256 equivalent for "yafta" is easy to match
            db.userDao().insertUser(
                User(
                    email = "agency@yafta.com",
                    passwordHash = "yafta", // Plain-text matching fallback for simplified robust login
                    name = "Yafta Administrator",
                    role = "Admin",
                    companyId = 1
                )
            )
            db.userDao().insertUser(
                User(
                    email = "designer@yafta.com",
                    passwordHash = "yafta",
                    name = "Amira Al-Saeed",
                    role = "Designer",
                    companyId = 1
                )
            )
            db.userDao().insertUser(
                User(
                    email = "fabricator@yafta.com",
                    passwordHash = "yafta",
                    name = "Sari Al-Rashed",
                    role = "Fabricator",
                    companyId = 1
                )
            )

            // 3. Prepopulate inventory signage raw materials
            db.inventoryDao().insertInventoryItem(
                InventoryItem(
                    name = "Custom 3D Neon Purple LED Strips",
                    materialType = "LED",
                    currentStock = 250.0,
                    minimumStockAlert = 50.0,
                    unitPrice = 12.0
                )
            )
            db.inventoryDao().insertInventoryItem(
                InventoryItem(
                    name = "High-Intensity RGB LED Modules",
                    materialType = "LED",
                    currentStock = 1800.0,
                    minimumStockAlert = 200.0,
                    unitPrice = 1.50
                )
            )
            db.inventoryDao().insertInventoryItem(
                InventoryItem(
                    name = "Red Cast Acrylic Sheet (1.2m x 2.4m, 3mm)",
                    materialType = "Acrylic",
                    currentStock = 45.0,
                    minimumStockAlert = 10.0,
                    unitPrice = 35.0
                )
            )
            db.inventoryDao().insertInventoryItem(
                InventoryItem(
                    name = "Glossy Flex Signage Material (Standard)",
                    materialType = "Flex",
                    currentStock = 600.0,
                    minimumStockAlert = 100.0,
                    unitPrice = 4.50
                )
            )
            db.inventoryDao().insertInventoryItem(
                InventoryItem(
                    name = "Waterproof Power Transformer (12V, 400W)",
                    materialType = "Transformer",
                    currentStock = 30.0,
                    minimumStockAlert = 5.0,
                    unitPrice = 28.0
                )
            )
            db.inventoryDao().insertInventoryItem(
                InventoryItem(
                    name = "Aluminium Signage Box Frame Profiles",
                    materialType = "Metal Profile",
                    currentStock = 150.0,
                    minimumStockAlert = 25.0,
                    unitPrice = 18.50
                )
            )

            // 4. Prepopulate some leads / design briefing queries
            db.leadDao().insertLead(
                Lead(
                    clientName = "Al Faisaliah Cafe",
                    clientPhone = "+966 50 123 4567",
                    projectType = "3D Neon Signboard",
                    designBrief = "Need a premium neon visual styled with cool cosmic slate backing and double-ring neon purple glow with letters 'Faisaliah'.",
                    estimatedValue = 4200.0,
                    status = "Briefing"
                )
            )
            db.leadDao().insertLead(
                Lead(
                    clientName = "Kingdom Luxury Hotel",
                    clientPhone = "+966 55 987 6543",
                    projectType = "LED Screen",
                    designBrief = "Giant outdoor screen for main driveway (4x3 meters) with P4 outdoor LED panels and waterproof casing.",
                    estimatedValue = 28500.0,
                    status = "New"
                )
            )

            // 5. Prepopulate CRM Clients and Communication Logs
            val client1Id = db.crmClientDao().insertClient(
                CrmClient(
                    name = "Al Faisaliah Cafe",
                    email = "info@faisaliahcafe.sa",
                    phone = "+966 50 123 4567",
                    address = "Olaya District, Riyadh",
                    organization = "Al Faisaliah Group"
                )
            )
            val client2Id = db.crmClientDao().insertClient(
                CrmClient(
                    name = "Kingdom Luxury Hotel",
                    email = "facilities@kingdomhotel.com",
                    phone = "+966 55 987 6543",
                    address = "King Fahd Rd, Riyadh",
                    organization = "Kingdom Holding Company"
                )
            )

            db.communicationLogDao().insertLog(
                CommunicationLog(
                    clientId = client1Id,
                    type = "In-Person Meeting",
                    summary = "Met with Al Faisaliah Cafe managers regarding double-ring design",
                    detail = "Discussed acrylic layout thickness and neon purple lumen levels. Customer requested mock design in their dashboard view.",
                    agentName = "Amira Al-Saeed"
                )
            )
            db.communicationLogDao().insertLog(
                CommunicationLog(
                    clientId = client1Id,
                    type = "WhatsApp",
                    summary = "Confirmed budget and timeline parameters",
                    detail = "Agreed on US$4,200 total budget with 15% VAT breakdown. Installation set for Olaya branch location.",
                    agentName = "Yafta Administrator"
                )
            )
            db.communicationLogDao().insertLog(
                CommunicationLog(
                    clientId = client2Id,
                    type = "Phone Call",
                    summary = "Initial contact with procurement head",
                    detail = "Requested pricing for outdoor LED screens. Guided them through fabrication timelines.",
                    agentName = "Yafta Administrator"
                )
            )
        }
    }
}
